<?php

use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\FpayGatewayImpl;
use DI\Container;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use Fpay\Woocommerce\Strategies\CreatedOrderStrategy;
use Fpay\Woocommerce\Strategies\FpayOrderContextImpl;
use Fpay\Woocommerce\Strategies\RefundedOrderStrategy;
use Fpay\Woocommerce\Services\RefundManagerImpl;
use Fpay\Woocommerce\Services\PaymentManagerImpl;

use function Brain\Monkey\Functions\expect as expect_woocommerce;
use function Fpay\Woocommerce\Config\config;

/**
 * Const
 */
const UUID_KEY = 'uuid';


beforeAll(function () {
    $_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
});

beforeEach(function () {
    $this->fpay_factory = createFpayFactoryInstance($this->container, $this->plugin_config, $this->logger);
});

afterAll(function () {
    unset($_SERVER['HTTP_USER_AGENT']);
    unset($_GET[UUID_KEY]);
});

it('checks if the container was initialized correctly', function () {

    /**
     * Arrange
     */

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('sanitize_title')->twice()->andReturnFirstArg();

    /**
     * Act
     */
    $fpay_gateway = new FpayGatewayImpl();

    /**
     * Assert
     */
    expect($fpay_gateway->getContainer())->toBeInstanceOf(Container::class);

});

it('check if the payment was created correctly', function ($created_fpay_intent_response) {

    /**
     * Arrange
     */

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);

    /** @var FpayGatewayImpl | \Mockery\MockInterface $fpay_gateway_spy */
    $fpay_gateway_spy = Mockery::spy(FpayGatewayImpl::class)->makePartial();
    $fpay_gateway_spy->shouldReceive('saveDataInSession')->andReturn();
    $fpay_gateway_spy->setContainer($this->container);
    $fpay_gateway_spy->setLogger($this->logger);

    $logger_spy = createLoggerSpy();
    $fpay_gateway_spy->setLogger($logger_spy);

    $fpay_order_context = Mockery::spy(new FpayOrderContextImpl());
    $fpay_gateway_spy->setFpayOrderContext($fpay_order_context);

    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    $spy_order_id = $wc_order_spy->get_id();
    $wc_order_spy->shouldReceive('set_payment_method')->andReturn();
    $wc_order_spy->shouldReceive('set_payment_method_title')->andReturn();


    $payment_manager_spy = Mockery::spy(PaymentManagerImpl::class);
    $payment_manager_spy->shouldReceive('processPayment')
        ->withAnyArgs()
        ->andReturn($fpay_intent);

    $fpay_gateway_spy->setPaymentManager($payment_manager_spy);
    $fpay_gateway_spy->setPluginConfig(config());

    $session_manager_spy = Mockery::spy(SessionManager::class);
    $session_manager_spy->shouldReceive('saveDataInSession')->andReturn();
    $fpay_gateway_spy->setSessionManager($session_manager_spy);

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_add_notice')
        ->once()
        ->with('Por favor realice el pago en Fpay.');

    expect_woocommerce('home_url')
        ->once()
        ->andReturn(WOOCOMMERCE_DOMAIN);

    expect_woocommerce('wc_get_order')->twice()->andReturn($wc_order_spy);

    /**
     * Act
     */
    $response = $fpay_gateway_spy->process_payment($spy_order_id);

    /**
     * Assert
     */
    expect($response)->toMatchArray(array(
        'result' => 'success',
        'redirect' => $fpay_intent->getFpayCheckoutUrl()
    ));

    expect($fpay_gateway_spy->getFpayOrderContext()->getStrategy())
        ->toBeInstanceOf(
            CreatedOrderStrategy::class
        );

    $wc_order_spy->shouldHaveReceived('set_payment_method')
        ->with(Mockery::on(function ($payment_method) {
            return $payment_method === config('plugin_id');
        }))
        ->once();

    $wc_order_spy->shouldHaveReceived('set_payment_method_title')
        ->with(Mockery::on(function ($payment_method) {
            return $payment_method === config('plugin_tittle');
        }))
        ->once();

    $wc_order_spy->shouldHaveReceived('save')
        ->twice();

    $payment_manager_spy->shouldHaveReceived('processPayment')
        ->once();

    $wc_order_spy->shouldHaveReceived('add_order_note')
        ->twice();

    $session_manager_spy->shouldHaveReceived('saveDataInSession')
        ->once();

})
    ->with('created_fpay_intent_response');

it('checks when a refund was did via woocommerce', function (
    $partially_refund_fpay_intent_response,
    $wc_order_refund_without_metadata_data
) {
    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($partially_refund_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);

    /** @var FpayGatewayImpl | \Mockery\Mock $fpay_gateway_spy */
    $fpay_gateway_spy = Mockery::spy(FpayGatewayImpl::class)->makePartial();
    $fpay_gateway_spy->setContainer($this->container);
    $fpay_gateway_spy->setPluginConfig(config());
    $fpay_gateway_spy->id = config('plugin_id');

    $logger_spy = createLoggerSpy();
    $fpay_gateway_spy->setLogger($logger_spy);

    $fpay_order_context = Mockery::spy(new FpayOrderContextImpl());
    $fpay_gateway_spy->setFpayOrderContext($fpay_order_context);

    $last_refund_spy = Mockery::spy(WC_Order_Refund::class);
    /** @var WoocommerceRefundsManager | \Mockery\Mock $woocommerce_refunds_manager_spy */
    $woocommerce_refunds_manager_spy = Mockery::spy(WoocommerceRefundsManager::class)->makePartial();
    $woocommerce_refunds_manager_spy->shouldReceive('addMetaDataToRefund')->andReturn();
    $woocommerce_refunds_manager_spy->shouldReceive('getLastRefund')->withAnyArgs()->andReturn($last_refund_spy);
    $fpay_gateway_spy->setWoocommerceRefundsManager($woocommerce_refunds_manager_spy);

    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    $order_spy_id = $wc_order_spy->get_id();

    $wc_order_refund_mock = createWcOrderRefund($wc_order_refund_without_metadata_data);
    $wc_order_spy->shouldReceive('get_refunds')->andReturn(array($wc_order_refund_mock));

    $refund_mock = createRefundFromRefundData($this->fpay_factory, $fpay_intent->getId(), 1, $order_spy_id);
    /** @var FpayFactory | Mockery\Mock $fpay_factory_spy */
    $fpay_factory_spy = Mockery::spy(FpayFactory::class)->makePartial();
    $fpay_factory_spy->shouldReceive('createRefund')
        ->andReturn($refund_mock);
    $fpay_gateway_spy->setFpayFactory($fpay_factory_spy);

    /** @var RefundManager | Mockery\Mock $refund_manager_mock */
    $refund_manager_mock = Mockery::mock(RefundManagerImpl::class)
        ->makePartial();

    $refund_manager_mock->expects('processRefund')
        ->withAnyArgs()
        ->andReturn($fpay_intent);

    $fpay_gateway_spy->setRefundManager($refund_manager_mock);

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_get_order')->once()->andReturn($wc_order_spy);

    /**
     * Act
     */
    $refund_result = $fpay_gateway_spy->process_refund($order_spy_id, 1, 'fpay_refund');

    /**
     * Assert
     */
    expect($fpay_gateway_spy->getFpayOrderContext()->getStrategy())
        ->toBeInstanceOf(
            RefundedOrderStrategy::class
        );

    expect($refund_result)->toBeTrue();

    $woocommerce_refunds_manager_spy->shouldHaveReceived('getLastRefund')
        ->once();

    $woocommerce_refunds_manager_spy->shouldHaveReceived('addMetaDataToRefund')
        ->once();

    $wc_order_spy
        ->shouldHaveReceived('add_order_note')
        ->twice();

})->with('partially_refund_fpay_intent_response')
    ->with('wc_order_refund_without_metadata_data');

