<?php
const ERROR_KEY_1 = 'FpayWoocommerceError-001';
const ERROR_KEY_2 = 'FpayWoocommerceError-002';
const ERROR_KEY_3 = 'FpayWoocommerceError-003';
const ERROR_KEY_4 = 'FpayWoocommerceError-004';
const ERROR_KEY_5 = 'FpayWoocommerceError-005';
const ERROR_KEY_6 = 'FpayWoocommerceError-006';
const ERROR_KEY_7 = 'FpayWoocommerceError-007';
const ERROR_KEY_8 = 'FpayWoocommerceError-008';
const ERROR_KEY_9 = 'FpayWoocommerceError-009';
const ERROR_KEY_10 = 'FpayWoocommerceError-010';
const ERROR_KEY_11 = 'FpayWoocommerceError-011';
const ERROR_KEY_12 = 'FpayWoocommerceError-012';
const ERROR_KEY_13 = 'FpayWoocommerceError-013';
const  ERROR_KEY_14 = 'FpayWoocommerceError-014';
const  ERROR_KEY_15 = 'FpayWoocommerceError-015';
const  ERROR_KEY_16 = 'FpayWoocommerceError-016';


const ERROR_FOR_HUMANS_MESSAGE = 'Ocurrió un error al procesar la transacción con Fpay - ';
