<?php

use Fpay\Woocommerce\Exceptions\FpayAuthExceptionImpl;
use Fpay\Woocommerce\Services\FpayAuthImpl;
use function Brain\Monkey\Functions\expect as expect_woocommerce;

it('checks when the credentials are invalid and throw an exception', function ($invalid_credentials_data) {

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_add_notice')
        ->with(
            ERROR_FOR_HUMANS_MESSAGE . ERROR_KEY_1,
            'error'
        );

    /**
     * Arrange
     */
    $client_mock = createClientMock(
        array($invalid_credentials_data)
    );
    $settings = createSettingsMock();
    $logger_spy = createLoggerSpy();

    $fpay_auth_impl = new FpayAuthImpl(
        $client_mock,
        $settings['prod_base_url'],
        $settings['auth_url'],
        $logger_spy,
        $this->container,
    );
    $message = 'Bad response client exception.';

    /**
     * Act
     */
    $exception_to_assert = new \Exception();
    $error = false;

    try {
        $fpay_auth_impl->authInServer($settings['public_key'], $settings['private_key']);
    } catch (\Exception $fpay_auth_exception) {
        $exception_to_assert = $fpay_auth_exception;
        $error = true;
    }

    /**
     * Assert
     */
    expect($error)->toBeTrue();
    expect($exception_to_assert)->toBeInstanceOf(FpayAuthExceptionImpl::class);
    expect($exception_to_assert->getMessage())->toEqual($message);

})->with('invalid_credentials_data');

it('checks the method authInServer works', function ($valid_credentials_data) {

    /**
     * Arrange
     */
    $client_mock = createClientMock(
        array($valid_credentials_data)
    );
    $settings = createSettingsMock();
    $logger_spy = createLoggerSpy();

    $fpay_auth_impl = new FpayAuthImpl(
        $client_mock,
        $settings['prod_base_url'],
        $settings['auth_url'],
        $logger_spy,
        $this->container,
    );


    /**
     * Act
     */

    $fpay_auth_impl->authInServer($settings['public_key'], $settings['private_key']);

    /**
     * Assert
     */
    expect($fpay_auth_impl->getBearerToken())->toBeString();

})->with('valid_credentials_data');

