<?php

use Fpay\Woocommerce\Controllers\Contracts\WebhookController;
use Fpay\Woocommerce\Controllers\WebhookControllerImpl;
use Fpay\Woocommerce\Exceptions\Contracts\FpayWebhookControllerException;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\FpayGatewayImpl;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Fpay\Woocommerce\Services\Contracts\Webhook;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use Fpay\Woocommerce\Services\FpayIntentManagerImpl;
use Fpay\Woocommerce\Services\WebhookImpl;
use Fpay\Woocommerce\Strategies\CancelOrderStrategy;
use Fpay\Woocommerce\Strategies\FailOrderStrategy;
use Fpay\Woocommerce\Strategies\FpayOrderContextImpl;
use Fpay\Woocommerce\Strategies\PaidOrderStrategy;
use function Brain\Monkey\Functions\expect as expect_woocommerce;
use function Fpay\Woocommerce\Config\config;

beforeAll(function () {
    $_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
});

beforeEach(function () {
    /** @var FpayFactory fpay_factory */
    $this->fpay_factory = createFpayFactoryInstance($this->container, $this->plugin_config, $this->logger);
});

afterAll(function () {
    unset($_SERVER['HTTP_USER_AGENT']);
    unset($_GET[UUID_KEY]);
});


it('check when the report of a success payment was received on the store', function ($paid_fpay_intent_response) {
    /**
     * Arrange
     */

    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('sanitize_title')->once()->andReturnFirstArg();
    expect_woocommerce('wc_clear_notices')->once()->andReturn();
    expect_woocommerce('wc_add_notice')
        ->once()
        ->with('Gracias por pagar con Fpay, súmate a lo simple.');

    $fpay_intent_data_hidrated = json_decode(json_encode($paid_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);

    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    $wc_order_spy->shouldReceive('get_checkout_order_received_url')
        ->andReturn(WOOCOMMERCE_DOMAIN . '/?page_id=12&order-received=360&key=wc_order_M0cHEvNnCn2Ev');

    expect_woocommerce('wp_safe_redirect')
        ->once()
        ->with($wc_order_spy->get_checkout_order_received_url());

    expect_woocommerce('wc_get_order')->once()->andReturn($wc_order_spy);

    /** @var SessionManager | \Mockery\Mock $session_manager_spy */
    $session_manager_spy = Mockery::spy(SessionManager::class)->makePartial();
    $session_manager_spy->shouldReceive('getDataFromSession')->andReturn(
        array(FpayGatewayImpl::ORDER_ID_KEY => $wc_order_spy->get_id(), FpayGatewayImpl::SELF_LINK_KEY => $fpay_intent->getSelfUrl())
    );

    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManagerImpl::class)->makePartial();
    $fpay_intent_manager_spy->shouldReceive('getFpayIntentFromSelfUrl')
        ->withAnyArgs()
        ->andReturn($fpay_intent);

    $fpay_auth_spy = createFpayAuthSpy();
    $settings = createSettingsMock();

    $woocommerce_refunds_maanger = Mockery::spy(WoocommerceRefundsManager::class);

    $refund_manager = Mockery::spy(RefundManager::class);

    $fpay_order_context = Mockery::spy(new FpayOrderContextImpl());

    /** @var Webhook | \Mockery\Mock $webhook_spy */
    $webhook_spy = Mockery::spy(WebhookImpl::class, [
        $this->logger,
        $this->container,
        $fpay_intent_manager_spy,
        $fpay_auth_spy,
        $settings,
        $fpay_order_context,
        $woocommerce_refunds_maanger,
        $refund_manager,
        config()
    ])->makePartial();

    $webhook_spy->shouldReceive('checkIfBelongsToPaymentGateway')->andReturn();

    /** @var WebhookController | \Mockery\Mock $webhook_controller */
    $webhook_controller_spy = Mockery::spy(new WebhookControllerImpl(
        $webhook_spy,
        config(),
        $this->fpay_factory,
        $this->logger,
        $session_manager_spy,
        $this->container
    ));

    $webhook_controller_spy->shouldReceive('registerRoutes')->andReturn();

    /**
     * Act
     */
    $webhook_controller_spy->paymentWebhook();

    /**
     * Assert
     */
    expect($webhook_spy->getFpayOrderContext()->getStrategy())
        ->toBeInstanceOf(
            PaidOrderStrategy::class
        );

    $wc_order_spy
        ->shouldHaveReceived('payment_complete')
        ->once();

    $wc_order_spy
        ->shouldHaveReceived('add_order_note')
        ->twice();

    $webhook_spy->shouldHaveReceived('processFpayIntent')
        ->once();

    $webhook_spy->shouldHaveReceived('processFpayIntentSuccess')
        ->once();

})->with('paid_fpay_intent_response');

it('check when the report of a cancel payment was received on the store', function ($created_fpay_intent_response) {
    /**
     * Arrange
     */

    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('sanitize_title')->once()->andReturnFirstArg();
    expect_woocommerce('wc_clear_notices')->once()->andReturn();
    expect_woocommerce('wc_add_notice')
        ->once()
        ->with(
            'Se abandono el proceso con Fpay. Intentalo de nuevo.',
            'error'
        );
    expect_woocommerce('wc_get_checkout_url')
        ->once()
        ->andReturn(CHECKOUT_URL);

    expect_woocommerce('wp_safe_redirect')
        ->once()
        ->with(CHECKOUT_URL);

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);

    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    expect_woocommerce('wc_get_order')->once()->andReturn($wc_order_spy);

    /** @var SessionManager | \Mockery\Mock $session_manager_spy */
    $session_manager_spy = Mockery::spy(SessionManager::class)->makePartial();
    $session_manager_spy->shouldReceive('getDataFromSession')->andReturn(
        array(FpayGatewayImpl::ORDER_ID_KEY => $wc_order_spy->get_id(), FpayGatewayImpl::SELF_LINK_KEY => $fpay_intent->getSelfUrl())
    );

    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManagerImpl::class)->makePartial();
    $fpay_intent_manager_spy->shouldReceive('getFpayIntentFromSelfUrl')
        ->withAnyArgs()
        ->andReturn($fpay_intent);

    $fpay_auth_spy = createFpayAuthSpy();
    $settings = createSettingsMock();

    $woocommerce_refunds_maanger = Mockery::spy(WoocommerceRefundsManager::class);

    $refund_manager = Mockery::spy(RefundManager::class);

    $fpay_order_context = Mockery::spy(new FpayOrderContextImpl());

    /** @var Webhook | \Mockery\Mock $webhook_spy */
    $webhook_spy = Mockery::spy(WebhookImpl::class, [
        $this->logger,
        $this->container,
        $fpay_intent_manager_spy,
        $fpay_auth_spy,
        $settings,
        $fpay_order_context,
        $woocommerce_refunds_maanger,
        $refund_manager,
        config()
    ])->makePartial();

    $webhook_spy->shouldReceive('checkIfBelongsToPaymentGateway')->andReturn();

    /** @var WebhookController | \Mockery\Mock $webhook_controller */
    $webhook_controller_spy = Mockery::spy(new WebhookControllerImpl(
        $webhook_spy,
        config(),
        $this->fpay_factory,
        $this->logger,
        $session_manager_spy,
        $this->container
    ));

    $webhook_controller_spy->shouldReceive('registerRoutes')->andReturn();

    /**
     * Act
     */
    $webhook_controller_spy->paymentWebhook();

    /**
     * Assert
     */
    /**
     * Assert
     */
    expect($webhook_spy->getFpayOrderContext()->getStrategy())
        ->toBeInstanceOf(
            CancelOrderStrategy::class
        );

    $webhook_spy->shouldHaveReceived('processFpayIntent')
        ->once();

    $webhook_spy->shouldHaveReceived('processOthersStatesOfFpayIntent')
        ->once();

    $wc_order_spy
        ->shouldHaveReceived('add_order_note')
        ->twice();

})->with('created_fpay_intent_response');

it('check when the report of a failed payment was received on the store', function ($rejected_fpay_intent_response) {
    /**
     * Arrange
     */

    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($rejected_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);

    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    expect_woocommerce('wc_get_order')->once()->andReturn($wc_order_spy);

    /** @var SessionManager | \Mockery\Mock $session_manager_spy */
    $session_manager_spy = Mockery::spy(SessionManager::class)->makePartial();
    $session_manager_spy->shouldReceive('getDataFromSession')->andReturn(
        array(
            FpayGatewayImpl::ORDER_ID_KEY => $wc_order_spy->get_id(),
            FpayGatewayImpl::SELF_LINK_KEY => $fpay_intent->getSelfUrl()
        )
    );

    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManagerImpl::class)->makePartial();
    $fpay_intent_manager_spy->shouldReceive('getFpayIntentFromSelfUrl')
        ->withAnyArgs()
        ->andReturn($fpay_intent);

    $fpay_auth_spy = createFpayAuthSpy();
    $settings = createSettingsMock();

    $woocommerce_refunds_maanger = Mockery::spy(WoocommerceRefundsManager::class);

    $refund_manager = Mockery::spy(RefundManager::class);

    $fpay_order_context = Mockery::spy(new FpayOrderContextImpl());

    /** @var Webhook | \Mockery\Mock $webhook_spy */
    $webhook_spy = Mockery::spy(WebhookImpl::class, [
        $this->logger,
        $this->container,
        $fpay_intent_manager_spy,
        $fpay_auth_spy,
        $settings,
        $fpay_order_context,
        $woocommerce_refunds_maanger,
        $refund_manager,
        config()
    ])->makePartial();

    $webhook_spy->shouldReceive('checkIfBelongsToPaymentGateway')->andReturn();

    /** @var WebhookController | \Mockery\Mock $webhook_controller */
    $webhook_controller_spy = Mockery::spy(new WebhookControllerImpl(
        $webhook_spy,
        config(),
        $this->fpay_factory,
        $this->logger,
        $session_manager_spy,
        $this->container
    ));

    $webhook_controller_spy->shouldReceive('registerRoutes')->andReturn();

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('sanitize_title')->once()->andReturnFirstArg();
    expect_woocommerce('wc_clear_notices')->once()->andReturn();

    expect_woocommerce('wc_add_notice')
        ->once()
        ->with(
            'El pago falló, por favor vuelva a intentarlo.',
            'error'
        );
    expect_woocommerce('wc_get_checkout_url')
        ->once()
        ->andReturn(CHECKOUT_URL);

    expect_woocommerce('wp_safe_redirect')
        ->once()
        ->with(CHECKOUT_URL);

    /**
     * Act
     */
    $webhook_controller_spy->paymentWebhook();

    /**
     * Assert
     */
    /**
     * Assert
     */
    expect($webhook_spy->getFpayOrderContext()->getStrategy())
        ->toBeInstanceOf(
            FailOrderStrategy::class
        );

    $webhook_spy->shouldHaveReceived('processFpayIntent')
        ->once();

    $webhook_spy->shouldHaveReceived('processOthersStatesOfFpayIntent')
        ->once();

    $wc_order_spy
        ->shouldHaveReceived('add_order_note')
        ->twice();

})->with('rejected_fpay_intent_response');

it('check when get data from session method fails on SessionManager class', function ($paid_fpay_intent_response) {
    /**
     * Arrange
     */

    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($paid_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);

    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    $wc_order_spy->shouldReceive('get_checkout_order_received_url')
        ->andReturn(WOOCOMMERCE_DOMAIN . '/?page_id=12&order-received=360&key=wc_order_M0cHEvNnCn2Ev');

    /** @var SessionManager | \Mockery\Mock $session_manager_spy */
    $session_manager_spy = Mockery::spy(SessionManager::class)->makePartial();
    $session_manager_spy->shouldReceive('getDataFromSession')->andThrows(new Exception());

    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManagerImpl::class)->makePartial();
    $fpay_intent_manager_spy->shouldReceive('getFpayIntentFromSelfUrl')
        ->withAnyArgs()
        ->andReturn($fpay_intent);

    $fpay_auth_spy = createFpayAuthSpy();
    $settings = createSettingsMock();

    $woocommerce_refunds_maanger = Mockery::spy(WoocommerceRefundsManager::class);

    $refund_manager = Mockery::spy(RefundManager::class);

    $fpay_order_context = Mockery::spy(new FpayOrderContextImpl());

    /** @var Webhook | \Mockery\Mock $webhook_spy */
    $webhook_spy = Mockery::spy(WebhookImpl::class, [
        $this->logger,
        $this->container,
        $fpay_intent_manager_spy,
        $fpay_auth_spy,
        $settings,
        $fpay_order_context,
        $woocommerce_refunds_maanger,
        $refund_manager,
        config()
    ])->makePartial();

    $webhook_spy->shouldReceive('checkIfBelongsToPaymentGateway')->andReturn();

    /** @var WebhookController | \Mockery\Mock $webhook_controller */
    $webhook_controller_spy = Mockery::spy(new WebhookControllerImpl(
        $webhook_spy,
        config(),
        $this->fpay_factory,
        $this->logger,
        $session_manager_spy,
        $this->container
    ))->makePartial();

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('sanitize_title')->once()->andReturnFirstArg();
    expect_woocommerce('wc_clear_notices')->once()->andReturn();
    expect_woocommerce('wc_add_notice')
        ->with(ERROR_FOR_HUMANS_MESSAGE . ERROR_KEY_16, 'error')
        ->once();

    expect_woocommerce('home_url')->once()->andReturn(WOOCOMMERCE_DOMAIN);

    expect_woocommerce('wp_safe_redirect')
        ->once()
        ->with(WOOCOMMERCE_DOMAIN);

    /**
     * Act
     */
    $exception_to_assert = null;
    try {
        $webhook_controller_spy->paymentWebhook();
    } catch (Exception $exception) {
        $exception_to_assert = $exception;
    }

    /**
     * Assert
     */
    expect($exception_to_assert)->toBeInstanceOf(FpayWebhookControllerException::class);

})->with('paid_fpay_intent_response');