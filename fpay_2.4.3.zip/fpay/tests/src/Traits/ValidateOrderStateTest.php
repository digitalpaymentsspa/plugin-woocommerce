<?php

use Fpay\Woocommerce\Exceptions\Contracts\FpayDuplicateOrderUpdateException;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\Models\Contracts\AbstractOrder;
use Fpay\Woocommerce\Traits\ValidateOrderState;
use function Brain\Monkey\Functions\expect as expect_woocommerce;

uses(ValidateOrderState::class);
beforeEach(function () {
    /** @var FpayWoocommerceFactory fpay_woocommerce_real_factory */
    $this->fpay_woocommerce_real_factory = createFpayWoocommerceFactoryInstance($this->container, $this->plugin_config, $this->logger);
    /** @var FpayFactory fpay_real_factory */
    $this->fpay_real_factory = createFpayFactoryInstance($this->container, $this->plugin_config, $this->logger);
});

it('checks when the callback url in cancel state was called more than once', function ($data_for_create_wc_order){
    /**
     * Arrange
     */
    expect_woocommerce('wp_safe_redirect')->once();
    expect_woocommerce('wc_get_checkout_url')->once();

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $wc_order_spy->shouldReceive('get_status')->andReturn(AbstractOrder::CANCELLED_STATUS);
    //expect_woocommerce('wc_get_order')->andReturn($wc_order_spy)->twice();
    /**
     * Act
     */
    $exception_to_assert = null;
    try{
        $this->wasOrderUpdatedPreviously($wc_order_spy, AbstractOrder::CANCELLED_STATUS);
    }catch (\Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeInstanceOf(FpayDuplicateOrderUpdateException::class);
})->with('data_for_create_wc_order');

it('checks when the callback url in paid state was called more than once', function ($data_for_create_wc_order){
    /**
     * Arrange
     */
    expect_woocommerce('wp_safe_redirect')->once();
    expect_woocommerce('wc_get_checkout_url')->once();

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $wc_order_spy->shouldReceive('get_status')->andReturn(AbstractOrder::PROCESSING_STATUS);
    expect_woocommerce('wc_get_order')->andReturn($wc_order_spy)->once();
    /**
     * Act
     */
    $exception_to_assert = null;
    try{

        $this->wasOrderUpdatedPreviously($wc_order_spy, AbstractOrder::PROCESSING_STATUS);
    }catch (\Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeInstanceOf(FpayDuplicateOrderUpdateException::class);
})->with('data_for_create_wc_order');

it('checks when the callback url in fail state was called more than once', function ($data_for_create_wc_order){
    /**
     * Arrange
     */
    expect_woocommerce('wp_safe_redirect')->once();

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $wc_order_spy->shouldReceive('get_status')->andReturn(AbstractOrder::FAILED_STATUS);

    /**
     * Act
     */
    $exception_to_assert = null;
    try{

        $this->wasOrderUpdatedPreviously($wc_order_spy, AbstractOrder::FAILED_STATUS);
    }catch (\Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeInstanceOf(FpayDuplicateOrderUpdateException::class);
})->with('data_for_create_wc_order');

it('checks when order state is null', function ($data_for_create_wc_order){
    /**
     * Arrange
     */

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $wc_order_spy->shouldReceive('get_status')->andReturn(null);

    /**
     * Act
     */
    $exception_to_assert = null;
    try{
        $this->wasOrderUpdatedPreviously($wc_order_spy, AbstractOrder::FAILED_STATUS);
    }catch (\Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeNull();
})->with('data_for_create_wc_order');

it('checks when the callback url in not success payment state was called but has a different state', function ($data_for_create_wc_order){
    /**
     * Arrange
     */

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $wc_order_spy->shouldReceive('get_status')->andReturn(AbstractOrder::PENDING_STATUS);
    /**
     * Act
     */
    $exception_to_assert = null;
    try{

        $this->wasOrderUpdatedPreviously($wc_order_spy, AbstractOrder::CANCELLED_STATUS);
    }catch (\Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeNull();
})->with('data_for_create_wc_order');

it('checks when the callback url in success payment state was called but has a different state', function ($data_for_create_wc_order){
    /**
     * Arrange
     */

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $wc_order_spy->shouldReceive('get_status')->andReturn(AbstractOrder::PENDING_STATUS);

    /**
     * Act
     */
    $exception_to_assert = null;
    try{

        $this->wasOrderUpdatedPreviously($wc_order_spy, AbstractOrder::PROCESSING_STATUS);
    }catch (\Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeNull();
})->with('data_for_create_wc_order');