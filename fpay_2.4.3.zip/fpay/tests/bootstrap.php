<?php
declare(strict_types=1);

!defined('ABSPATH') && define('ABSPATH', 'WooCommerce_Const');
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/stubs/WC_Payment_Gateway.php';
require_once __DIR__ . '/stubs/WC_Settings_API.php';

/**
 * Copy the .env file if this does not exist.
 */
$source = __DIR__ . '/../.env.example';
$destination = __DIR__ . '/../.env';
copy($source, $destination);

