<?php


dataset('paid_fpay_intent_response', function () {
    yield function () {
        return
            array(
                'http_code' => 200,
                'body' => array(
                    "redirect_urls" => array(
                        "return_url" =>
                            "http://example.com?wc-api=fpay_payment_success&uuid=" . UUID,
                        "cancel_url" =>
                            "http://example.com?wc-api=fpay_payment_not_success&uuid=" . UUID,
                    ),
                    "intent" => "sale",
                    "state" => "paid",
                    "_id" => "6305b48f74cd94002eea6689",
                    "payment_method" => "WALLET_QR",
                    "pst_origen" => "woocommerce",
                    "buyer" => array(
                        "logged_in" => true,
                        "email" => "ext_andfevegan@falabella.cl",
                        "phone" => "3012017499",
                        "full_name" => "Andres Vega",
                    ),
                    "transaction" => array(
                        "purchase_order" => "360",
                        "invoice_type" => "BOLETA",
                        "fpay_calculate_tax_subtotal" => false,
                        "promotions" => array(),
                        "deferred_capture" => false,
                        "shipping_method" => "DIGITAL",
                        "merchant_unique_id" => "wc_360_20220824051807000000",
                        "description" => "Compra woocommerce",
                        "soft_descriptor" => "WOOCOMMERCE_2.1.1",
                        "merchant_fantasy_name" => "woocommerce",
                        "reconciliation_id" => "6305b48f74cd94002eea6689",
                        "terminal_id" => "1",
                        "store_id" => "1",
                        "channel" => "WEB",
                        "on_behalf_of" => "360",
                        "invoice_number" => "360",
                        "item_list" => array(
                            "items" => array(
                                array(
                                    "sku" => "17",
                                    "name" => "leche la vaca lola",
                                    "description" => "leche la vaca lola",
                                    "quantity" => 1,
                                    "price" => 9,
                                    "tax" => 0,
                                    "category" => "line_item",
                                ),
                            ),
                            "shipping_method" => "DIGITAL",
                            "shipping_address" => array(
                                "address_type" => "HOME_OR_WORK",
                                "line1" => "cra 17 55 n 45 ",
                                "city" => "Santiago",
                                "country_code" => "CL",
                                "phone" => "3012017499",
                                "recipient_name" => "Andres Vega",
                            ),
                        ),
                        "amount" => array(
                            "installments_number" => 1,
                            "deferred_months_number" => 0,
                            "currency" => "CLP",
                            "total" => 9,
                            "details" => array(
                                "subtotal" => 9,
                                "tax" => 0,
                                "shipping" => 0,
                                "shipping_discount" => 0,
                            ),
                        ),
                        "aggregation_code" => "CL-636741",
                    ),
                    "application" => "62752e822b604e003e4fb42f",
                    "invoice_number" => "IP-16613182879513131",
                    "create_time" => "2022-08-24T05:18:07.951Z",
                    "update_time" => "2022-08-24T05:20:29.827Z",
                    "links" => array(
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/6305b48f74cd94002eea6689",
                            "rel" => "self",
                            "security" => array("ApiKey"),
                            "method" => "GET",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/6305b48f74cd94002eea6689/pay",
                            "rel" => "approval_url",
                            "method" => "REDIRECT",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/6305b48f74cd94002eea6689/edit",
                            "rel" => "update_url",
                            "method" => "PUT",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/wc_360_20220824051807000000/merchant-unique-id",
                            "rel" => "self_by_merchant_unique_id",
                            "security" => array("ApiKey"),
                            "method" => "GET",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/6305b48f74cd94002eea6689/pay",
                            "rel" => "approval_url_void",
                            "method" => "PUT",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/6305b48f74cd94002eea6689/refund",
                            "rel" => "refund_method",
                            "security" => array("Jwt"),
                            "method" => "POST",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/6305b48f74cd94002eea6689/refund",
                            "rel" => "refund_void",
                            "security" => array("Jwt"),
                            "method" => "PUT",
                        ),
                    ),
                    "expiration_date" => "2022-08-24T05:28:09.436Z",
                    "fpay_merchant_id" => "PP62752e822b604e003e4fb42f",
                    "long_transaction_code" => "2022082479953127",
                    "mutated" => true,
                    "short_transaction_code" => "79953127",
                    "ui_mode" => "001",
                    "payer" => array(
                        "country" => "CL",
                        "document_type" => "RUT",
                        "document_number" => "144425189",
                    ),
                    "payment_type" => "WALLET",
                    "qr_type" => "DYNAMIC",
                    "gateway" => array(
                        "refunds" => array(),
                        "voids" => array(),
                        "resume" => array(
                            "response" => array("code" => 0),
                            "transaction" => array(
                                "installments_info" => array(
                                    "installments_number" => "1",
                                    "deferred" => "0",
                                ),
                                "gateway_id" => "6305b48f74cd94002eea6689",
                                "selected_payment_method" => "WALLET",
                                "currency" => "CLP",
                                "purchase_order" => "360",
                                "amount" => 9,
                                "date" => "2022-08-24T05:20:22.605Z",
                            ),
                            "authorizations" => array("code" => "39173134"),
                            "account_number" => array(
                                "account_first6" => "445596",
                                "account_last4" => "8918",
                            ),
                            "refunds" => array(),
                            "settlement_info" => array(
                                array(
                                    "operation_type" => "004010",
                                    "amount" => 9,
                                    "currency" => "CLP",
                                    "description" =>
                                        "Pago con Tarjeta de crédito sin cuotas CMR",
                                    "installments_number" => 1,
                                    "deferred" => 0,
                                ),
                            ),
                        ),
                        "fraudAssessment" => array(
                            "engine" => "Cybersource",
                            "status" => "ACCEPTED",
                            "metadata" => array(
                                "clientReferenceInformation" => array(
                                    "code" => "wc_118_20220901053122000000"
                                ),
                                "consumerAuthenticationInformation" => array(
                                    "token" => "AxjjbwSTZuBlBa9nvZGzADJPN96AxHCYCWRhwyaSZejFhnxWAUAAXiRK"
                                ),
                                "id" => "6620103714676081004979",
                                "paymentInformation" => array(
                                    "scheme" => "VISA CREDIT",
                                    "bin" => "444444",
                                    "accountType" => "Visa Gold",
                                    "issuer" => "CREDIT AGRICOLE BANK POLSKA S.A.",
                                    "binCountry" => "PL"
                                ),
                            )
                        ),
                        "voucher" => array(
                            "                                        ",
                            "                 WALLET                 ",
                            "               woocommerce              ",
                            "                                        ",
                            "                                        ",
                            " FECHA  : 24/08/2022  HORA  : 01:20     ",
                            " TIENDA : 1           TERM  : 1         ",
                            " Pago con Tarjeta de credito sin cuotas ",
                            "                                        ",
                            " CODIGO AUTORIZACION:  39173134         ",
                            " NUMERO UNICO   :  6305b48f74cd94002eea ",
                            "                                        ",
                            " MONTO OPERACION:  $                  9 ",
                            " NRO CUOTA:                           1 ",
                            "                                        ",
                            " ACEPTO PAGAR SEGUN CONTRATO CON EMISOR ",
                            "    COMPROBANTE NO VALIDO COMO BOLETA   ",
                            "                                        ",
                        ),
                    ),
                    "id" => "6305b48f74cd94002eea6689",
                )
            );
    };
});