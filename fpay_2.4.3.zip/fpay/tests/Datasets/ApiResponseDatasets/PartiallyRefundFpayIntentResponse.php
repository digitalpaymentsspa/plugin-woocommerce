<?php


dataset('partially_refund_fpay_intent_response', function () {
    yield function () {
        return
            array(
                'http_code' => 200,
                'body' => array(
                    "redirect_urls" => array(
                        "return_url" =>
                            "http://example.com?wc-api=fpay_payment_success&uuid=" . UUID,
                        "cancel_url" =>
                            "http://example.com?wc-api=fpay_payment_not_success&uuid=" . UUID,
                    ),
                    "intent" => "sale",
                    "state" => "partially_refunded",
                    "_id" => "63084004cadb56394d4282b8",
                    "payment_method" => "WALLET_QR",
                    "pst_origen" => "woocommerce",
                    "buyer" => array(
                        "logged_in" => true,
                        "email" => "ext_andfevegan@falabella.cl",
                        "phone" => "3012017499",
                        "full_name" => "Andres Vega",
                    ),
                    "transaction" => array(
                        "purchase_order" => "366",
                        "invoice_type" => "BOLETA",
                        "fpay_calculate_tax_subtotal" => false,
                        "promotions" => array(),
                        "deferred_capture" => false,
                        "shipping_method" => "DIGITAL",
                        "merchant_unique_id" => "wc_366_20220826033739000000",
                        "description" => "Compra woocommerce",
                        "soft_descriptor" => "WOOCOMMERCE_2.1.1",
                        "merchant_fantasy_name" => "woocommerce",
                        "reconciliation_id" => "63084004cadb56394d4282b8",
                        "terminal_id" => "1",
                        "store_id" => "1",
                        "channel" => "WEB",
                        "on_behalf_of" => "366",
                        "invoice_number" => "366",
                        "item_list" => array(
                            "items" => array(
                                array(
                                    "sku" => "17",
                                    "name" => "leche la vaca lola",
                                    "description" => "leche la vaca lola",
                                    "quantity" => 2,
                                    "price" => 18,
                                    "tax" => 0,
                                    "category" => "line_item",
                                ),
                            ),
                            "shipping_method" => "DIGITAL",
                            "shipping_address" => array(
                                "address_type" => "HOME_OR_WORK",
                                "line1" => "cra 17 55 n 45 ",
                                "city" => "Santiago",
                                "country_code" => "CL",
                                "phone" => "3012017499",
                                "recipient_name" => "Andres Vega",
                            ),
                        ),
                        "amount" => array(
                            "installments_number" => 1,
                            "deferred_months_number" => 0,
                            "currency" => "CLP",
                            "total" => 18,
                            "details" => array(
                                "subtotal" => 18,
                                "tax" => 0,
                                "shipping" => 0,
                                "shipping_discount" => 0,
                            ),
                        ),
                        "aggregation_code" => "CL-637860",
                    ),
                    "application" => "62752e822b604e003e4fb42f",
                    "invoice_number" => "IP-16614850600860481",
                    "create_time" => "2022-08-26T03:37:40.086Z",
                    "update_time" => "2022-08-26T03:46:25.542Z",
                    "links" => array(
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/63084004cadb56394d4282b8",
                            "rel" => "self",
                            "security" => array("ApiKey"),
                            "method" => "GET",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/63084004cadb56394d4282b8/pay",
                            "rel" => "approval_url",
                            "method" => "REDIRECT",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/63084004cadb56394d4282b8/edit",
                            "rel" => "update_url",
                            "method" => "PUT",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/wc_366_20220826033739000000/merchant-unique-id",
                            "rel" => "self_by_merchant_unique_id",
                            "security" => array("ApiKey"),
                            "method" => "GET",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/63084004cadb56394d4282b8/pay",
                            "rel" => "approval_url_void",
                            "method" => "PUT",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/63084004cadb56394d4282b8/refund",
                            "rel" => "refund_method",
                            "security" => array("Jwt"),
                            "method" => "POST",
                        ),
                        array(
                            "href" =>
                                "https://payments-psp-qa.fpayapp.com/checkout/payments/gateways/wallet/qr/63084004cadb56394d4282b8/refund",
                            "rel" => "refund_void",
                            "security" => array("Jwt"),
                            "method" => "PUT",
                        ),
                    ),
                    "expiration_date" => "2022-08-26T03:47:44.802Z",
                    "fpay_merchant_id" => "PP62752e822b604e003e4fb42f",
                    "long_transaction_code" => "2022082697769097",
                    "mutated" => true,
                    "short_transaction_code" => "97769097",
                    "ui_mode" => "001",
                    "payer" => array(
                        "country" => "CL",
                        "document_type" => "RUT",
                        "document_number" => "144425189",
                    ),
                    "payment_type" => "WALLET",
                    "qr_type" => "DYNAMIC",
                    "gateway" => array(
                        "refunds" => array(
                            array(
                                "refunded_amount" => 1,
                                "refund_merchant_unique_id" => "212",
                                "payer_acccount_id" => 102308736,
                                "tracking_id" => "PSPCL-386750-212",
                                "authorization_ids" => array(
                                    "credit" => 39270940,
                                    "debit" => 39270939,
                                ),
                                "metadata" => array(
                                    "payment_method" => "CREDIT",
                                    "response_code" => "00",
                                    "response_description" => "Transacción correcta",
                                    "transaction" => array(
                                        "acquirer" => "CMR_CL",
                                        "acquirer_unique_id" => "223723415080",
                                        "authorization_code" => "168817987281",
                                        "installments" => array(
                                            "deferred_months" => 0,
                                            "number" => 1,
                                        ),
                                        "transaction_datetime" => "2022-08-26T03:46:23Z",
                                        "unique_id" => "PSPCL-386750-212",
                                    ),
                                    "transaction_type" => "REFUND",
                                    "operation_type" => "004011",
                                    "operation_type_description" =>
                                        "Cancel pago con Tarjeta de crédito sin cuotas CMR",
                                ),
                            ),
                            array(
                                "refunded_amount" => 1,
                                "refund_merchant_unique_id" => "21",
                                "payer_acccount_id" => 102308736,
                                "tracking_id" => "PSPCL-386750-21",
                                "authorization_ids" => array(
                                    "credit" => 39270938,
                                    "debit" => 39270937,
                                ),
                                "metadata" => array(
                                    "payment_method" => "CREDIT",
                                    "response_code" => "00",
                                    "response_description" => "Transacción correcta",
                                    "transaction" => array(
                                        "acquirer" => "CMR_CL",
                                        "acquirer_unique_id" => "223723305110",
                                        "authorization_code" => "168817987280",
                                        "installments" => array(
                                            "deferred_months" => 0,
                                            "number" => 1,
                                        ),
                                        "transaction_datetime" => "2022-08-26T03:46:17Z",
                                        "unique_id" => "PSPCL-386750-21",
                                    ),
                                    "transaction_type" => "REFUND",
                                    "operation_type" => "004011",
                                    "operation_type_description" =>
                                        "Cancel pago con Tarjeta de crédito sin cuotas CMR",
                                ),
                            ),
                        ),
                        "voids" => array(),
                        "resume" => array(
                            "response" => array("code" => 0),
                            "transaction" => array(
                                "installments_info" => array(
                                    "installments_number" => "1",
                                    "deferred" => "0",
                                ),
                                "gateway_id" => "63084004cadb56394d4282b8",
                                "selected_payment_method" => "WALLET",
                                "currency" => "CLP",
                                "purchase_order" => "366",
                                "amount" => 18,
                                "date" => "2022-08-26T03:43:42.394Z",
                            ),
                            "authorizations" => array("code" => "39270936"),
                            "account_number" => array(
                                "account_first6" => "445596",
                                "account_last4" => "8918",
                            ),
                            "refunds" => array(
                                array(
                                    "authorization_code" => 39270939,
                                    "refund_merchant_unique_id" => "212",
                                    "refunded_amount" => 1,
                                    "operation_type" => "004011",
                                    "description" =>
                                        "Cancel pago con Tarjeta de crédito sin cuotas CMR",
                                    "state" => "applied",
                                ),
                                array(
                                    "authorization_code" => 39270937,
                                    "refund_merchant_unique_id" => "21",
                                    "refunded_amount" => 1,
                                    "operation_type" => "004011",
                                    "description" =>
                                        "Cancel pago con Tarjeta de crédito sin cuotas CMR",
                                    "state" => "applied",
                                ),
                            ),
                            "settlement_info" => array(
                                array(
                                    "operation_type" => "004010",
                                    "amount" => 18,
                                    "currency" => "CLP",
                                    "description" =>
                                        "Pago con Tarjeta de crédito sin cuotas CMR",
                                    "installments_number" => 1,
                                    "deferred" => 0,
                                ),
                            ),
                        ),
                        "fraudAssessment" => array(
                            "engine" => "Cybersource",
                            "status" => "ACCEPTED",
                            "metadata" => array(
                                "clientReferenceInformation" => array(
                                    "code" => "wc_118_20220901053122000000"
                                ),
                                "consumerAuthenticationInformation" => array(
                                    "token" => "AxjjbwSTZuBlBa9nvZGzADJPN96AxHCYCWRhwyaSZejFhnxWAUAAXiRK"
                                ),
                                "id" => "6620103714676081004979",
                                "paymentInformation" => array(
                                    "scheme" => "VISA CREDIT",
                                    "bin" => "444444",
                                    "accountType" => "Visa Gold",
                                    "issuer" => "CREDIT AGRICOLE BANK POLSKA S.A.",
                                    "binCountry" => "PL"
                                ),
                            )
                        ),
                        "voucher" => array(
                            "                                        ",
                            "                 WALLET                 ",
                            "               woocommerce              ",
                            "                                        ",
                            "                                        ",
                            " FECHA  : 25/08/2022  HORA  : 23:43     ",
                            " TIENDA : 1           TERM  : 1         ",
                            " Pago con Tarjeta de credito sin cuotas ",
                            "                                        ",
                            " CODIGO AUTORIZACION:  39270936         ",
                            " NUMERO UNICO   :  63084004cadb56394d42 ",
                            "                                        ",
                            " MONTO OPERACION:  $                 18 ",
                            " NRO CUOTA:                           1 ",
                            "                                        ",
                            " ACEPTO PAGAR SEGUN CONTRATO CON EMISOR ",
                            "    COMPROBANTE NO VALIDO COMO BOLETA   ",
                            "                                        ",
                        ),
                    ),
                    "id" => "63084004cadb56394d4282b8",
                )
            );
    };
});