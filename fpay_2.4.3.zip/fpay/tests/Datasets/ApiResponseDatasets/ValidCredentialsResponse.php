<?php

dataset('valid_credentials_data', function () {
    yield function () {
        return [
            'http_code' => 200,
            'body' => [
                "scope" => "",
                "token_type" => "Bearer",
                "access_token" =>
                    "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJwcmltYXJ5c2lkIjoiNjI3NTJlODIyYjYwNGUwMDNlNGZiNDJmIiwidW5pcXVlX25hbWUiOiJPbnRoZW0gQ29tZXJjaW8gMDEiLCJncm91cHNpZCI6IkFQUEwiLCJpc3MiOiJGYWxhYmVsbGEiLCJhdWQiOiJXZWIiLCJ0eXBlIjoiQmVhcmVyIiwic2NvcGUiOltdLCJpYXQiOjE2NjE4MDE5MDEsImV4cCI6MTY2MTgwMjUwMX0.aI-E5cNXLJbhcfzWDWyYKuky9BdEEZDP7ajv7db6k3UtpmxwP1CMk8WGJvpJymOLiJUhFzsE_VdIvEhEE6rKkBmuY9mOREfLsiAbKIaNqVdi7HJg4pF4fRJpXfP7CbsqBYd5p9sIYwJU_yISI8B-QNUm2lF6v2V7cx_OJV2M0s24SET8XcoQsHEFhGRzzzmjk9mLoC8iRsERmSOV5ONYkMTeLSB0Ayv9WhZWq5bkSaJtJq464EtW3LI9RLkPw19r7nPKy2fQvDnJrX5dJ7UJ2QUmnR63k-xr25-nMRG11kk9JiJBPYTW-hFIHuuDQpIH7omNUdS-DcoDK1l705wm9A",
                "expires_in" => 1661802501,
            ],
            'headers' => []
        ];
    };
});