<?php

dataset('invalid_self_response', function () {
    yield function () {
        return [
            'http_code' => 400,
            'body' => [
                'error_code' => 'DATABASE_ERROR_FIND',
                'error_description' => 'Error to try obtain document',
                'meta_data' => [
                    'error' => [
                        'stringValue' => '"6308d7adcadb56394d4292202"',
                        'valueType' => 'string',
                        'kind' => 'ObjectId',
                        'value' => '6308d7adcadb56394d4292202',
                        'path' => '_id',
                        'reason' => [
                        ],
                        'name' => 'CastError',
                        'message' => 'Cast to ObjectId failed for value "6308d7adcadb56394d4292202" (type string) at path "_id" for model "intention"',
                    ],
                    'payment_id' => '6308d7adcadb56394d4292202',
                ],
            ],
            'headers' => []
        ];
    };
});
