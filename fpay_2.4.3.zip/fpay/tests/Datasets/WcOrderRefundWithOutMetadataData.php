<?php

dataset('wc_order_refund_without_metadata_data', function () {
    yield function () {
        return [
            "id" => 367,
            "parent_id" => 366,
            "status" => "completed",
            "currency" => "COP",
            "version" => "6.4.1",
            "prices_include_tax" => false,
            "date_created" => [
                "date" => "2022-08-26 06:00:13.000000",
                "timezone_type" => 1,
                "timezone" => "+00:00",
            ],
            "date_modified" => [
                "date" => "2022-08-26 06:00:13.000000",
                "timezone_type" => 1,
                "timezone" => "+00:00",
            ],
            "discount_total" => "0",
            "discount_tax" => "0",
            "shipping_total" => "0",
            "shipping_tax" => "0",
            "cart_tax" => "0",
            "total" => "-1",
            "total_tax" => "0",
            "amount" => "1",
            "reason" => "",
            "refunded_by" => 1,
            "refunded_payment" => false,
            "meta_data" => [],
            "line_items" => [],
            "tax_lines" => [],
            "shipping_lines" => [],
            "fee_lines" => [],
            "coupon_lines" => [],
        ];
    };
});