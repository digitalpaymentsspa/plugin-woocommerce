<?php

dataset('data_for_create_wc_order', [
    'fpay_intent_data' => [
        [
            "id" => "62f570753e2d84003b9fb932",
            "subtotal" => 50,
            "total" => 50,
            "shipping" => 0,
            "billing_address_1" => "José Miguel Carrera 130",
            "billing_address_2" => "La Florida, Chile",
            "billing_city" => "Santiago",
            "phone" => "3103-3565",
            "billing_first_name" => "Andres",
            "billing_last_name" => "Vega",
            "items" => [
                [
                    "sku" => 118,
                    "order_id" => 360,
                    "name" => "leche la vaca lola",
                    "description" => "Que leche tan muuu",
                    "product_id" => 17,
                    "variation_id" => 0,
                    "quantity" => 5,
                    "tax_class" => "",
                    "subtotal" => "10",
                    "subtotal_tax" => "0",
                    "tax" => 0,
                    "total" => "10",
                    "total_tax" => "0",
                    "taxes" => ["total" => [], "subtotal" => []],
                    "meta_data" => [],
                ]
            ],
            "buyer" => [
                "logged_in" => true,
                "email" => "marcos@forsend.cl",
                "phone" => "3103-3565",
                "first_name" => "Andres",
                "last_name" => "Vega",
            ],
            "transaction" => [
                "purchase_order" => "159238",
            ],
        ]
    ]
]);