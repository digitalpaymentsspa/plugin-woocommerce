<?php

namespace Fpay\Woocommerce\Services;

use Exception;
use Fpay\Woocommerce\Services\Contracts\FpayAuth;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\BadResponseException;
use Monolog\Logger;
use Fpay\Woocommerce\Exceptions\Contracts\FpayAuthException;
use GuzzleHttp\Psr7\Message;
use stdClass;

defined('ABSPATH') || exit;

class FpayAuthImpl implements FpayAuth
{
    private $bearer_token;
    private $http_client;
    private $base_url;
    private $auth_url;
    private $logger;
    private $container;

    /**
     * @param Client $http_client
     * @param string $base_url
     * @param string $auth_url
     * @param Logger $logger
     * @param $container
     */
    public function __construct(
        Client $http_client,
        string $base_url,
        string $auth_url,
        Logger $logger,
               $container
    )
    {
        $this->http_client = $http_client;
        $this->base_url = $base_url;
        $this->auth_url = $auth_url;
        $this->logger = $logger;
        $this->container = $container;

    }

    /**
     * @throws \GuzzleHttp\Exception\GuzzleException
     * @throws FpayAuthException
     */
    public function authInServer(string $public_key, string $private_key): void
    {
        $options = [
            'headers' => array(
                'Authorization' => 'Basic ' . $public_key . ':' . $private_key,
                'Content-Type' => 'application/json',
            ),
            'body' => '{"grant_type" : "client_credentials"}'
        ];

        try {
            $request = $this->http_client->request('POST', $this->base_url . $this->auth_url, $options);
            $response = json_decode($request->getBody()->getContents());
        } catch (BadResponseException $exception) {
            $fpay_auth_exception = $this->container->make(FpayAuthException::class, [
                'logger' => $this->logger,
                'error_data' => Message::toString($exception->getResponse()),
                'message' => 'Bad response client exception.',
            ]);
            $fpay_auth_exception->sendMessage();
            throw $fpay_auth_exception;

        }
        $this->setBearerToken($response->access_token);
    }

    public function setBearerToken($access_token): void
    {
        $this->bearer_token = $access_token;
    }

    public function getBearerToken(): string
    {
        return $this->bearer_token;
    }
}
