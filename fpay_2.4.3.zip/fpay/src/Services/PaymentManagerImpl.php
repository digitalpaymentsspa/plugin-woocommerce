<?php

namespace Fpay\Woocommerce\Services;

use Fpay\Woocommerce\Services\Contracts\FpayAuth;
use Fpay\Woocommerce\Services\Contracts\FpayIntentManager;
use Fpay\Woocommerce\Services\Contracts\PaymentManager;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use GuzzleHttp\Client;
use Monolog\Logger;

defined('ABSPATH') || exit;

class PaymentManagerImpl implements PaymentManager
{

    private array $settings;
    private Logger $logger;
    private FpayAuth $fpay_auth;
    private Client $client;
    private FpayWoocommerceFactory $factory;
    private FpayIntentManager $fpay_intent_manager;
    private array $plugin_config;


    /**
     * @param FpayAuth $fpay_auth
     * @param $settings
     * @param $logger
     * @param $client
     * @param $factory
     * @param FpayIntentManager $fpay_intent_manager
     */
    public function __construct(
        FpayAuth          $fpay_auth,
                          $settings,
                          $logger,
                          $client,
                          $factory,
        FpayIntentManager $fpay_intent_manager,
        array             $plugin_config
    )
    {
        $this->settings = $settings;
        $this->logger = $logger;
        $this->fpay_auth = $fpay_auth;
        $this->client = $client;
        $this->factory = $factory;
        $this->fpay_intent_manager = $fpay_intent_manager;
        $this->plugin_config = $plugin_config;
    }

    public function loadCredentials(): string
    {
        $this->fpay_auth->authInServer(
            $this->settings['public_key'],
            $this->settings['private_key']

        );
        return $this->fpay_auth->getBearerToken();
    }

    public function processPayment($order, $home_url, $uuid): AbstractFpayIntent
    {
        $bearer_token = $this->loadCredentials();

        $fpay_intent = $this->factory->createFpayIntent($order);
        $redirect_urls = $this->createRedirectUrls($home_url, $uuid);
        $fpay_intent->setRedirectUrls($redirect_urls);

        return $this->fpay_intent_manager->createFpayIntentInServer(
            $bearer_token,
            $fpay_intent
        );

    }

    public function createRedirectUrls($home_url, $uuid): array
    {
        $payment_success_url = $home_url . "?wc-api=" . $this->plugin_config['success_api_name'] . "&uuid=" . $uuid;
        $payment_error_url = $home_url . "?wc-api=" . $this->plugin_config['not_success_api_name']  . "&uuid=" . $uuid;
        return array("return_url" => $payment_success_url, "cancel_url" => $payment_error_url);
    }

    public function reverseIntent($bearer_token, $order_id): void
    {
        //TODO: Implement this in the next versions
    }
}