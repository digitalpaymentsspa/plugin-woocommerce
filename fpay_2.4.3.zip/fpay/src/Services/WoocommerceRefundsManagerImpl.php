<?php

namespace Fpay\Woocommerce\Services;

use DI\Container;
use Fpay\Woocommerce\Exceptions\Contracts\FpayLastRefundNotFoundException;
use Fpay\Woocommerce\Exceptions\FpayLastRefundNotFoundExceptionImpl;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\FpayGatewayImpl2;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use Monolog\Logger;
use function Fpay\Woocommerce\Config\config;

class WoocommerceRefundsManagerImpl implements WoocommerceRefundsManager
{
    private Logger $logger;
    private Container $container;
    private FpayWoocommerceFactory $woocommerce_factory;

    public function __construct(Logger $logger, Container $container, FpayWoocommerceFactory $woocommerce_factory)
    {
        $this->logger = $logger;
        $this->container = $container;
        $this->woocommerce_factory = $woocommerce_factory;
    }

    public function filterRefundsViaFpay(array $refunds, string $fpay_intent_id): array
    {
        $refunds_from_fpay = array();
        $this->logger->info('WoocommerceRefundsManagerImpl@filterRefundsViaFpay', [
            'refunds_quantity' => count($refunds),
            'refunds' => $refunds
        ]);
        foreach ($refunds as $refund) {

            if (empty($refund->get_meta_data())) {
                continue;
            }

            $meta_data_decoded = json_decode(json_encode($refund->get_meta_data()));

            $fpay_meta_data = $this->getFpayMetaData($meta_data_decoded);

            if (!property_exists($fpay_meta_data, 'fpay_intent_id')) {
                continue;
            }

            array_push(
                $refunds_from_fpay,
                $this->woocommerce_factory->createRefund($fpay_meta_data, $fpay_intent_id)
            );
        }
        $this->logger->info('WoocommerceRefundsManagerImpl@filterRefundsViaFpay', [
            'refunds_from_fpay_quantity' => count($refunds_from_fpay),
            'refunds_from_fpay' => $refunds_from_fpay
        ]);

        return $refunds_from_fpay;
    }

    public function getFpayMetaData($meta_data_decoded): \stdClass
    {
        $meta_data_key = config('meta_data_key');
        foreach ($meta_data_decoded as $meta_data_item) {
            if ($meta_data_item->key === $meta_data_key) {
                $this->logger->info(get_class($meta_data_item->value));
                return $meta_data_item->value;
            }
        }
    }

    /**
     * @throws \DI\DependencyException
     * @throws FpayLastRefundNotFoundException
     * @throws \DI\NotFoundException
     */
    public function getLastRefund(array $order_refunds)
    {

        $order_refund = null;
        foreach ($order_refunds as $order_refund) {
            if (empty($order_refund->get_meta_data())) {
                $this->logger->info('FpayGateway@getLastRefund', [
                    'last_order_refund_id' => $order_refund->get_id(),
                    'last_order_refund' => $order_refund
                ]);
                return $order_refund;
            }
        }

        if ($order_refund === null) {
            $exception = $this->container->make(FpayLastRefundNotFoundException::class, [
                'logger' => $this->logger,
                'error_data' => json_encode([
                    'order_refunds' => $order_refunds,
                ])
            ]);

            $exception->sendMessage();
            throw $exception;
        }
    }

    public function addMetaDataToRefund($last_refund_woocommerce, AbstractRefund $last_refund_fpay)
    {
        $meta_data = [
            'payment_method' => config('plugin_id'),
            'fpay_intent_id' => $last_refund_fpay->getFpayIntentionId(),
            'refunded_amount' => $last_refund_fpay->getRefundedAmount(),
            'refund_merchant_unique_id' => $last_refund_fpay->getMerchantUniqueId(),
            'authorization_id' => $last_refund_fpay->getAuthorizationId(),
            'state' => $last_refund_fpay->getState()
        ];

        $this->logger->info('FpayGateway@addMetaDataToRefund', [
            'meta_data' => $meta_data,
        ]);

        add_post_meta(
            $last_refund_woocommerce->get_id(),
            config('meta_data_key'),
            $meta_data
        );

        $last_refund_woocommerce->save();

    }

}