<?php

namespace Fpay\Woocommerce\Services\Contracts;

use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;

interface RefundManager
{
    const REPLACE_URL_PATTERN = '{{intention-id}}';

    /**
     * @param AbstractRefund $refund
     * @param string $reason
     * @return AbstractFpayIntent
     */
    public function processRefund(AbstractRefund $refund, $reason = ''): AbstractFpayIntent;

    /**
     * @param AbstractRefund $refund
     * @param string $reason
     * @return AbstractFpayIntent
     */
    public function makePartialRefundInServer(AbstractRefund $refund, $reason = ''): AbstractFpayIntent;

    /**
     * @param AbstractFpayIntent $fpay_intent
     * @param string $reason
     * @return bool
     */
    public function processRefundViaWebhook(
        AbstractFpayIntent $fpay_intent,
        array              $order_refunds_from_fpay,
                           $total_refunded,
                           $total_order_value
    ): array;

    /**
     * @return string
     */
    public function loadCredentials(): string;


    /**
     * @param array $fpay_refunds
     * @param $order_refunds
     * @return array
     */
    public function getPendingRefundsToApplyInWoocommerce(array $fpay_refunds, array $order_refunds): array;


    /**
     * @param array $refunds
     * @return float
     */
    public function getTotalToRefund(array $refunds): float;

    /**
     * @param $refund_a
     * @param $refund_b
     * @return int
     */
    public function filter_pending($refund_a, $refund_b): int;
}
