<?php

namespace Fpay\Woocommerce\Services\Contracts;

interface WoocommerceRefundsManager
{
    /**
     * @param array $refunds
     * @param $fpay_intent_id
     * @return array
     */
    public function filterRefundsViaFpay(array $refunds,string $fpay_intent_id): array;

    public function getFpayMetaData($meta_data_decoded): \stdClass;

    public function getLastRefund(array $order_refunds);

}