<?php

namespace Fpay\Woocommerce\Services\Contracts;

use Fpay\Woocommerce\Exceptions\Contracts\FpayInconsistentDataException;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;

interface Webhook
{

    /**
     * @param $order
     * @param $self_link
     */
    public function processFpayIntent($order, $self_link): void;

    /**
     * @param $fpay_intent_id
     * @param $plugin_id_related_to_order
     * @param $current_plugin_id
     * @throws FpayInconsistentDataException
     */
    public function checkIfBelongsToPaymentGateway($fpay_intent_id, $plugin_id_related_to_order, $current_plugin_id):void;

    /**
     * @param $order_id
     * @param $fpay_intent
     * @param $strategy
     * @param $data
     */
    public function processFpayIntentSuccess($order_id, $fpay_intent, $strategy, $data): void;

    /**
     * @param $order
     * @param $fpay_intent
     * @param $strategy
     * @param $data
     */
    public function processOthersStatesOfFpayIntent($order, $fpay_intent, $strategy, $data): void;

    /**
     * @param $order
     * @param AbstractRefund $refund
     * @param $strategy
     * @param $data
     */
    public function makeRefundViaStrategy($order, AbstractRefund $refund, $strategy, $data): void;

    /**
     * @param $order
     * @param $fpay_intent
     * @param $strategy
     * @param $data
     */
    public function processRefunds($order, $fpay_intent, $strategy, $data): void;

    /**
     * @return FpayOrderContext
     */
    public function getFpayOrderContext(): FpayOrderContext;

}