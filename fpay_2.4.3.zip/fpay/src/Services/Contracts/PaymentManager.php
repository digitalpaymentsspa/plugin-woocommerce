<?php

namespace Fpay\Woocommerce\Services\Contracts;

use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;

interface PaymentManager
{
    /**
     * @param $order
     * @param $home_url
     * @param $uuid
     * @return AbstractFpayIntent
     */
    public function processPayment($order, $home_url, $uuid): AbstractFpayIntent;

    /**
     * @param $bearer_token
     * @param $order_id
     */
    public function reverseIntent($bearer_token, $order_id): void;

    /**
     * @param $home_url
     * @param $uuid
     * @return array
     */
    public function createRedirectUrls($home_url, $uuid): array;
}
