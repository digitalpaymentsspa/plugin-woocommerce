<?php

namespace Fpay\Woocommerce\Services\Contracts;

use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\FpayIntent;

interface FpayIntentManager
{
    /**
     * @param string $bearer_token
     * @param AbstractFpayIntent $fpay_intent
     * @return AbstractFpayIntent
     */
    public function createFpayIntentInServer(string $bearer_token, AbstractFpayIntent $fpay_intent): AbstractFpayIntent;

    /**
     * @param string $bearer_token
     * @param string $self_url
     * @return AbstractFpayIntent
     */
    public function getFpayIntentFromSelfUrl(string $bearer_token, string $self_url): AbstractFpayIntent;

    /**
     * @param string $bearer_token
     * @param string $fpay_intent_id
     * @return AbstractFpayIntent
     */
    public function getFpayIntentFromId(string $bearer_token, string $fpay_intent_id): AbstractFpayIntent;
}