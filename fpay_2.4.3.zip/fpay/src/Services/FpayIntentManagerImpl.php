<?php

namespace Fpay\Woocommerce\Services;

use Fpay\Woocommerce\Exceptions\Contracts\FpaySelfException;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Services\Contracts\FpayIntentManager;
use Fpay\Woocommerce\Exceptions\Contracts\FpayCreateIntentException;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\BadResponseException;
use Monolog\Logger;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use GuzzleHttp\Psr7\Message;

defined('ABSPATH') || exit;

class FpayIntentManagerImpl implements FpayIntentManager
{

    private $http_client;
    private $base_url;
    private $create_fpay_intent_url;
    private $logger;
    private $container;
    private $fpay_factory;
    private $self_url;

    /**
     * @param Client $http_client
     * @param string $base_url
     * @param string $create_fpay_intent_url
     * @param Logger $logger
     * @param $container
     * @param FpayFactory $fpay_factory
     * @param string $self_url
     */
    public function __construct(
        Client      $http_client,
        string      $base_url,
        string      $create_fpay_intent_url,
        Logger      $logger,
                    $container,
        FpayFactory $fpay_factory,
        string      $self_url
    )
    {
        $this->http_client = $http_client;
        $this->base_url = $base_url;
        $this->create_fpay_intent_url = $create_fpay_intent_url;
        $this->logger = $logger;
        $this->container = $container;
        $this->fpay_factory = $fpay_factory;
        $this->self_url = $self_url;

    }

    public function createFpayIntentInServer(string $bearer_token, AbstractFpayIntent $fpay_intent): AbstractFpayIntent
    {

        try {
            $options = [
                'headers' => array(
                    'Authorization' => 'Bearer' . ' ' . $bearer_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => $fpay_intent->jsonEncodeFromCreateInServer(),
            ];

            $request = $this->http_client->request(
                'POST',
                $this->base_url . $this->create_fpay_intent_url,
                $options
            );

            $response = json_decode($request->getBody()->getContents());

        } catch (BadResponseException $exception) {
            $fpay_create_intent_exception = $this->container->make(FpayCreateIntentException::class, [
                'logger' => $this->logger,
                'error_data' => Message::toString($exception->getResponse()),
                'message' => 'Bad response client exception.'
            ]);
            $fpay_create_intent_exception->sendMessage();
            throw $fpay_create_intent_exception;
        }

        return $this->fpay_factory->createFpayIntent($response);
    }

    public function getFpayIntentFromId(string $bearer_token, string $fpay_intent_id): AbstractFpayIntent
    {
        $self_url = $this->base_url . $this->self_url . $fpay_intent_id;

        $this->logger->info('FpayIntentManager@getFpayIntentFromId',
            [
                'self_url' => $self_url,
                'fpay_intent_id' => $fpay_intent_id
            ]);
        return $this->getFpayIntentFromSelfUrl($bearer_token, $self_url);
    }

    public function getFpayIntentFromSelfUrl(string $bearer_token, string $self_url): AbstractFpayIntent
    {
        try {
            $options = [
                'headers' => array(
                    'Authorization' => 'Bearer' . ' ' . $bearer_token,
                    'Content-Type' => 'application/json',
                ),
            ];

            $request = $this->http_client->request(
                'GET',
                $self_url,
                $options
            );

            $response = json_decode($request->getBody()->getContents());

            $this->logger->info('FpayIntentManagerImpl@getFpayIntentFromSelfUrl', [
                'response decode' => $response
            ]);

            $fpay_intent = $this->fpay_factory->createFpayIntent($response);
            $this->logger->info('FpayIntentManagerImpl@getFpayIntentFromSelfUrl', [
                'fpay_intent' => $fpay_intent
            ]);

        } catch (BadResponseException $exception) {

            $fpay_create_intent_exception = $this->container->make(FpaySelfException::class, [
                'logger' => $this->logger,
                'error_data' => Message::toString($exception->getResponse()),
                'message' => 'Bad response client exception.'
            ]);
            $fpay_create_intent_exception->sendMessage();
            throw $fpay_create_intent_exception;

        }

        return $fpay_intent;
    }
}