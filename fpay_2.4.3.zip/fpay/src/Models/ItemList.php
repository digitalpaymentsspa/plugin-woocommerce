<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractItemList;

defined('ABSPATH') || exit;

class ItemList implements AbstractItemList, \JsonSerializable
{
    protected $shipping_method;
    protected $items;
    protected $shipping_address;

    /**
     * @param $shipping_method
     * @param $items
     * @param $shipping_address
     */
    public function __construct($shipping_method, $items, $shipping_address)
    {
        $this->shipping_method = $shipping_method;
        $this->items = $items;
        $this->shipping_address = $shipping_address;
    }


    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

}