<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessment;
use Fpay\Woocommerce\Models\Contracts\AbstractGateway;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;

defined('ABSPATH') || exit;

class Gateway implements AbstractGateway, \JsonSerializable
{

    protected $voucher;
    protected $refunds;
    protected $fraudAssessment;

    /** 
     *
     * @param array $voucher
     * @param AbstractFraudAssessment|null $fraudAssessment
     * @param array $refunds
     */
    public function __construct($voucher, $fraudAssessment, $refunds = array()){
        $this->voucher = $voucher;
        $this->refunds = $refunds;
        $this->fraudAssessment = $fraudAssessment;
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    public function getVoucher():array{
        return $this->voucher;
    }

    public function getRefunds(): array
    {
        return $this->refunds;
    }
    
    public function getPaymentMethod(): string
    {
        return $this->getFraudAssessment()->getFraudAssessmentMetadata()->getPaymentInformation()->getScheme();
    }

    public function getLastRefund(): AbstractRefund
    {
        return $this->refunds[0];
    }

    public function getFraudAssessment()
    {
        return $this->fraudAssessment ?? null;
    }
}