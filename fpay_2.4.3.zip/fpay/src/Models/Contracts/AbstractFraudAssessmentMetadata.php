<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractFraudAssessmentMetadata
{ 
    public function getPaymentInformation(): AbstractPaymentInformation;
}