<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractRefund
{
    public function getFpayIntentionId();

    public function getRefundedAmount();

    public function getMerchantUniqueId();

    public function getAuthorizationId(): string;

    public function jsonEncodeFromCreateInServer(): string;

    public function getState(): string;

}