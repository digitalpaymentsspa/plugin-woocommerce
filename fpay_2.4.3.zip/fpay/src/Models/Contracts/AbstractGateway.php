<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractGateway
{
    public function getVoucher(): array;
    
    public function getPaymentMethod(): string;

    public function getRefunds(): array;

    public function getLastRefund(): AbstractRefund;
    
    /**     
     *
     * @return AbstractFraudAssessment|null
     */
    public function getFraudAssessment();
}