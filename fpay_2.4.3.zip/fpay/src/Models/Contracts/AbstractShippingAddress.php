<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractShippingAddress
{
    const ADDRESS_TYPE = 'HOME_OR_WORK';

}