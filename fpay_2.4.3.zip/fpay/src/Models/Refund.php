<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Traits\UniqueIds;

defined('ABSPATH') || exit;

class Refund implements AbstractRefund, \JsonSerializable
{
    use UniqueIds;

    private $fpay_intention_id;
    private $refunded_amount;
    private $refund_merchant_unique_id;
    private $authorization_id;
    private $state;

    /**
     * @param $fpay_intention_id
     * @param $refunded_amount
     * @param $refund_merchant_unique_id
     */
    public function __construct(
        $fpay_intention_id,
        $refunded_amount,
        $refund_merchant_unique_id,
        $authorization_id = '',
        $state = ''
    )
    {
        $this->fpay_intention_id = $fpay_intention_id;
        $this->refunded_amount = intval($refunded_amount);
        $this->refund_merchant_unique_id = $this->buildMerchantUniqueId($refund_merchant_unique_id);
        $this->authorization_id = $authorization_id;
        $this->state = $state;
    }

    public function getFpayIntentionId()
    {
        return $this->fpay_intention_id;
    }

    public function getRefundedAmount()
    {
        return $this->refunded_amount;
    }

    public function getMerchantUniqueId()
    {
        return $this->refund_merchant_unique_id;
    }

    public function getAuthorizationId(): string
    {
        return $this->authorization_id;
    }

    public function jsonSerialize(): array
    {
        return get_object_vars($this);
    }

    public function jsonEncodeFromCreateInServer(): string
    {
        return json_encode([
            'refunded_amount' => $this->refunded_amount,
            'refund_merchant_unique_id' => $this->refund_merchant_unique_id,
        ]);
    }

    public function getState(): string
    {
        return $this->state;
    }
}