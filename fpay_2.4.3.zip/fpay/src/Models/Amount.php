<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractAmount;

defined('ABSPATH') || exit;

class Amount implements AbstractAmount, \JsonSerializable
{

    private $currency;
    private $total;
    private $details;

    /**
     * @param $currency
     * @param $total
     * @param $details
     */
    public function __construct($currency, $total, $details)
    {
        $this->currency = $currency;
        $this->total = $total;
        $this->details = $details;
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}