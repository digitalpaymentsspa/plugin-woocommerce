<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessment;
use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessmentMetadata;

defined('ABSPATH') || exit;

class FraudAssessment implements AbstractFraudAssessment, \JsonSerializable
{
    protected $engine;
    protected $status;
    protected $fraudAssessmentMetadata;

    public function __construct(string $engine, string $status, AbstractFraudAssessmentMetadata $fraudAssessmentMetadata){
        $this->fraudAssessmentMetadata = $fraudAssessmentMetadata;    
        $this->engine = $engine;    
        $this->status = $status;    
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    public function getFraudAssessmentMetadata(): AbstractFraudAssessmentMetadata
    {
        return $this->fraudAssessmentMetadata;
    }
}