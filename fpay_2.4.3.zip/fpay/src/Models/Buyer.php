<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractBuyer;

defined('ABSPATH') || exit;

class Buyer implements AbstractBuyer, \JsonSerializable
{
    protected $logged_in;
    protected $email;
    protected $phone;
    protected $full_name;

    /**
     * @param $logged_in
     * @param $email
     * @param $phone
     * @param $full_name
     */
    public function __construct($logged_in, $email, $phone, $full_name){
        $this->logged_in = $logged_in;
        $this->email = $email;
        $this->phone = $phone;
        $this->full_name = $full_name;
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}