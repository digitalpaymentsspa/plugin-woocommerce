<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractOrder;

defined('ABSPATH') || exit;

class Order implements AbstractOrder
{

}