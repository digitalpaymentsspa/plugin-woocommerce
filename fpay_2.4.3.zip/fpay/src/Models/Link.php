<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractLink;

defined('ABSPATH') || exit;

class Link implements AbstractLink, \JsonSerializable
{
    private $href;
    private $rel;
    private $security;
    private $method;

    /**
     * @param $href
     * @param $rel
     * @param $method
     */
    public function __construct($href, $rel, $method)
    {
        $this->href = $href;
        $this->rel = $rel;
        $this->method = $method;
        $this->security = [];
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    public function setSecurityArray($security): void
    {
        $this->security = $security;
    }

    public function getRel(): string
    {
        return $this->rel;
    }

    public function getHref(): string
    {
        return $this->href;
    }
}