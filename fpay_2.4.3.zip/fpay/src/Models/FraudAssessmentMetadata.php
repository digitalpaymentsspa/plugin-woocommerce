<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractPaymentInformation;
use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessmentMetadata;

defined('ABSPATH') || exit;

class FraudAssessmentMetadata implements AbstractFraudAssessmentMetadata, \JsonSerializable
{
    protected $paymentInformation;    

    public function __construct(AbstractPaymentInformation $paymentInformation){
        $this->paymentInformation = $paymentInformation;        
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    public function getPaymentInformation(): AbstractPaymentInformation
    {
        return $this->paymentInformation;
    }
}