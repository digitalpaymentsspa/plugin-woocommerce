<?php

namespace Fpay\Woocommerce\Controllers\Contracts;

use Fpay\Woocommerce\Exceptions\Contracts\FpayDataInSessionNotFoundException;

interface WebhookController
{
    /**
     * @return void
     */
    public function registerRoutes(): void;

    /**
     * @throws FpayDataInSessionNotFoundException
     */
    public function paymentWebhook(): void;

    public function fpayPortalWebhooks();

    public function getPostDataFromRequest();

    /**
     * @return string
     */
    public function getUuidFromRequest(): string;


}