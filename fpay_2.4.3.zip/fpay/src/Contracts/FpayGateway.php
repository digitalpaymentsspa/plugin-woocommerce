<?php

namespace Fpay\Woocommerce\Contracts;

use Fpay\Woocommerce\Controllers\Contracts\WebhookController;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;
use Fpay\Woocommerce\Services\Contracts\PaymentManager;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Services\Contracts\Webhook;
use Monolog\Logger;
use DI\Container;

interface FpayGateway
{

    /**
     * @return string
     */
    public function getDeviceType(): string;

    /**
     * @return Container
     */
    public function getContainer(): Container;

    /**
     * @param PaymentManager $payment_manager
     */
    public function setPaymentManager(PaymentManager $payment_manager): void;

    /**
     * @param Webhook $webhook
     */
    public function setWebhook(Webhook $webhook): void;

    /**
     * @return FpayOrderContext
     */
    public function getFpayOrderContext(): FpayOrderContext;

    /**
     * @param RefundManager $refundManager
     */
    public function setRefundManager(RefundManager $refundManager): void;

    /**
     * @param Logger $logger
     */
    public function setLogger(Logger $logger): void;

    /**
     * @param $container
     */
    public function setContainer($container): void;

    /**
     * @param FpayOrderContext $fpay_order_context
     */
    public function setFpayOrderContext(FpayOrderContext $fpay_order_context): void;

    /**
     * @param FpayFactory $fpay_factory
     */
    public function setFpayFactory(FpayFactory $fpay_factory): void;

    /**
     * @param WoocommerceRefundsManager $woocommerce_refunds_manager
     */
    public function setWoocommerceRefundsManager(WoocommerceRefundsManager $woocommerce_refunds_manager): void;

    /**
     * @param array $plugin_config
     */
    public function setPluginConfig(array $plugin_config): void;

    /**
     * @param WebhookController $webhook_controller
     */
    public function setWebhookController(WebhookController $webhook_controller): void;

    /**
     * @param SessionManager $session_manager
     */
    public function setSessionManager(SessionManager $session_manager): void;
}