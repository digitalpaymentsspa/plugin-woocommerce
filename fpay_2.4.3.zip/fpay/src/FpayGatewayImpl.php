<?php

namespace Fpay\Woocommerce;

use DI\Container;
use Fpay\Woocommerce\Contracts\FpayGateway;
use Fpay\Woocommerce\Controllers\Contracts\WebhookController;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Services\Contracts\FpayIntentManager;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;
use Fpay\Woocommerce\Services\Contracts\PaymentManager;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Services\Contracts\Webhook;
use Fpay\Woocommerce\Services\Contracts\FpayAuth;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Monolog\Logger;
use Ramsey\Uuid\Uuid;
use WC_HTTPS;
use function Fpay\Woocommerce\Config\config;
use WC_Payment_Gateway;

defined('ABSPATH') || exit;

class FpayGatewayImpl extends WC_Payment_Gateway implements FpayGateway
{
    const LOGGER_CLASS_NAME = 'Logger';
    const PROD_ENVIRONMENT = 'produccion';
    const QA_ENVIRONMENT = 'pruebas';
    const INT_ENVIRONMENT = 'integracion';

    const UUID_KEY = 'uuid';
    const ORDER_ID_KEY = 'order_id';
    const SELF_LINK_KEY = 'self_link';

    protected PaymentManager $payment_manager;
    protected Container $container;
    protected array $plugin_config = array();
    protected Logger $logger;
    protected Webhook $webhook;
    protected FpayOrderContext $fpay_order_context;
    protected FpayFactory $fpay_factory;
    protected RefundManager $refund_manager;
    protected FpayWoocommerceFactory $woocommerce_factory;
    protected FpayAuth $fpay_auth;
    protected WoocommerceRefundsManager $woocommerce_refunds_manager;
    protected SessionManager $session_manager;
    protected WebhookController $webhook_controller;

    public function __construct()
    {
        $this->container = $this->container ?? require __DIR__ . '/../app/bootstrap.php';
        /**
         * Initialize the woocommerce class methods
         */
        $this->loadConfigValues();
        $this->init_form_fields();
        $this->initPluginSettingsData();

        $this->loadDependencies();
        $this->init_settings();
        $this->initForUserData();

    }

    protected function initPluginSettingsData()
    {
        $this->id = $this->plugin_config['plugin_id'];
        $this->icon = plugin_dir_url(__FILE__) . '../img/logo.png';
        $this->has_fields = false;
        $this->method = "redirect";
        $this->enabled = $this->get_option('enabled');
        $this->method_title = $this->plugin_config['plugin_tittle'];
        $this->title = 'Paga con ';
        $this->method_description = $this->plugin_config['method_description'];

        /**
         * This enabled the products and refunds functionality in the Fpay gateway
         */
        $this->supports = array('products', 'refunds');

        add_action($this->plugin_config['hook_for_config_name'], array($this, 'process_admin_options'));
        /**
         * This register the css
         */
        wp_register_style('fpay_woocommerce_styles', get_site_url() . '/wp-content/plugins/fpay/assets/css/fpay_styles.css');
        wp_enqueue_style('fpay_woocommerce_styles');
    }

    protected function loadConfigValues()
    {
        if(empty($this->plugin_config)){
            $this->plugin_config = config();
        }
    }

    protected function initForUserData()
    {
        if ($this->settings['environment'] === self::PROD_ENVIRONMENT) {
            $this->description = $this->getMessage();
            return;
        }

        $this->description = $this->getMessage() . $this->getNotProductionMessage();

    }

    protected function getMessage(): string
    {
        return "
                <div class='form-row form-row-wide'>
                    <p>" . $this->plugin_config['for_client_description'] . "</p>
                </div>
                <div class='clear'></div>
        ";
    }

    protected function getNotProductionMessage(): string
    {
        return "
                <hr>
                <h2 class='error'> <strong> Atencion !!! </strong></h2>
                <b class='error'> Plugin Id: "  . $this->plugin_config['plugin_id'] . "</b>
                <p>Se encuentra en uno de los ambientes de pruebas. Recuerde actualizar su configuración.</p>
       ";
    }

    protected function loadDependencies()
    {
        $this->logger = $this->container->get(self::LOGGER_CLASS_NAME);

        $this->logger->debug('plugin_config', [
            $this->plugin_config,
        ]);

        $this->fpay_auth = $this->container->make(FpayAuth::class, [
            'client' => $this->container->get('HttpClient'),
            'base_url' => $this->getActiveEnvironmentBaseUrl($this->plugin_config),
            'auth_url' => $this->plugin_config['auth_url'],
            'logger' => $this->logger,
            'container' => $this->container
        ]);

        $this->woocommerce_factory = $this->container->make(FpayWoocommerceFactory::class, [
            'container' => $this->container,
            'plugin_config' => $this->plugin_config,
            'logger' => $this->logger,
            'channel' => $this->getDeviceType()
        ]);

        $this->fpay_factory = $this->container->make(FpayFactory::class, [
            'container' => $this->container,
            'plugin_config' => $this->plugin_config,
            'logger' => $this->logger,
            'channel' => $this->getDeviceType()
        ]);

        $fpay_intent_manager = $this->container->make(FpayIntentManager::class, [
            'client' => $this->container->get('HttpClient'),
            'base_url' => $this->getActiveEnvironmentBaseUrl($this->plugin_config),
            'create_fpay_intent_url' => $this->plugin_config['create_fpay_intent_url'],
            'logger' => $this->logger,
            'container' => $this->container,
            'fpay_factory' => $this->fpay_factory,
            'self_url' => $this->plugin_config['self_url'],
        ]);
        $this->fpay_order_context = $this->container->make(FpayOrderContext::class);

        $this->woocommerce_refunds_manager = $this->container->make(WoocommerceRefundsManager::class, [
            'logger' => $this->logger,
            'container' => $this->container,
            'woocommerce_factory' => $this->woocommerce_factory
        ]);

        $this->refund_manager = $this->container->make(RefundManager::class, [
            'client' => $this->container->get('HttpClient'),
            'base_url' => $this->getActiveEnvironmentBaseUrl($this->plugin_config),
            'partial_refund_url' => $this->plugin_config['partial_refund_url'],
            'logger' => $this->logger,
            'container' => $this->container,
            'fpay_factory' => $this->fpay_factory,
            'fpay_auth' => $this->fpay_auth,
            'settings' => $this->settings,
            'fpay_intent_manager' => $fpay_intent_manager
        ]);

        $this->webhook = $this->container->make(Webhook::class, [
            'logger' => $this->logger,
            'container' => $this->container,
            'fpay_intent_manager' => $fpay_intent_manager,
            'fpay_auth' => $this->fpay_auth,
            'settings' => $this->settings,
            'context' => $this->fpay_order_context,
            'woocommerce_refunds_manager' => $this->woocommerce_refunds_manager,
            'refund_manager' => $this->refund_manager,
            'plugin_config' => $this->plugin_config
        ]);

        $this->session_manager = $this->container->make(SessionManager::class, [
            'container' => $this->container,
            'logger' => $this->logger
        ]);

        $this->webhook_controller = $this->container->make(WebhookController::class, [
            'webhook' => $this->webhook,
            'plugin_config' => $this->plugin_config,
            'fpay_factory' => $this->fpay_factory,
            'logger' => $this->logger,
            'session_manager' => $this->session_manager,
            'container' => $this->container
        ]);

        $this->payment_manager = $this->container->make(PaymentManager::class, [
            'fpay_auth' => $this->fpay_auth,
            'settings' => $this->settings,
            'logger' => $this->logger,
            'client' => $this->container->get('HttpClient'),
            'factory' => $this->woocommerce_factory,
            'fpay_intent_manager' => $fpay_intent_manager,
            'plugin_config' => $this->plugin_config
        ]);


    }

    public function getDeviceType(): string
    {
        $useragent = sanitize_title($_SERVER['HTTP_USER_AGENT']);
        return preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|iPhone|iPad|iPod|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $useragent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($useragent, 0, 4)) ? "MOBILE" : "WEB";
    }

    public function getActiveEnvironmentBaseUrl($config)
    {
        switch ($this->settings['environment']) {
            case self::INT_ENVIRONMENT:
                return $config['int_base_url'];
            case self::QA_ENVIRONMENT:
                return $config['qa_base_url'];
            default:
                return $config['prod_base_url'];
        }
    }

    public function init_form_fields(): void
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Activar/Desactivar el pluging: ',
                'label' => 'Activar Fpay',
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no'
            ),
            'api_details' => array(
                'title' => 'Ingresa o crea tu cuenta en <a href=" https://fpay.cl/comercios/cuenta/login" target="_blank"> Portal Comercios Fpay </a> para obtener tus credenciales.',
                'type' => 'title'
            ),
            'public_key' => array(
                'title' => 'Clave pública:',
                'type' => 'text'
            ),
            'private_key' => array(
                'title' => 'Clave privada:',
                'type' => 'password'
            ),
            'environment' => array(
                'title' => 'Ambiente',
                'type' => 'select',
                'options' => $this->plugin_config['environments'],
                'description' => ''
            ),
        );
    }

    /**
     * @override
     * This was override for moving the logo to the right alignment.
     * Return the gateway's icon.
     *
     * @return string
     */
    public function get_icon()
    {

        $icon = $this->icon ? '
            <img class="fpay_logo" src="' . WC_HTTPS::force_https_url($this->icon) . '" alt="' . esc_attr($this->get_title()) . '" />
        ' : '';
        return apply_filters('woocommerce_gateway_icon', $icon, $this->id);
    }

    /**
     * @override
     * This was override for showing only the logo in the checkout page and the name on the panel.
     * Return the gateway's title.
     *
     *
     * @return string
     */
    public function get_title()
    {
        if (is_admin()) {
            return apply_filters('woocommerce_gateway_title', $this->plugin_config['plugin_tittle'], $this->id);
        }

        return apply_filters('woocommerce_gateway_title', $this->title, $this->id);
    }

    /**
     * @param int $order_id
     * @return array
     */
    public function process_payment($order_id): array
    {
        $redirect_url = '';

        try {

            $this->logger->info('FpayGateway@process_payment starts the payment process');
            $order = wc_get_order($order_id);

            $order->set_payment_method($this->plugin_config['plugin_id']);
            $order->set_payment_method_title($this->plugin_config['plugin_tittle']);
            $order->save();

            $uuid = Uuid::uuid4();

            $this->logger->info('FpayGateway@process_payment', [
                'uuid' => $uuid
            ]);

            $fpay_intent = $this->payment_manager->processPayment($order, home_url(), $uuid);
            $this->session_manager->saveDataInSession($uuid, $order_id, $fpay_intent->getSelfUrl());

            $this->logger->info('FpayGateway@process_payment save data in session');

            $data = [
                'fpay_intent_id' => $fpay_intent->getId(),
            ];

            $strategy = $this->container->make(FpayOrderContext::CREATED_STRATEGY, [
                'logger' => $this->logger
            ]);
            $this->fpay_order_context->setStrategy($strategy);
            $this->fpay_order_context->updateOrderStatus($order, $data);

            $redirect_url = $fpay_intent->getFpayCheckoutUrl();

        } catch (\Exception $exception) {
            $this->logger->error('FpayGateway@process_payment exception.', [
                'error' => $exception,
            ]);
            // TODO: Create an exception to show that the creation of the intent failed.
        }

        return array(
            'result' => 'success',
            'redirect' => $redirect_url
        );
    }

    public function process_refund($order_id, $amount = null, $reason = ''): bool
    {
        try {
            $this->logger->info('FpayGateway@process_refund - start process');
            $order = wc_get_order($order_id);

            $refund_data = array(
                'fpay_intent_id' => $order->get_transaction_id(),
                'refunded_amount' => $amount === null ? 0 : $amount,
                'refund_merchant_unique_id' => $order->get_id(),
                'authorization_id' => -1
            );

            $this->logger->info('FpayGateway@process_refund', [
                'refund_data' => $refund_data,
            ]);

            $refund = $this->fpay_factory->createRefund($refund_data);

            $fpay_intent = $this->refund_manager->processRefund($refund, $reason);

            $order_refunds = $order->get_refunds();
            $last_refund_woocommerce = $this->woocommerce_refunds_manager->getLastRefund($order_refunds);

            $this->logger->info('FpayGateway@process_refund before add metadata.', [
                'refunds_from_order' => $order_refunds,
            ]);

            $this->woocommerce_refunds_manager->addMetaDataToRefund(
                $last_refund_woocommerce,
                $fpay_intent->getGateway()->getLastRefund()
            );

            $this->logger->info('FpayGateway@process_refund after add metadata.', [
                'refunds_from_order' => $order->get_refunds(),
            ]);

            $strategy = $this->container->make(FpayOrderContext::REFUNDED_STRATEGY, [
                'logger' => $this->logger,
                'refund' => $last_refund_woocommerce
            ]);

            $data = array(
                'fpay_intent_id' => $fpay_intent->getId(),
                'fpay_state' => $fpay_intent->getState(),
                'refunded_amount' => $amount,
                'reason' => $reason,
                'authorization_id' => $fpay_intent->getGateway()->getLastRefund()->getAuthorizationId(),
                'state' => $fpay_intent->getGateway()->getLastRefund()->getState()
            );

            $this->fpay_order_context->setStrategy($strategy);
            $this->fpay_order_context->updateOrderStatus($order, $data);

        } catch (\Exception $exception) {
            $this->logger->error('FpayGateway@process_refund exception.', [
                'error' => $exception,
            ]);
            return false;
        }

        return true;
    }

    /**
     * @return Container
     */
    public function getContainer(): Container
    {
        return $this->container;
    }

    public function setPaymentManager(PaymentManager $payment_manager): void
    {
        $this->payment_manager = $payment_manager;
    }

    public function getFpayOrderContext(): FpayOrderContext
    {
        return $this->fpay_order_context;
    }

    public function setWebhook(Webhook $webhook): void
    {
        $this->webhook = $webhook;
    }

    public function setRefundManager(RefundManager $refund_manager): void
    {
        $this->refund_manager = $refund_manager;
    }

    public function setLogger(Logger $logger): void
    {
        $this->logger = $logger;
    }

    public function setContainer($container): void
    {
        $this->container = $container;
    }

    public function setFpayOrderContext(FpayOrderContext $fpay_order_context): void
    {
        $this->fpay_order_context = $fpay_order_context;
    }

    public function setFpayFactory(FpayFactory $fpay_factory): void
    {
        $this->fpay_factory = $fpay_factory;
    }

    public function setWoocommerceRefundsManager(WoocommerceRefundsManager $woocommerce_refunds_manager): void
    {
        $this->woocommerce_refunds_manager = $woocommerce_refunds_manager;
    }

    public function setPluginConfig(array $plugin_config): void
    {
        $this->plugin_config = $plugin_config;
    }

    public function setWebhookController(WebhookController $webhook_controller): void
    {
        $this->webhook_controller = $webhook_controller;
    }

    public function setSessionManager(SessionManager $session_manager): void
    {
        $this->session_manager = $session_manager;
    }
}