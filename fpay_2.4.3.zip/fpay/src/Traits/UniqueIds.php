<?php

namespace Fpay\Woocommerce\Traits;

trait UniqueIds
{
    public function buildMerchantUniqueId($order_id): string
    {
        return 'wc_' . $order_id . '_' . date('Ymdhisu');
    }
}