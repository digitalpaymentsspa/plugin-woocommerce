<?php

namespace Fpay\Woocommerce\Traits;

use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;

trait PaymentStates
{

    public function isIntentInSomePaymentState(AbstractFpayIntent $fpay_intent): bool
    {
        return $fpay_intent->getState() === AbstractFpayIntent::STATE_PAID
            || $fpay_intent->getState() === AbstractFpayIntent::STATE_PARTIAL_REFUNDED
            || $fpay_intent->getState() === AbstractFpayIntent::STATE_REFUNDED;
    }
}