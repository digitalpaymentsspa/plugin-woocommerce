<?php

namespace Fpay\Woocommerce\Strategies;

use Fpay\Woocommerce\Models\Contracts\AbstractOrder;
use Fpay\Woocommerce\Strategies\Contracts\OrderStrategy;
use Fpay\Woocommerce\Traits\ValidateOrderState;

defined('ABSPATH') || exit;

class FailOrderStrategy implements OrderStrategy
{
    use ValidateOrderState;

    private $logger;
    private $container;
    private $incoming_state;

    public function __construct($logger, $container, $incoming_state)
    {
        $this->logger = $logger;
        $this->container = $container;
        $this->incoming_state = $incoming_state;
    }


    public function execute($order, $data)
    {
        $this->wasOrderUpdatedPreviously($order, $this->incoming_state);

        $this->logger->info('FailOrderStrategy');

        $order->update_status(AbstractOrder::FAILED_STATUS);
        $order->save();

        $date = date('d/m/Y H:i');
        $transaction_details = "
                    <div class='fpay_response_note'>
                        <p><h3>Pago Fallido</h3></p>
                        <strong>Estado Interno Fpay: </strong>{$data['fpay_state']}<br />                         
                        <strong>Fecha:</strong> {$date} <br />
                        <strong>ID interno: </strong>{$data['fpay_intent_id']} <br />
                    </div>
        ";

        $order->add_order_note('El pago fue fallido', true);
        $order->add_order_note($transaction_details);

        $data['order_id'] = $order->get_id();
        $redirect_url = wc_get_checkout_url();
        $this->notifyToShop($data, $redirect_url);
    }

    public function notifyToShop($data, $redirect_url)
    {
        wc_add_notice('El pago falló, por favor vuelva a intentarlo.', 'error');
        $this->logger->info(get_class($this) . ': Pago fallido con Fpay.');
        $this->logger->info(get_class($this) . ': ' . json_encode($data));
        wp_safe_redirect($redirect_url);
    }
}