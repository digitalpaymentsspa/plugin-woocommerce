<?php

namespace Fpay\Woocommerce\Strategies\Contracts;

interface OrderStrategy
{
    /**
     * @param $order
     * @param $data
     * @return mixed
     */
    public function execute($order, $data);

    /**
     * @param $data
     * @param $redirect_url
     * @return mixed
     */
    public function notifyToShop($data, $redirect_url);
}