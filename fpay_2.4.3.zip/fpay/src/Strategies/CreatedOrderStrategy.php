<?php

namespace Fpay\Woocommerce\Strategies;

use Fpay\Woocommerce\Models\Contracts\AbstractOrder;
use Fpay\Woocommerce\Strategies\Contracts\OrderStrategy;

defined('ABSPATH') || exit;

class CreatedOrderStrategy implements OrderStrategy
{
    private $logger;

    public function __construct($logger)
    {
        $this->logger = $logger;
    }

    public function execute($order, $data)
    {
        $this->logger->info('CreatedOrderStrategy', [
            'data' => $data,
        ]);
        $order->update_status(AbstractOrder::PENDING_STATUS);
        $order->set_transaction_id($data['fpay_intent_id']);
        $order->save();

        $this->logger->info('CreatedOrderStrategy', [
            'order_meta' => wc_get_order($order->get_id())->get_transaction_id(),
        ]);
        $date = date('d/m/Y H:i');

        $transaction_details = "
                    <div class='fpay_response_note'>
                        <p><h3>Pago en proceso</h3></p>
                        <strong>Estado Interno Fpay: </strong>Created <br />                         
                        <strong>Fecha:</strong> {$date} <br />
                        <strong>ID interno: </strong>{$data['fpay_intent_id']} <br />
                    </div>
        ";
        $order->add_order_note('Se inicia el proceso de pago con Fpay.');
        $order->add_order_note($transaction_details);
        $this->notifyToShop($data, '');
    }

    public function notifyToShop($data, $redirect_url)
    {
        wc_add_notice('Por favor realice el pago en Fpay.');
    }
}