<?php

namespace Fpay\Woocommerce\Strategies;

use function Fpay\Woocommerce\Config\config;

defined('ABSPATH') || exit;

use Fpay\Woocommerce\FpayGatewayImpl2;
use Fpay\Woocommerce\Strategies\Contracts\OrderStrategy;

class RefundWebhookStrategy implements OrderStrategy
{

    private $logger;

    public function __construct($logger)
    {
        $this->logger = $logger;
    }

    public function execute($order, $data)
    {
        $this->logger->info('RefundWebhookStrategy');

        $refund = wc_create_refund(
            array('amount' => $data['refunded_amount'],
                'reason' => $data['reason'],
                'order_id' => $order->get_id()
            )
        );

        $refund->set_reason(
            $refund->get_reason() .
            '- via Fpay, Id autorización: ' . $data['authorization_id']
        );


        $data['payment_method'] = config('plugind_id');

        add_post_meta(
            $refund->get_id(),
            config('meta_data_key'),
            $data
        );

        $refund->save();

        $date = date('d/m/Y H:i');

        $transaction_details = "
                    <div class='fpay_response_note'>
                        <p><h3> Devolución vía webhook</h3></p>
                        <strong>Estado Interno Fpay: </strong>{$data['fpay_state']}<br />                         
                        <strong>ID interno intención de pago: </strong>{$data['fpay_intent_id']} <br />
                        <strong>Fecha:</strong> {$date} <br />
                        <strong>Valor devolución:</strong> {$data['refunded_amount']} <br />
                        <strong>Razón devolución:</strong> {$data['reason']} <br />
                        <strong>Estado interno devolución:</strong> {$data['state']} <br />
                        <strong>Id autorización devolución:</strong> {$data['authorization_id']} <br />
                    </div>
        ";
        $order->add_order_note('Se realizo un proceso de devolución.');
        $order->add_order_note($transaction_details);
    }

    public function notifyToShop($data, $redirect_url)
    {
        //This is not necessary to implements nothing to notify to the client
    }
}