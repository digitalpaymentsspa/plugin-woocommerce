<?php

namespace Fpay\Woocommerce\Strategies;

use Fpay\Woocommerce\Strategies\Contracts\OrderStrategy;

defined('ABSPATH') || exit;

class RefundedOrderStrategy implements OrderStrategy
{
    private $logger;
    private $refund;

    public function __construct($logger, $refund)
    {
        $this->logger = $logger;
        $this->refund = $refund;
    }

    public function execute($order, $data)
    {
        $this->logger->info('RefundedStrategy');

        $date = date('d/m/Y H:i');

        $this->refund->set_reason(
            $this->refund->get_reason() .
            '- via Fpay, Id autorización: ' . $data['authorization_id']
        );
        $this->refund->save();

        $transaction_details = "
                    <div class='fpay_response_note'>
                        <p><h3> Devolución</h3></p>
                        <strong>Estado Interno Fpay: </strong>{$data['fpay_state']}<br />                         
                        <strong>ID interno intención de pago: </strong>{$data['fpay_intent_id']} <br />
                        <strong>Fecha:</strong> {$date} <br />
                        <strong>Valor devolución:</strong> {$data['refunded_amount']} <br />
                        <strong>Razón devolución:</strong> {$data['reason']} <br />
                        <strong>Estado interno devolución:</strong> {$data['state']} <br />
                        <strong>Id autorización devolución:</strong> {$data['authorization_id']} <br />
                    </div>
        ";
        $order->add_order_note('Se realizo un proceso de devolución.');
        $order->add_order_note($transaction_details);
    }

    public function notifyToShop($data, $redirect_url)
    {
        //This is not necessary to implements nothing to notify to the client
    }
}