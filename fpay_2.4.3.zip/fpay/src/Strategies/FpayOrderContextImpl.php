<?php

namespace Fpay\Woocommerce\Strategies;

use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;
use Fpay\Woocommerce\Strategies\Contracts\OrderStrategy;

defined('ABSPATH') || exit;

class FpayOrderContextImpl implements FpayOrderContext
{
    /** @var OrderStrategy */
    private $strategy;

    public function updateOrderStatus($order, array $data)
    {
        $this->strategy->execute($order, $data);
    }

    public function setStrategy(OrderStrategy $strategy)
    {
        $this->strategy = $strategy;
    }

    public function getStrategy(): OrderStrategy
    {
        return $this->strategy;
    }
}