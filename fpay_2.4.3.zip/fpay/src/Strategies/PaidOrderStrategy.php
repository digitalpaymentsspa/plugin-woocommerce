<?php

namespace Fpay\Woocommerce\Strategies;

use Fpay\Woocommerce\Models\Contracts\AbstractOrder;
use Fpay\Woocommerce\Strategies\Contracts\OrderStrategy;
use Fpay\Woocommerce\Traits\ValidateOrderState;

defined('ABSPATH') || exit;

class PaidOrderStrategy implements OrderStrategy
{
    use ValidateOrderState;

    private $logger;
    private $container;
    private $incoming_state;

    public function __construct($logger, $container, $incoming_state)
    {
        $this->logger = $logger;
        $this->container = $container;
        $this->incoming_state = $incoming_state;
    }

    public function execute($order, $data)
    {
        $this->logger->info('PaidOrderStrategy');
        $this->wasOrderUpdatedPreviously($order, $this->incoming_state);

        /** @var \WC_Order */
        $order->payment_complete();
        $order->set_transaction_id($data['fpay_intent_id']);
        $order->save();

        $order->update_status(AbstractOrder::PROCESSING_STATUS);
        $order->add_order_note('Pago recibido correctamente con FPay!', true);

        $date = date('d/m/Y H:i');
        $transaction_details = "
                    <div>
                        <p><h3>Pago Completado</h3></p>
                        <strong>Estado Interno Fpay: </strong>Paid<br />                         
                        <strong>Medio de pago:</strong> {$data['payment_method']} <br />
                        <strong>Fecha:</strong> {$date} <br />
                        <strong>ID interno: </strong>{$data['fpay_intent_id']} <br/>
                    </div>
            ";
        $order->add_order_note($transaction_details, true);
        $this->notifyToShop('', $order->get_checkout_order_received_url());

    }

    public function notifyToShop($data, $redirect_url)
    {
        wp_safe_redirect($redirect_url);
        wc_add_notice('Gracias por pagar con Fpay, súmate a lo simple.');
    }
}