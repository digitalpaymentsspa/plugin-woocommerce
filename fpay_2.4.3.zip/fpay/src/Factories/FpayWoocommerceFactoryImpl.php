<?php

namespace Fpay\Woocommerce\Factories;

use Fpay\Woocommerce\Exceptions\Contracts\FpayFactoryException;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\Models\Contracts\AbstractAmount;
use Fpay\Woocommerce\Models\Contracts\AbstractBuyer;
use Fpay\Woocommerce\Models\Contracts\AbstractDetails;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractItem;
use Fpay\Woocommerce\Models\Contracts\AbstractItemList;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Models\Contracts\AbstractShippingAddress;
use Fpay\Woocommerce\Models\Contracts\AbstractTransaction;

defined('ABSPATH') || exit;

class FpayWoocommerceFactoryImpl implements FpayWoocommerceFactory
{
    private $container;
    private $plugin_config;
    private $logger;
    private $channel;

    public function __construct($container, $plugin_config, $logger, $channel)
    {
        $this->container = $container;
        $this->plugin_config = $plugin_config;
        $this->logger = $logger;
        $this->channel = $channel;
    }

    public function createAmount($data, $details): AbstractAmount
    {
        return $this->container->make(AbstractAmount::class, [
            'currency' => $this->plugin_config['currency'],
            'total' => round($data->get_total()),
            'details' => $details
        ]);
    }

    public function createBuyer($data): AbstractBuyer
    {
        $email = $data->get_billing_email();
        $phone = $data->get_billing_phone();
        $full_name = $data->get_billing_first_name() . " " . $data->get_billing_last_name();

        return $this->container->make(AbstractBuyer::class, [
            'logged_in' => true,
            'email' => $email === '' ? ' ' : $email,
            'phone' => $phone === '' ? ' ' : $phone,
            'full_name' => $full_name === '' ? ' ' : $full_name,
        ]);
    }

    public function createFpayIntent($data): AbstractFpayIntent
    {
        $fpay_intent = null;

        try {

            $this->logger->info('FpayWoocommerceFactory@createFpayIntent', [
                'data' => $data,
            ]);

            $details = $this->createDetails($data);
            $this->logger->info('FpayWoocommerceFactory@createFpayIntent', [
                'details' => $details,
            ]);
            $amount = $this->createAmount($data, $details);

            $shipping_address = $this->createShippingAddress($data);

            $items = $this->mapItemsFromData($data->get_items());

            $items_list = $this->createItemList($data, $items, $shipping_address);

            $transaction = $this->createTransaction($data, $items_list, $amount);

            $buyer = $this->createBuyer($data);

            $fpay_intent = $this->container->make(AbstractFpayIntent::class, [
                'buyer' => $buyer,
                'intent' => AbstractFpayIntent::INTENT_SALE,
                'payment_method' => $this->plugin_config['payment_method'],
                'pst_origen' => $this->plugin_config['pst_origen'],
                'transaction' => $transaction,
                'container' => $this->container
            ]);

        } catch (\Exception $exception) {
            $fpay_factory_exception = $this->container->make(FpayFactoryException::class, [
                'logger' => $this->logger,
                'error_data' => $exception
            ]);

            $fpay_factory_exception->sendMessage();
            throw $fpay_factory_exception;
        }

        return $fpay_intent;
    }

    public function mapItemsFromData($items): array
    {
        $items_mapped = array();

        foreach ($items as $item) {
            array_push($items_mapped, $this->createItem($item));
        }
        return $items_mapped;
    }

    public function createItem($data): AbstractItem
    {
        return $this->container->make(AbstractItem::class, [
            "sku" => $data->get_product_id(),
            "name" => $data->get_name(),
            "description" => $data->get_name(),
            "quantity" => $data->get_quantity(),
            "price" => round($data->get_total()),
            "tax" => round($data->get_subtotal_tax()),
            "category" => $data->get_type()
        ]);
    }

    public function createItemList($data, $items, $shipping_address): AbstractItemList
    {
        return $this->container->make(AbstractItemList::class, [
            'shipping_method' => $this->plugin_config['shipping_method'],
            'items' => $items,
            'shipping_address' => $shipping_address,
        ]);
    }

    public function createShippingAddress($data): AbstractShippingAddress
    {
        return $this->container->make(AbstractShippingAddress::class, [
            'address_type' => AbstractShippingAddress::ADDRESS_TYPE,
            'line1' => $data->get_billing_address_1() . " " . $data->get_billing_address_2(),
            "city" => $data->get_billing_city() === '' ?
                $data->get_billing_address_1() . " " . $data->get_billing_address_2() : $data->get_billing_city(),
            "country_code" => $this->plugin_config['country_code'],
            "phone" => $data->get_billing_phone() === '' ? ' ' : $data->get_billing_phone(),
            "recipient_name" => $data->get_billing_first_name() . " " . $data->get_billing_last_name()
        ]);
    }

    public function createTransaction($data, $item_list, $amount): AbstractTransaction
    {
        $transaction = $this->container->make(AbstractTransaction::class, [
            'deferred_capture' => AbstractTransaction::DEFERRED_CAPTURE_FALSE,
            'shipping_method' => AbstractTransaction::SHIPPING_METHOD_DIGITAL,
            'purchase_order' => $data->get_id(),
            'description' => AbstractTransaction::DESCRIPTION,
            'soft_descriptor' => $this->plugin_config['soft_descriptor'],
            'merchant_fantasy_name' => $this->plugin_config['merchant_fantasy_name'],
            'reconciliation_id' => $data->get_id(),
            'invoice_type' => $this->plugin_config['invoice_type'],
            'terminal_id' => AbstractTransaction::TERMINAL_ID,
            'store_id' => AbstractTransaction::STORE_ID,
            'channel' => $this->channel,
            'on_behalf_of' => $data->get_id(),
            'invoice_number' => $data->get_id(),
            'item_list' => $item_list,
            'amount' => $amount
        ]);
        $merchant_unique_id = $transaction->buildMerchantUniqueId($data->get_id());
        $transaction->setMerchantUniqueId($merchant_unique_id);
        return $transaction;
    }

    public function createDetails($data): AbstractDetails
    {
        return $this->container->make(AbstractDetails::class, [
            'subtotal' => round($data->get_subtotal()),
            'tax' => AbstractDetails::TAX_CERO,
            'shipping' => round($data->get_shipping_total()),
            'shipping_discount' => AbstractDetails::DISCOUNT_CERO,
        ]);
    }

    public function createRefund($data, $fpay_intent_id): AbstractRefund
    {
        return $this->container->make(AbstractRefund::class, [
            'fpay_intention_id' => $fpay_intent_id,
            'refunded_amount' => $data->refunded_amount,
            'refund_merchant_unique_id' => $data->refund_mechant_unique_id,
            'authorization_id' => (int)$data->authorization_id,
            'state' => $data->state,
        ]);
    }
}