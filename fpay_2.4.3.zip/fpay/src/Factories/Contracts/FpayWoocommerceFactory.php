<?php

namespace Fpay\Woocommerce\Factories\Contracts;

use Fpay\Woocommerce\Models\Contracts\AbstractAmount;
use Fpay\Woocommerce\Models\Contracts\AbstractBuyer;
use Fpay\Woocommerce\Models\Contracts\AbstractDetails;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractItem;
use Fpay\Woocommerce\Models\Contracts\AbstractItemList;
use Fpay\Woocommerce\Models\Contracts\AbstractLink;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Models\Contracts\AbstractShippingAddress;
use Fpay\Woocommerce\Models\Contracts\AbstractTransaction;

interface FpayWoocommerceFactory
{

    public function createAmount($data, $details): AbstractAmount;

    public function createBuyer($data): AbstractBuyer;

    public function createFpayIntent($data): AbstractFpayIntent;

    public function createItem($data): AbstractItem;

    public function createItemList($data, $items, $shipping_address): AbstractItemList;

    public function createShippingAddress($data): AbstractShippingAddress;

    public function createTransaction($data, $item_list, $amount): AbstractTransaction;

    public function createDetails($data): AbstractDetails;

    public function mapItemsFromData($items): array;

    public function createRefund($data, $fpay_intent_id): AbstractRefund;

}