<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayIntentDoesNotBelongsToPaymentGatewayException
{
    public function sendMessage();
}