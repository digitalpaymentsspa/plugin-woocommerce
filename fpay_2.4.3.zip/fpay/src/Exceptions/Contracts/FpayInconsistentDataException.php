<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayInconsistentDataException
{
    public function sendMessage();
}