<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayHasPreviousIntentException
{
    public function sendMessage();
}
