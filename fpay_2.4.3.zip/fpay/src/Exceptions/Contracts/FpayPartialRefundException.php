<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayPartialRefundException
{
    public function sendMessage();
}
