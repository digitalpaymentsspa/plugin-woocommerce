<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayRefundIntentStateNotValidException
{
    public function sendMessage();
}