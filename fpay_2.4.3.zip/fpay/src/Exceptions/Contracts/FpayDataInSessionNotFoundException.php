<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayDataInSessionNotFoundException
{
    public function sendMessage();
}