<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpaySelfException
{
    public function sendMessage();
}
