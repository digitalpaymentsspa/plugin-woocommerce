<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayDuplicateOrderUpdateException
{
    public function sendMessage();
    public function redirect();
}