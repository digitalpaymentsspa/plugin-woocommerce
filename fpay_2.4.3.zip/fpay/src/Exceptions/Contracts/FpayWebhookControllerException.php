<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayWebhookControllerException
{
    public function sendMessage();
}