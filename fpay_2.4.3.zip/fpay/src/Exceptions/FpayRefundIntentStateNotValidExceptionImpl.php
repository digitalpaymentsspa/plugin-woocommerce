<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayRefundIntentStateNotValidException;

defined('ABSPATH') || exit;

class FpayRefundIntentStateNotValidExceptionImpl extends FpayException implements FpayRefundIntentStateNotValidException
{

    public function sendMessage()
    {
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_10);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
    }
}