<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayDataInSessionNotFoundException;

defined('ABSPATH') || exit;

class FpayDataInSessionNotFoundExceptionImpl extends FpayException implements FpayDataInSessionNotFoundException
{

    public function sendMessage()
    {
        wc_add_notice(self::ERROR_FOR_HUMANS_MESSAGE . self::ERROR_KEY_3, 'error');
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_3);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
        wp_safe_redirect(wc_get_checkout_url());
    }
}