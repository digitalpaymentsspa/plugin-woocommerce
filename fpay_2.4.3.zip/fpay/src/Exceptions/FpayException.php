<?php

namespace Fpay\Woocommerce\Exceptions;

use Exception;

defined('ABSPATH') || exit;

abstract class FpayException extends Exception
{

    const ERROR_KEY_1 = 'FpayWoocommerceError-001';
    const ERROR_KEY_2 = 'FpayWoocommerceError-002';
    const ERROR_KEY_3 = 'FpayWoocommerceError-003';
    const ERROR_KEY_4 = 'FpayWoocommerceError-004';
    const ERROR_KEY_5 = 'FpayWoocommerceError-005';
    const ERROR_KEY_6 = 'FpayWoocommerceError-006';
    const ERROR_KEY_7 = 'FpayWoocommerceError-007';
    const ERROR_KEY_8 = 'FpayWoocommerceError-008';
    const ERROR_KEY_9 = 'FpayWoocommerceError-009';
    const ERROR_KEY_10 = 'FpayWoocommerceError-010';
    const ERROR_KEY_11 = 'FpayWoocommerceError-011';
    const ERROR_KEY_12 = 'FpayWoocommerceError-012';
    const ERROR_KEY_13 = 'FpayWoocommerceError-013';
    const ERROR_KEY_14 = 'FpayWoocommerceError-014';
    const ERROR_KEY_15 = 'FpayWoocommerceError-015';
    const ERROR_KEY_16 = 'FpayWoocommerceError-016';

    const ERROR_FOR_HUMANS_MESSAGE = 'Ocurrió un error al procesar la transacción con Fpay - ';
    const ERROR_FOR_LOGS_MESSAGE = ': Ocurrió un error al procesar la transacción con Fpay - ';

    protected $logger;
    protected $error_data;

    public function __construct($logger = null, $error_data = "", $message = "", $code = 0, \Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
        $container = require __DIR__ . '/../../app/bootstrap.php';
        $this->logger = $logger ?? $container->get('Logger');
        $this->error_data = json_encode($error_data);
    }
}
