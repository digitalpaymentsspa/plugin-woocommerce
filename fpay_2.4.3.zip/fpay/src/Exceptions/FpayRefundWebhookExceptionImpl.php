<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayRefundWebhookException;

defined('ABSPATH') || exit;

class FpayRefundWebhookExceptionImpl extends FpayException implements FpayRefundWebhookException
{

    public function sendMessage()
    {
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_11);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
    }
}