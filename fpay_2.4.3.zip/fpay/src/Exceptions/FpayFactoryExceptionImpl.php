<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayFactoryException;

defined('ABSPATH') || exit;

class FpayFactoryExceptionImpl extends FpayException implements FpayFactoryException
{

    public function sendMessage()
    {
        wc_add_notice(self::ERROR_FOR_HUMANS_MESSAGE . self::ERROR_KEY_4, 'error');
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_4);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
    }
}