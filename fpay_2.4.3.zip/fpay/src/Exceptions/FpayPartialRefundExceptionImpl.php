<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayPartialRefundException;

defined('ABSPATH') || exit;

class FpayPartialRefundExceptionImpl extends FpayException implements FpayPartialRefundException
{

    public function sendMessage()
    {
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_8);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
    }

}


