<?php

namespace Fpay\Woocommerce\Config;


if (!function_exists('Fpay\Woocommerce\Config\config')) {
    /**
     * @param string $key
     * @return array|mixed
     */
    function config($key = '')
    {
        $values = [
            'environments' => array_combine(
                explode(',', $_ENV['FPAY_ENVIRONMENTS']),
                explode(',', $_ENV['FPAY_ENVIRONMENTS'])
            ),
            'auth_url' => $_ENV['FPAY_AUTH_URL'],
            'int_base_url' => $_ENV['FPAY_INT_BASE_URL'],
            'qa_base_url' => $_ENV['FPAY_QA_BASE_URL'],
            'prod_base_url' => $_ENV['FPAY_PROD_BASE_URL'],
            'country_code' => $_ENV['FPAY_COUNTRY_CODE'],
            'currency' => $_ENV['FPAY_CURRENCY'],
            'plugin_version' => $_ENV['FPAY_PLUGIN_VERSION'],
            'soft_descriptor' => $_ENV['FPAY_SOFT_DESCRIPTOR'] . $_ENV['FPAY_PLUGIN_VERSION'],
            'merchant_fantasy_name' => $_ENV['FPAY_MERCHANT_FANTASY_NAME'],
            'payment_method' => $_ENV['FPAY_PAYMENT_METHOD'],
            'pst_origen' => $_ENV['FPAY_PST_ORIGEN'],
            'create_fpay_intent_url' => $_ENV['FPAY_CREATE_INTENT_URL'],
            'shipping_method' => $_ENV['FPAY_SHIPPING_METHOD'],
            'invoice_type' => $_ENV['FPAY_INVOCE_TYPE'],
            'self_url' => $_ENV['FPAY_SELF_URL'],
            'partial_refund_url' => $_ENV['FPAY_PARTIAL_REFUND_URL'],
            'plugin_id' => $_ENV['FPAY_PLUGIN_ID'],
            'logger_name' => $_ENV['FPAY_LOGGER_NAME'],
            'logger_path' => $_ENV['FPAY_LOGGER_PATH'] ?? __DIR__ . '/../logs/fpay-' . $_ENV['FPAY_PLUGIN_NUMBER'] . '.log',
            'meta_data_key' => $_ENV['FPAY_META_DATA_KEY'],
            'hook_for_config_name' => $_ENV['FPAY_HOOK_NAME_FOR_CONFIG'] . $_ENV['FPAY_PLUGIN_ID'],
            'plugin_tittle' => $_ENV['FPAY_PLUGIN_TITTLE'],
            'method_description' => $_ENV['FPAY_METHOD_DESCRIPTION'],
            'for_client_description' => $_ENV['FPAY_DESCRIPTION'],
            'success_api_name' => $_ENV['FPAY_SUCCESS_API_NAME'] ?? 'fpay_payment_success',
            'not_success_api_name' => $_ENV['FPAY_NOT_SUCCESS_API_NAME'] ?? 'fpay_payment_not_success',
            'webhook_url' => $_ENV['FPAY_WEBHOOKS_URL'],

            /*
           * For the file to connect to woocommerce
           */
            'plugin_prefix' => $_ENV['FPAY_PLUGIN_PREFIX'],
            'plugin_number' => $_ENV['FPAY_PLUGIN_NUMBER'],
            'plugin_file_name' => $_ENV['FPAY_PLUGIN_FILE_NAME'],
            'gateway_path' => $_ENV['FPAY_GATEWAY_PATH'],
            'gateway_class_name' => $_ENV['FPAY_GATEWAY_CLASS_NAME'],
        ];
        if($key === ''){
            return $values;
        }
        return $values[$key];
    }
}


