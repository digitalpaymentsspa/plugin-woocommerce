<?php

namespace Fpay\Woocommerce\App\binds;

use Fpay\Woocommerce\Services\Contracts\FpayAuth;
use Fpay\Woocommerce\Services\Contracts\FpayIntentManager;
use Fpay\Woocommerce\Services\Contracts\PaymentManager;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Fpay\Woocommerce\Services\Contracts\Webhook;
use Fpay\Woocommerce\Services\FpayAuthImpl;
use Fpay\Woocommerce\Services\FpayIntentManagerImpl;
use Fpay\Woocommerce\Services\PaymentManagerImpl;
use Fpay\Woocommerce\Services\RefundManagerImpl;
use Fpay\Woocommerce\Services\SessionManagerImpl;
use Fpay\Woocommerce\Services\WebhookImpl;
use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;
use Fpay\Woocommerce\Strategies\FpayOrderContextImpl;
use Fpay\Woocommerce\Services\WoocommerceRefundsManagerImpl;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use function DI\autowire;

if (!function_exists('Fpay\Woocommerce\App\binds\services')) {
    function services(): array
    {
        return array(
            // Bind an interface to a service implementation.
            PaymentManager::class => autowire(PaymentManagerImpl::class),
            Webhook::class => autowire(WebhookImpl::class),
            FpayAuth::class => autowire(FpayAuthImpl::class),
            FpayIntentManager::class => autowire(FpayIntentManagerImpl::class),
            FpayOrderContext::class => autowire(FpayOrderContextImpl::class),
            RefundManager::class => autowire(RefundManagerImpl::class),
            WoocommerceRefundsManager::class => autowire(WoocommerceRefundsManagerImpl::class),
            SessionManager::class => autowire(SessionManagerImpl::class),
        );
    }
}
