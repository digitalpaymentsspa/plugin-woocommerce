<?php

namespace Fpay\Woocommerce\App\binds;

use Fpay\Woocommerce\Exceptions\FpayWebhookControllerExceptionImpl;
use Fpay\Woocommerce\Exceptions\Contracts\FpayCreateIntentException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayDataInSessionNotFoundException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayDuplicateOrderUpdateException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayFactoryException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayInconsistentDataException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayLastRefundNotFoundException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayNotFoundLinkTypeException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayOverDraftRefundException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayPartialRefundException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayRefundIntentStateNotValidException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayRefundWebhookException;
use Fpay\Woocommerce\Exceptions\Contracts\FpaySelfException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayWebhookControllerException;
use Fpay\Woocommerce\Exceptions\FpayCreateIntentExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayDataInSessionNotFoundExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayDuplicateOrderUpdateExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayFactoryExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayInconsistentDataExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayLastRefundNotFoundExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayNotFoundLinkTypeExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayOverDraftRefundExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayPartialRefundExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayRefundIntentStateNotValidExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpayRefundWebhookExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpaySelfExceptionImpl;
use function DI\autowire;
use Fpay\Woocommerce\Exceptions\Contracts\FpayAuthException;
use Fpay\Woocommerce\Exceptions\FpayAuthExceptionImpl;
use Fpay\Woocommerce\Exceptions\Contracts\FpayIntentDoesNotBelongsToPaymentGatewayException;
use Fpay\Woocommerce\Exceptions\FpayIntentDoesNotBelongsToPaymentGatewayExceptionImpl;


if (!function_exists('Fpay\Woocommerce\App\binds\exceptions')) {
    function exceptions(): array
    {
        return array(

            //Bind Exceptions, an interface to an implementation
            FpayAuthException::class => autowire(FpayAuthExceptionImpl::class),
            FpayFactoryException::class => autowire(FpayFactoryExceptionImpl::class),
            FpayCreateIntentException::class => autowire(FpayCreateIntentExceptionImpl::class),
            FpayNotFoundLinkTypeException::class => autowire(FpayNotFoundLinkTypeExceptionImpl::class),
            FpayDataInSessionNotFoundException::class => autowire(
                FpayDataInSessionNotFoundExceptionImpl::class
            ),
            FpayPartialRefundException::class => autowire(
                FpayPartialRefundExceptionImpl::class
            ),
            FpayInconsistentDataException::class => autowire(
                FpayInconsistentDataExceptionImpl::class
            ),
            FpayRefundIntentStateNotValidException::class => autowire(
                FpayRefundIntentStateNotValidExceptionImpl::class
            ),
            FpayRefundWebhookException::class => autowire(
                FpayRefundWebhookExceptionImpl::class
            ),
            FpayOverDraftRefundException::class => autowire(
                FpayOverDraftRefundExceptionImpl::class
            ),
            FpayLastRefundNotFoundException::class => autowire(
                FpayLastRefundNotFoundExceptionImpl::class
            ),
            FpaySelfException::class => autowire(
                FpaySelfExceptionImpl::class
            ),
            FpayDuplicateOrderUpdateException::class => autowire(
                FpayDuplicateOrderUpdateExceptionImpl::class,
            ),
            FpayIntentDoesNotBelongsToPaymentGatewayException::class => autowire(
                FpayIntentDoesNotBelongsToPaymentGatewayExceptionImpl::class
            ),
            FpayWebhookControllerException::class => autowire(
                FpayWebhookControllerExceptionImpl::class
            ),
        );
    }
}
