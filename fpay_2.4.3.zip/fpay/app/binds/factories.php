<?php

namespace Fpay\Woocommerce\App\binds;

use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\Factories\FpayFactoryImpl;
use Fpay\Woocommerce\Factories\FpayWoocommerceFactoryImpl;
use function DI\autowire;


if (!function_exists('Fpay\Woocommerce\App\binds\factories')) {
    function factories(): array
    {
        return array(
            // Bind Factories
            FpayFactory::class => autowire(FpayFactoryImpl::class),
            FpayWoocommerceFactory::class => autowire(FpayWoocommerceFactoryImpl::class),
        );
    }
}