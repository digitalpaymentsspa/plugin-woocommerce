<?php

namespace Fpay\Woocommerce\App\binds;

use Fpay\Woocommerce\Strategies\CancelOrderStrategy;
use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;
use Fpay\Woocommerce\Strategies\CreatedOrderStrategy;
use Fpay\Woocommerce\Strategies\FailOrderStrategy;
use Fpay\Woocommerce\Strategies\PaidOrderStrategy;
use Fpay\Woocommerce\Strategies\RefundedOrderStrategy;
use Fpay\Woocommerce\Strategies\RefundWebhookStrategy;
use function DI\autowire;

if (!function_exists('Fpay\Woocommerce\App\binds\strategies')) {
    function strategies(): array
    {
        return array(
            FpayOrderContext::PAID_STRATEGY => autowire(PaidOrderStrategy::class),
            FpayOrderContext::CANCEL_STRATEGY => autowire(CancelOrderStrategy::class),
            FpayOrderContext::CREATED_STRATEGY => autowire(CreatedOrderStrategy::class),
            FpayOrderContext::REFUNDED_STRATEGY => autowire(RefundedOrderStrategy::class),
            FpayOrderContext::FAIL_STRATEGY => autowire(FailOrderStrategy::class),
            FpayOrderContext::REFUND_WEBHOOK_STRATEGY => autowire(RefundWebhookStrategy::class),
        );
    }
}