<?php

namespace Fpay\Woocommerce\App\binds;

use GuzzleHttp\Client;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Logger;
use function DI\factory;
use function Fpay\Woocommerce\Config\config;


if (!function_exists('Fpay\Woocommerce\App\binds\others')) {
    function others(): array
    {
        return array(
            // Other Instances.
            'Logger' => factory(function () {
                $logger = new Logger(config('logger_name'));
                $handler = new RotatingFileHandler(config()['logger_path'], 0, Logger::INFO);
                $logger->pushHandler($handler);
                return $logger;
            }),

            'HttpClient' => factory(function () {
                return new Client(array(
                    'timeout' => 5.0,
                ));
            }),

            'config' => config()
        );
    }
}