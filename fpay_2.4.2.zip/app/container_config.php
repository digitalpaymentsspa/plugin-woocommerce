<?php

namespace Fpay\Woocommerce\App;

use function Fpay\Woocommerce\App\binds\exceptions;
use function Fpay\Woocommerce\App\binds\factories;
use function Fpay\Woocommerce\App\binds\models;
use function Fpay\Woocommerce\App\binds\others;
use function Fpay\Woocommerce\App\binds\services;
use function Fpay\Woocommerce\App\binds\strategies;
use function Fpay\Woocommerce\App\binds\controllers;

defined('ABSPATH') || exit();

return array_merge(
    exceptions(),
    factories(),
    models(),
    others(),
    services(),
    strategies(),
    controllers()
);