<?php

require __DIR__ . '/../vendor/autoload.php';

use DI\ContainerBuilder;

/**
 * Define the dotenv configuration
 */
$dotenv = Dotenv\Dotenv::createMutable(__DIR__ . '/../');
$dotenv->safeLoad();

/**
 * The bootstrap file creates and returns the container.
 */
$containerBuilder = new ContainerBuilder;
$container_config = __DIR__ . '/container_config.php';
$containerBuilder->addDefinitions($container_config);
$containerBuilder->useAutowiring(true);
return $containerBuilder->build();