<?php

namespace Fpay\Woocommerce\App\binds;

use Fpay\Woocommerce\Controllers\WebhookControllerImpl;
use Fpay\Woocommerce\Controllers\Contracts\WebhookController;
use function DI\autowire;

if (!function_exists('Fpay\Woocommerce\App\binds\controllers')) {
    function controllers(): array
    {
        return array(
            WebhookController::class => autowire(
                WebhookControllerImpl::class
            ),
        );
    }
}