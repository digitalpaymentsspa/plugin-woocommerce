<?php

namespace Fpay\Woocommerce\App\binds;

use Fpay\Woocommerce\Models\Amount;
use Fpay\Woocommerce\Models\Buyer;
use Fpay\Woocommerce\Models\Contracts\AbstractAmount;
use Fpay\Woocommerce\Models\Contracts\AbstractBuyer;
use Fpay\Woocommerce\Models\Contracts\AbstractDetails;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessment;
use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessmentMetadata;
use Fpay\Woocommerce\Models\Contracts\AbstractPaymentInformation;
use Fpay\Woocommerce\Models\Contracts\AbstractGateway;
use Fpay\Woocommerce\Models\Contracts\AbstractItem;
use Fpay\Woocommerce\Models\Contracts\AbstractItemList;
use Fpay\Woocommerce\Models\Contracts\AbstractLink;
use Fpay\Woocommerce\Models\Contracts\AbstractOrder;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Models\Contracts\AbstractShippingAddress;
use Fpay\Woocommerce\Models\Contracts\AbstractTransaction;
use Fpay\Woocommerce\Models\Details;
use Fpay\Woocommerce\Models\FpayIntent;
use Fpay\Woocommerce\Models\FraudAssessment;
use Fpay\Woocommerce\Models\FraudAssessmentMetadata;
use Fpay\Woocommerce\Models\PaymentInformation;
use Fpay\Woocommerce\Models\Gateway;
use Fpay\Woocommerce\Models\Item;
use Fpay\Woocommerce\Models\ItemList;
use Fpay\Woocommerce\Models\Link;
use Fpay\Woocommerce\Models\Order;
use Fpay\Woocommerce\Models\Refund;
use Fpay\Woocommerce\Models\ShippingAddress;
use Fpay\Woocommerce\Models\Transaction;
use function DI\autowire;


if (!function_exists('Fpay\Woocommerce\App\binds\models')) {
    function models(): array
    {
        return array(
            // Bind an interface to an implementation for the factory
            AbstractDetails::class => autowire(Details::class),
            AbstractAmount::class => autowire(Amount::class),
            AbstractBuyer::class => autowire(Buyer::class),
            AbstractFpayIntent::class => autowire(FpayIntent::class),
            AbstractItem::class => autowire(Item::class),
            AbstractItemList::class => autowire(ItemList::class),
            AbstractShippingAddress::class => autowire(ShippingAddress::class),
            AbstractTransaction::class => autowire(Transaction::class),
            AbstractLink::class => autowire(Link::class),
            AbstractGateway::class => autowire(Gateway::class),
            AbstractFraudAssessment::class => autowire(FraudAssessment::class),
            AbstractFraudAssessmentMetadata::class => autowire(FraudAssessmentMetadata::class),
            AbstractPaymentInformation::class => autowire(PaymentInformation::class),
            AbstractOrder::class => autowire(Order::class),
            AbstractRefund::class => autowire(Refund::class),
        );
    }
}