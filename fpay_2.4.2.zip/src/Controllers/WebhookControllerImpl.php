<?php

namespace Fpay\Woocommerce\Controllers;

use DI\Container;
use Exception;
use Fpay\Woocommerce\Controllers\Contracts\WebhookController;
use Fpay\Woocommerce\Exceptions\Contracts\FpayWebhookControllerException;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\FpayGatewayImpl;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Fpay\Woocommerce\Services\Contracts\Webhook;
use Monolog\Logger;

class WebhookControllerImpl implements WebhookController
{
    protected array $plugin_config;
    protected Webhook $webhook;
    protected FpayFactory $fpay_factory;
    protected Logger $logger;
    protected SessionManager $session_manager;
    protected Container $container;

    public function __construct(
        Webhook $webhook,
        array $plugin_config,
        FpayFactory $fpay_factory,
        Logger $logger,
        SessionManager $session_manager,
        Container $container
    )
    {
        $this->webhook = $webhook;
        $this->plugin_config = $plugin_config;
        $this->fpay_factory = $fpay_factory;
        $this->logger = $logger;
        $this->session_manager = $session_manager;
        $this->container = $container;

        $this->registerRoutes();
    }

    public function registerRoutes(): void
    {
        add_action('woocommerce_api_' . $this->plugin_config['success_api_name'], array($this, 'paymentWebhook'));
        add_action('woocommerce_api_' . $this->plugin_config['not_success_api_name'], array($this, 'paymentWebhook'));
        add_action('woocommerce_api_' . $this->plugin_config['webhook_url'], array($this, 'fpayPortalWebhooks'));
    }

    public function getPostDataFromRequest()
    {
        return json_decode(file_get_contents('php://input'));
    }

    /**
     * @throws \DI\DependencyException
     * @throws FpayWebhookControllerException
     * @throws \DI\NotFoundException
     */
    public function paymentWebhook(): void
    {
        {
            wc_clear_notices();
            $this->logger->info('WebhookController@payment_webhook - ' . $this->plugin_config['plugin_id']);
            try {
                $uuid = $this->getUuidFromRequest();
                $data = $this->session_manager->getDataFromSession($uuid);
                $order = wc_get_order($data[FpayGatewayImpl::ORDER_ID_KEY]);
                $this->webhook->processFpayIntent($order, $data[FpayGatewayImpl::SELF_LINK_KEY]);
            } catch (Exception $exception) {
                $exception = $this->container->make(FpayWebhookControllerException::class, [
                    'logger' => $this->logger,
                    'error_data' => $exception,
                    'message' => 'Exists a problem in the paymentWebhook method'
                ]);
                $exception->sendMessage();
                throw $exception;
            }
        }
    }

    public function fpayPortalWebhooks()
    {
        try {
            $data = $this->getPostDataFromRequest();
            $this->logger->info('WebhookController@fpay_portal_webhooks - plugin_id: ' . $this->plugin_config['plugin_id'], [
                'data' => $data
            ]);
            $fpay_intent = $this->fpay_factory->createFpayIntent($data);
            $order_id = $fpay_intent->getTransaction()->getPurchaseOrder();

            $self_url = $fpay_intent->getSelfUrl();
            $order = wc_get_order($order_id);
            $this->webhook->processFpayIntent($order, $self_url);

        } catch (Exception $exception) {
            $this->logger->error('WebhookController@process_refund exception.', [
                'error' => $exception,
            ]);
            return wp_send_json([
                'status' => 'failed',
                'source' => 'fpay_plugin_woocommerce',
                'fpay_intent_id' => $fpay_intent->getId() ? $fpay_intent->getId() : 'empty',
                'woocommerce_order_id' => $order->get_id() ?: 'empty',
                'store' => $fpay_intent->getApplication() ? $fpay_intent->getApplication() : 'empty'
            ], 400);
        }

        return wp_send_json([
            'status' => 'received',
            'source' => 'fpay_plugin_woocommerce',
            'fpay_intent_id' => $fpay_intent->getId(),
            'woocommerce_order_id' => $order->get_id(),
            'store' => $fpay_intent->getApplication()
        ], 200);

    }

    public function getUuidFromRequest(): string
    {
        return sanitize_title($_GET[FpayGatewayImpl::UUID_KEY]);
    }
}