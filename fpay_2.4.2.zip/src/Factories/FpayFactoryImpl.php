<?php

namespace Fpay\Woocommerce\Factories;

use Fpay\Woocommerce\Exceptions\Contracts\FpayFactoryException;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Models\Contracts\AbstractAmount;
use Fpay\Woocommerce\Models\Contracts\AbstractBuyer;
use Fpay\Woocommerce\Models\Contracts\AbstractDetails;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessment;
use Fpay\Woocommerce\Models\Contracts\AbstractFraudAssessmentMetadata;
use Fpay\Woocommerce\Models\Contracts\AbstractGateway;
use Fpay\Woocommerce\Models\Contracts\AbstractItem;
use Fpay\Woocommerce\Models\Contracts\AbstractItemList;
use Fpay\Woocommerce\Models\Contracts\AbstractLink;
use Fpay\Woocommerce\Models\Contracts\AbstractPaymentInformation;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Models\Contracts\AbstractShippingAddress;
use Fpay\Woocommerce\Models\Contracts\AbstractTransaction;
use Fpay\Woocommerce\Traits\PaymentStates;

defined('ABSPATH') || exit;

class FpayFactoryImpl implements FpayFactory
{
    use PaymentStates;

    private $container;
    private $plugin_config;
    private $logger;
    private $channel;

    public function __construct($container, $plugin_config, $logger, $channel)
    {
        $this->container = $container;
        $this->plugin_config = $plugin_config;
        $this->logger = $logger;
        $this->channel = $channel;
    }

    public function createAmount($data, $details): AbstractAmount
    {
        return $this->container->make(AbstractAmount::class, [
            'currency' => $data->currency,
            'total' => $data->total,
            'details' => $details
        ]);
    }

    public function createBuyer($data): AbstractBuyer
    {
        return $this->container->make(AbstractBuyer::class, [
            'logged_in' => true,
            'email' => $data->email,
            'phone' => $data->phone,
            'full_name' => $data->full_name
        ]);
    }

    public function createFpayIntent($data): AbstractFpayIntent
    {
        $fpay_intent = null;

        try {

            $buyer_data = $data->buyer;
            $transaction_data = $data->transaction;
            $item_list_data = $transaction_data->item_list;
            $items_data = $item_list_data->items;
            $shipping_address_data = $item_list_data->shipping_address;
            $amount_data = $transaction_data->amount;
            $details_data = $amount_data->details;

            $details = $this->createDetails($details_data);
            $amount = $this->createAmount($amount_data, $details);
            $shipping_address = $this->createShippingAddress($shipping_address_data);
            $items = $this->mapItemsFromData($items_data);
            $item_list = $this->createItemList($item_list_data, $items, $shipping_address);
            $transaction = $this->createTransaction($transaction_data, $item_list, $amount);
            $buyer = $this->createBuyer($buyer_data);

            $fpay_intent = $this->container->make(AbstractFpayIntent::class, [
                'buyer' => $buyer,
                'intent' => $data->intent,
                'payment_method' => $data->payment_method,
                'pst_origen' => $data->pst_origen,
                'transaction' => $transaction,
                'container' => $this->container
            ]);

            $fpay_intent->setLinks(
                $this->mapLinksFromData($data->links)
            );

            $fpay_intent->setApplication($data->application);
            $fpay_intent->setInvoiceNumber($data->invoice_number);
            $fpay_intent->setCreateTime($data->create_time);
            $fpay_intent->setUpdateTime($data->update_time);
            $fpay_intent->setExpirationDate($data->expiration_date);
            $fpay_intent->setFpayMerchantId($data->fpay_merchant_id);
            $fpay_intent->setId($data->id);
            $fpay_intent->setState($data->state);

            if ($this->isIntentInSomePaymentState($fpay_intent)) {
                $gateway = $this->createGateway($data->gateway, $fpay_intent->getId());
                $fpay_intent->setGateway($gateway);
            }

        } catch (\Exception $exception) {
            $fpay_factory_exception = $this->container->make(FpayFactoryException::class, [
                'logger' => $this->logger,
                'error_data' => $exception
            ]);

            $fpay_factory_exception->sendMessage();
            throw $fpay_factory_exception;
        }

        $this->logger->info('FpayFactoryImpl@createFpayIntent', [
            'fpay_intent' => $fpay_intent
        ]);

        return $fpay_intent;
    }

    public function mapItemsFromData($items): array
    {
        $items_mapped = array();

        foreach ($items as $item) {
            array_push($items_mapped, $this->createItem($item));
        }
        return $items_mapped;
    }

    public function createItem($data): AbstractItem
    {
        return $this->container->make(AbstractItem::class, [
            "sku" => $data->sku,
            "name" => $data->name,
            "description" => $data->description,
            "quantity" => $data->quantity,
            "price" => $data->price,
            "tax" => $data->tax,
            "category" => $data->category
        ]);
    }

    public function createItemList($data, $items, $shipping_address): AbstractItemList
    {
        return $this->container->make(AbstractItemList::class, [
            'shipping_method' => $data->shipping_method,
            'items' => $items,
            'shipping_address' => $shipping_address,
        ]);
    }

    public function createShippingAddress($data): AbstractShippingAddress
    {
        return $this->container->make(AbstractShippingAddress::class, [
            'address_type' => $data->address_type,
            'line1' => $data->line1,
            "city" => $data->city,
            "country_code" => $data->country_code,
            "phone" => $data->phone,
            "recipient_name" => $data->recipient_name
        ]);
    }

    public function createTransaction($data, $item_list, $amount): AbstractTransaction
    {
        $transaction = $this->container->make(AbstractTransaction::class, [
            'deferred_capture' => $data->deferred_capture,
            'shipping_method' => $data->shipping_method,
            'purchase_order' => $data->purchase_order,
            'description' => $data->description,
            'soft_descriptor' => $data->soft_descriptor,
            'merchant_fantasy_name' => $data->merchant_fantasy_name,
            'reconciliation_id' => $data->reconciliation_id,
            'invoice_type' => $data->invoice_type,
            'terminal_id' => $data->terminal_id,
            'store_id' => $data->store_id,
            'channel' => $data->channel,
            'on_behalf_of' => $data->on_behalf_of,
            'invoice_number' => $data->invoice_number,
            'item_list' => $item_list,
            'amount' => $amount
        ]);
        $transaction->setMerchantUniqueId($data->merchant_unique_id);
        return $transaction;
    }

    public function createDetails($data): AbstractDetails
    {
        return $this->container->make(AbstractDetails::class, [
            'subtotal' => $data->subtotal,
            'tax' => $data->tax,
            'shipping' => $data->shipping,
            'shipping_discount' => $data->shipping_discount,
        ]);
    }


    public function mapLinksFromData($links): array
    {
        $links_mapped = array();

        foreach ($links as $link) {
            array_push($links_mapped, $this->createLink($link));
        }
        return $links_mapped;
    }

    public function createLink($data): AbstractLink
    {
        $link = $this->container->make(AbstractLink::class, [
            'href' => $data->href,
            'rel' => $data->rel,
            'method' => $data->method
        ]);

        if (isset($data->security)) {
            $link->setSecurityArray($data->security);
        }

        return $link;
    }

    public function createGateway($data, $fpay_intent_id): AbstractGateway
    {
        $refunds = array();

        foreach ($data->resume->refunds as $refund) {
            array_push($refunds, $this->createRefund([
                'fpay_intent_id' => $fpay_intent_id,
                'refunded_amount' => $refund->refunded_amount,
                'refund_merchant_unique_id' => $refund->refund_merchant_unique_id,
                'authorization_id' => $refund->authorization_code,
                'state' => $refund->state
            ]));
        }
        
        return $this->container->make(AbstractGateway::class, [
            'voucher' => $data->voucher,
            'fraudAssessment' => $data->fraudAssessment ? $this->createFraudAssessment($data->fraudAssessment) : null,
            'refunds' => $refunds,
        ]);
    }

    public function createFraudAssessment($data) : AbstractFraudAssessment
    {
        return $this->container->make(AbstractFraudAssessment::class,[
            'engine' => $data->engine,
            'status' => $data->status,
            'fraudAssessmentMetadata' => $this->createFraudAssessmentMetadata($data->metadata)
        ]);
    }

    public function createFraudAssessmentMetadata($data) : AbstractFraudAssessmentMetadata
    {
        return $this->container->make(AbstractFraudAssessmentMetadata::class,[
            'paymentInformation' => $this->createPaymentInformation($data->paymentInformation)
        ]);
    }

    public function createPaymentInformation($data) : AbstractPaymentInformation
    {
        return $this->container->make(AbstractPaymentInformation::class,[
            'scheme' => $data->scheme
        ]);
    }

    public function createRefund($data): AbstractRefund
    {
        return $this->container->make(AbstractRefund::class, [
            'fpay_intention_id' => $data['fpay_intent_id'],
            'refunded_amount' => $data['refunded_amount'],
            'refund_merchant_unique_id' => $data['refund_merchant_unique_id'],
            'authorization_id' => $data['authorization_id'],
            'state' => $data['state'] ?? 'empty',
        ]);
    }
}