<?php

namespace Fpay\Woocommerce\Strategies\Contracts;

interface FpayOrderContext
{
    const PAID_STRATEGY = 'PAID_STRATEGY';
    const CANCEL_STRATEGY = 'CANCEL_STRATEGY';
    const CREATED_STRATEGY = 'CREATED_STRATEGY';
    const REFUNDED_STRATEGY = "REFUNDED_STRATEGY";
    const FAIL_STRATEGY = 'FAIL_STRATEGY';
    const REFUND_WEBHOOK_STRATEGY = 'REFUND_WEBHOOK_STRATEGY';

    /**
     * @param $order
     * @param array $data
     * @return mixed
     */
    public function updateOrderStatus($order, array $data);

    /**
     * @param OrderStrategy $strategy
     * @return mixed
     */
    public function setStrategy(OrderStrategy $strategy);

    public function getStrategy(): OrderStrategy;
}