<?php

namespace Fpay\Woocommerce\Traits;

use Fpay\Woocommerce\Exceptions\Contracts\FpayDuplicateOrderUpdateException;

trait ValidateOrderState
{
    public function wasOrderUpdatedPreviously($order, string $incoming_state): void
    {
        $current_state = $order->get_status();
        $order_id = $order->get_id();

        $this->logger->info('ValidOrderState@wasOrderUpdatedPreviously', [
            'current_status' => $current_state,
            'incomming_state' => $incoming_state
        ]);

        if($current_state === null){
            return;
        }

        if ($current_state === $incoming_state) {
            $this->logger->info('ValidOrderState@wasOrderUpdatedPreviously', [
                'has the same state'
            ]);

            $this->logger->info('ValidOrderState@wasOrderUpdatedPreviously', [
                'current_status' => $current_state,
                'incomming_state' => $incoming_state
            ]);

            $exception = $this->container->make(FpayDuplicateOrderUpdateException::class, [
                'incoming_state' => $incoming_state,
                'order_id' =>  $order_id,
                'logger' => $this->logger,
                'error_data' => json_encode([
                    'current_state' => $current_state,
                    'incoming_state' => $incoming_state,
                    'order_id' => $order_id
                ]),
                'message' => 'The order was updated previously'
            ]);

            $exception->sendMessage();
            throw $exception;
        }
    }

}