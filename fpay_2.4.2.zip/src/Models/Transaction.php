<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractTransaction;
use Fpay\Woocommerce\Traits\UniqueIds;

defined('ABSPATH') || exit;

class Transaction implements AbstractTransaction, \JsonSerializable
{
    use UniqueIds;

    private $deferred_capture;
    private $shipping_method;
    private $merchant_unique_id;
    private $purchase_order;
    private $description;
    private $soft_descriptor;
    private $merchant_fantasy_name;
    private $reconciliation_id;
    private $invoice_type;
    private $terminal_id;
    private $store_id;
    private $channel;
    private $on_behalf_of;
    private $invoice_number;
    private $item_list;
    private $amount;

    /**
     * @param $deferred_capture
     * @param $shipping_method
     * @param $purchase_order
     * @param $description
     * @param $soft_descriptor
     * @param $merchant_fantasy_name
     * @param $reconciliation_id
     * @param $invoice_type
     * @param $terminal_id
     * @param $store_id
     * @param $channel
     * @param $on_behalf_of
     * @param $invoice_number
     */
    public function __construct(
        $deferred_capture,
        $shipping_method,
        $purchase_order,
        $description,
        $soft_descriptor,
        $merchant_fantasy_name,
        $reconciliation_id,
        $invoice_type,
        $terminal_id,
        $store_id,
        $channel,
        $on_behalf_of,
        $invoice_number,
        $item_list,
        $amount
    )
    {
        $this->deferred_capture = $deferred_capture;
        $this->shipping_method = $shipping_method;
        $this->purchase_order = $purchase_order;
        $this->description = $description;
        $this->soft_descriptor = $soft_descriptor;
        $this->merchant_fantasy_name = $merchant_fantasy_name;
        $this->reconciliation_id = $reconciliation_id;
        $this->invoice_type = $invoice_type;
        $this->terminal_id = $terminal_id;
        $this->store_id = $store_id;
        $this->channel = $channel;
        $this->on_behalf_of = $on_behalf_of;
        $this->invoice_number = $invoice_number;
        $this->item_list = $item_list;
        $this->amount = $amount;
    }



    public function setMerchantUniqueId($merchant_unique_id){
        $this->merchant_unique_id = $merchant_unique_id;
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    public function getPurchaseOrder(): string
    {
        return $this->purchase_order;
    }
}