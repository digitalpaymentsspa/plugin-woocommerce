<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractDetails;

defined('ABSPATH') || exit;

class Details implements AbstractDetails, \JsonSerializable
{
    private $subtotal;
    private $tax;
    private $shipping;
    private $shipping_discount;

    /**
     * @param $subtotal
     * @param $tax
     * @param $shipping
     * @param $shipping_discount
     */
    public function __construct($subtotal, $tax, $shipping, $shipping_discount)
    {
        $this->subtotal = $subtotal;
        $this->tax = $tax;
        $this->shipping = $shipping;
        $this->shipping_discount = $shipping_discount;
    }


    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}