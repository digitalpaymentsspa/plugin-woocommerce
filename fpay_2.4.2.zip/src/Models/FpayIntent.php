<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Exceptions\Contracts\FpayNotFoundLinkTypeException;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractGateway;
use Fpay\Woocommerce\Models\Contracts\AbstractTransaction;
use Monolog\Logger;

defined('ABSPATH') || exit;

class FpayIntent implements AbstractFpayIntent, \JsonSerializable
{
    private $intent;
    private $payment_method;
    private $pst_origen;
    private $buyer;
    private $transaction;
    private $redirect_urls;
    private $links;
    private $application;
    private $invoice_number;
    private $create_time;
    private $update_time;
    private $expiration_date;
    private $fpay_merchant_id;
    private $id;
    private $state;
    private $container;
    private $gateway;
    private Logger $logger;

    /**
     * @param $intent
     * @param $payment_method
     * @param $pst_origen
     * @param $buyer
     * @param $transaction
     * @param $container
     */
    public function __construct(
        $intent,
        $payment_method,
        $pst_origen,
        $buyer,
        $transaction,
        $container
    )
    {
        $this->intent = $intent;
        $this->payment_method = $payment_method;
        $this->pst_origen = $pst_origen;
        $this->buyer = $buyer;
        $this->transaction = $transaction;
        $this->container = $container;
        $this->logger = $this->container->get('Logger');

        $this->links = [];
        $this->redirect_urls = [];
    }

    /**
     * @return array|mixed
     */
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    /**
     * @param $redirect_urls
     */
    public function setRedirectUrls($redirect_urls)
    {
        $this->redirect_urls = $redirect_urls;
    }

    /**
     * @param mixed $links
     */
    public function setLinks($links): void
    {
        $this->links = $links;
    }

    /**
     * @param mixed $application
     */
    public function setApplication($application): void
    {
        $this->application = $application;
    }

    /**
     * @param mixed $invoice_number
     */
    public function setInvoiceNumber($invoice_number): void
    {
        $this->invoice_number = $invoice_number;
    }

    /**
     * @param mixed $create_time
     */
    public function setCreateTime($create_time): void
    {
        $this->create_time = $create_time;
    }

    /**
     * @param mixed $update_time
     */
    public function setUpdateTime($update_time): void
    {
        $this->update_time = $update_time;
    }

    /**
     * @param mixed $expiration_date
     */
    public function setExpirationDate($expiration_date): void
    {
        $this->expiration_date = $expiration_date;
    }

    /**
     * @param mixed $fpay_merchant_id
     */
    public function setFpayMerchantId($fpay_merchant_id): void
    {
        $this->fpay_merchant_id = $fpay_merchant_id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $state
     */
    public function setState($state): void
    {
        $this->state = $state;
    }

    public function jsonEncodeFromCreateInServer()
    {
        return json_encode([
            'intent' => $this->intent,
            'payment_method' => $this->payment_method,
            'pst_origen' => $this->pst_origen,
            'buyer' => $this->buyer,
            'transaction' => $this->transaction,
            'redirect_urls' => $this->redirect_urls
        ]);
    }

    /**
     * @return string
     * @throws FpayNotFoundLinkTypeException
     */
    public function getFpayCheckoutUrl(): string
    {
        return $this->searchUrlTypeInLinks(Link::REL_APPROVAL_URL);
    }

    /**
     * @return string
     * @throws FpayNotFoundLinkTypeException
     */
    public function getSelfUrl(): string
    {
        return $this->searchUrlTypeInLinks(Link::REL_SELF_URL);
    }

    /**
     * @param $url_type
     * @return string
     * @throws FpayNotFoundLinkTypeException
     */
    public function searchUrlTypeInLinks($url_type): string
    {
        $redirect_url = '';
        foreach ($this->links as $link) {
            if ($link->getRel() === $url_type) {
                $redirect_url = $link->getHref();
                break;
            }
        }

        if ($redirect_url === '') {
            $exception = $this->container->make(FpayNotFoundLinkTypeException::class, [
                'logger' => $this->logger,
                'error_data' => 'The redirect url does not match with the key [' . $url_type . ']'
            ]);
            $exception->sendMessage();
            throw $exception;
        }

        return $redirect_url;
    }

    /**
     * @return AbstractTransaction
     */
    public function getTransaction(): AbstractTransaction{
        return $this->transaction;
    }

    public function getState(): string
    {
        return $this->state;
    }

    public function getPaymentType(): string
    {
        return $this->payment_type;
    }

    public function getPaymentInformationScheme(): string
    {
        $paymentInformationScheme =  "";
        if ($this->gateway) {
            $paymentInformationScheme = $this->getGateway()->getFraudAssessment() ? 
            $this->getGateway()->getPaymentMethod() : "";
        }
        return $paymentInformationScheme;
    }

    public function getGateway(): AbstractGateway
    {
        return $this->gateway;
    }

    public function setGateway($gateway): void
    {
        $this->gateway = $gateway;
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getApplication(): string
    {
        return $this->application;
    }
}