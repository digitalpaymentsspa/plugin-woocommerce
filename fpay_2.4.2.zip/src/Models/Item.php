<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractItem;

defined('ABSPATH') || exit;

class Item implements AbstractItem, \JsonSerializable
{
    private $sku;
    private $name;
    private $description;
    private $quantity;
    private $price;
    private $tax;
    private $category;

    /**
     * @param $sku
     * @param $name
     * @param $description
     * @param $quantity
     * @param $price
     * @param $tax
     * @param $category
     */
    public function __construct($sku, $name, $description, $quantity, $price, $tax, $category)
    {
        $this->sku = $sku;
        $this->name = $name;
        $this->description = $description;
        $this->quantity = $quantity;
        $this->price = $price;
        $this->tax = $tax;
        $this->category = $category;
    }


    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}