<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractShippingAddress;

defined('ABSPATH') || exit;

class ShippingAddress implements AbstractShippingAddress, \JsonSerializable
{
    private $address_type;
    private $line1;
    private $city;
    private $country_code;
    private $phone;
    private $recipient_name;

    public function __construct(
        $address_type,
        $line1,
        $city,
        $country_code,
        $phone,
        $recipient_name
    ){
        $this->address_type  = $address_type;
        $this->line1 = $line1;
        $this->city = $city;
        $this->country_code = $country_code;
        $this->phone = $phone;
        $this->recipient_name = $recipient_name;
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}