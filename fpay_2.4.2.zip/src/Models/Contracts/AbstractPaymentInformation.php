<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractPaymentInformation
{ 
    public function getScheme(): string;
}