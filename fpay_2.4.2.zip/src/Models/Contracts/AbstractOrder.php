<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractOrder
{
    const PROCESSING_STATUS = 'processing';
    const COMPLETED_STATUS = 'completed';

    const REFUNDED_STATUS = 'refunded';
    const CANCELLED_STATUS = 'cancelled';
    const FAILED_STATUS = 'failed';
    const PENDING_STATUS = 'pending';
}