<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractFpayIntent
{
    const INTENT_SALE = 'sale';
    const STATE_CREATED = 'created';
    const STATE_PAID = 'paid';
    const STATE_REFUNDED = 'refunded';
    const STATE_PARTIAL_REFUNDED = 'partially_refunded';
    const STATE_REVERSED = 'reversed';
    const STATE_CANCELLED = 'cancelled';
    const STATE_REJECTED = 'rejected';
    const STATE_VOIDED = 'voided';
    const STATE_EXPIRED = 'expired';

    public function jsonEncodeFromCreateInServer();

    public function setRedirectUrls($redirect_urls);

    public function setLinks($links);

    public function setApplication($application): void;

    public function setInvoiceNumber($invoice_number): void;

    public function setCreateTime($create_time): void;

    public function setUpdateTime($update_time): void;

    public function setExpirationDate($expiration_date): void;

    public function setFpayMerchantId($fpay_merchant_id): void;

    public function setId($id): void;

    public function getFpayCheckoutUrl(): string;

    public function getSelfUrl(): string;

    public function searchUrlTypeInLinks($url_type): string;

    public function getTransaction(): AbstractTransaction;

    public function getState(): string;

    public function getPaymentType(): string;

    public function getPaymentInformationScheme(): string;

    public function getGateway(): AbstractGateway;

    public function setGateway($gateway): void;

    public function getId():string;

    public function getApplication():string;
}