<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractTransaction
{
    const SHIPPING_METHOD_DIGITAL = 'DIGITAL';
    const DESCRIPTION = 'Compra woocommerce';
    const TERMINAL_ID = 1;
    const STORE_ID = 1;
    const DEFERRED_CAPTURE_FALSE = 0;

    public function buildMerchantUniqueId($order_id): string;

    public function setMerchantUniqueId($merchant_unique_id);

    public function getPurchaseOrder(): string;
}