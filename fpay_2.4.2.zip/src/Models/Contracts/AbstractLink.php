<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractLink
{
    const REL_APPROVAL_URL = 'approval_url';
    const REL_SELF_URL = 'self';

    public function setSecurityArray($security): void;

    public function getRel(): string;
}