<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractItem
{

}