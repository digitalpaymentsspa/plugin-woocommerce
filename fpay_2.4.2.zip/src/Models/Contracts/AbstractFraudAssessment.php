<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractFraudAssessment
{ 
    public function getFraudAssessmentMetadata(): AbstractFraudAssessmentMetadata;
}