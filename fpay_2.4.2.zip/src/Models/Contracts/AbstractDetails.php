<?php

namespace Fpay\Woocommerce\Models\Contracts;

interface AbstractDetails
{
    const TAX_CERO = 0;
    const DISCOUNT_CERO = 0;
}