<?php

namespace Fpay\Woocommerce\Models;

use Fpay\Woocommerce\Models\Contracts\AbstractPaymentInformation;

defined('ABSPATH') || exit;

class PaymentInformation implements AbstractPaymentInformation, \JsonSerializable
{
    protected $scheme;    

    public function __construct(string $scheme){
        $this->scheme = $scheme;        
    }

    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

    public function getScheme(): string
    {
        return $this->scheme;
    }
}