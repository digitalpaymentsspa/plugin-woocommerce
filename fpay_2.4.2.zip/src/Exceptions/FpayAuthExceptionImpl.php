<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayAuthException;

defined('ABSPATH') || exit;

class FpayAuthExceptionImpl extends FpayException implements FpayAuthException
{
    public function sendMessage()
    {
        wc_add_notice(self::ERROR_FOR_HUMANS_MESSAGE . self::ERROR_KEY_1, 'error');
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_1);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
    }
}