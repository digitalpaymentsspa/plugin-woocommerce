<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;


interface FpayNotFoundLinkTypeException
{
    public function sendMessage();
}