<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayOverDraftRefundException
{
    public function sendMessage();
}