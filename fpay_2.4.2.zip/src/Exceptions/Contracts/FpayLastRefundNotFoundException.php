<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayLastRefundNotFoundException
{
    public function sendMessage();
}