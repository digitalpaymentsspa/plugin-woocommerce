<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayRefundWebhookException
{
    public function sendMessage();
}