<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayFactoryException
{
    public function sendMessage();
}