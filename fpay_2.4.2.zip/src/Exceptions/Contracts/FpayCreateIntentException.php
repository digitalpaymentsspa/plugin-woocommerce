<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayCreateIntentException
{
    public function sendMessage();
}