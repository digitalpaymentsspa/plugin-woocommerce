<?php

namespace Fpay\Woocommerce\Exceptions\Contracts;

interface FpayAuthException
{
    public function sendMessage();
}
