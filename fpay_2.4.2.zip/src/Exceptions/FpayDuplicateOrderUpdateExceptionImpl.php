<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayDuplicateOrderUpdateException;
use Fpay\Woocommerce\Models\Contracts\AbstractOrder;

defined('ABSPATH') || exit;

class FpayDuplicateOrderUpdateExceptionImpl extends FpayException implements FpayDuplicateOrderUpdateException
{
    private int $order_id;
    private string $incoming_state;

    public function __construct($incoming_state, $order_id, $logger = null, $error_data = "", $message = "", $code = 0, \Throwable $previous = null)
    {
        $this->incoming_state = $incoming_state;
        $this->order_id = $order_id;
        parent::__construct($logger, $error_data, $message, $code, $previous);
    }

    public function sendMessage()
    {
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_15);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
       $this->redirect();
    }

    public function redirect()
    {
        if($this->incoming_state === AbstractOrder::PROCESSING_STATUS){
            $order = wc_get_order($this->order_id);
            $redirect_url =  $order->get_checkout_order_received_url();
            wp_safe_redirect($redirect_url);
            return;
        }
        wp_safe_redirect(wc_get_checkout_url());
    }

}