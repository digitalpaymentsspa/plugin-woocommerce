<?php

namespace Fpay\Woocommerce\Exceptions;

use Fpay\Woocommerce\Exceptions\Contracts\FpayHasPreviousIntentException;

defined('ABSPATH') || exit;

class FpayHasPreviousIntentExceptionImpl extends FpayException implements FpayHasPreviousIntentException
{
    public function sendMessage()
    {
        wc_add_notice(self::ERROR_FOR_HUMANS_MESSAGE . self::ERROR_KEY_5, 'error');
        $this->logger->error(get_class($this) . self::ERROR_FOR_LOGS_MESSAGE . self::ERROR_KEY_5);
        $this->logger->error(get_class($this) . ': ' . $this->error_data);
    }
}