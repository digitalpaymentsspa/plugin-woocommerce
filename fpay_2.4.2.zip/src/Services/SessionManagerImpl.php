<?php

namespace Fpay\Woocommerce\Services;

use DI\Container;
use Fpay\Woocommerce\Exceptions\Contracts\FpayDataInSessionNotFoundException;
use Fpay\Woocommerce\FpayGatewayImpl;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Monolog\Logger;

class SessionManagerImpl implements SessionManager
{
    protected Container $container;
    protected Logger $logger;

    public function __construct(Container $container, Logger $logger){
        $this->container = $container;
        $this->logger = $logger;
    }

    /**
     * @param $uuid
     * @param $order_id
     * @param $self_link
     */
    public function saveDataInSession($uuid, $order_id, $self_link): void
    {
        WC()->session->set($uuid . FpayGatewayImpl::ORDER_ID_KEY, $order_id);
        WC()->session->set($uuid . FpayGatewayImpl::SELF_LINK_KEY, $self_link);
    }

    /**
     * @return array
     * @throws \DI\DependencyException
     * @throws \DI\NotFoundException
     * @throws FpayDataInSessionNotFoundException
     */
    public function getDataFromSession($uuid): array
    {
        $order_id = WC()->session->get($uuid . FpayGatewayImpl::ORDER_ID_KEY);
        $self_link = WC()->session->get($uuid . FpayGatewayImpl::SELF_LINK_KEY);

        $is_valid = $this->validateIfTheSessionDataIsCorrect($order_id, $self_link);

        if (!$is_valid) {
            $exception = $this->container->make(FpayDataInSessionNotFoundException::class, [
                'logger' => $this->logger,
                'error_data' => json_encode([
                    'uuid' => $uuid,
                ])
            ]);

            $exception->sendMessage();
            throw $exception;
        }

        return array(FpayGatewayImpl::ORDER_ID_KEY => $order_id, FpayGatewayImpl::SELF_LINK_KEY => $self_link);
    }

    /**
     * @param $order_id
     * @param $self_link
     * @return bool
     */
    public function validateIfTheSessionDataIsCorrect($order_id, $self_link): bool
    {
        if ($order_id === null || $self_link === null) {
            return false;
        }

        if (!wc_get_order($order_id)) {
            return false;
        }
        return true;
    }

}