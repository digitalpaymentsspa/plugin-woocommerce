<?php

namespace Fpay\Woocommerce\Services;

use Fpay\Woocommerce\Exceptions\Contracts\FpayOverDraftRefundException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayPartialRefundException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayRefundIntentStateNotValidException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayRefundWebhookException;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Services\Contracts\FpayAuth;
use Fpay\Woocommerce\Services\Contracts\FpayIntentManager;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Traits\PaymentStates;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\BadResponseException;
use GuzzleHttp\Psr7\Message;
use Monolog\Logger;

defined('ABSPATH') || exit;

class RefundManagerImpl implements RefundManager
{
    use PaymentStates;

    private $http_client;
    private $base_url;
    private $partial_refund_url;
    private $logger;
    private $container;
    private $fpay_factory;
    private $fpay_auth;
    private $settings;
    private $fpay_intent_manager;

    /**
     * @param Client $http_client
     * @param string $base_url
     * @param string $partial_refund_url
     * @param Logger $logger
     * @param $container
     * @param $fpay_factory
     * @param FpayAuth $fpay_auth
     * @param array $settings
     * @param FpayIntentManager $fpay_intent_manager
     */
    public function __construct(
        Client            $http_client,
        string            $base_url,
        string            $partial_refund_url,
        Logger            $logger,
                          $container,
                          $fpay_factory,
        FpayAuth          $fpay_auth,
        array             $settings,
        FpayIntentManager $fpay_intent_manager
    )
    {
        $this->http_client = $http_client;
        $this->base_url = $base_url;
        $this->partial_refund_url = $partial_refund_url;
        $this->logger = $logger;
        $this->container = $container;
        $this->fpay_factory = $fpay_factory;
        $this->fpay_auth = $fpay_auth;
        $this->settings = $settings;
        $this->fpay_intent_manager = $fpay_intent_manager;
    }

    public function loadCredentials(): string
    {
        $this->fpay_auth->authInServer(
            $this->settings['public_key'],
            $this->settings['private_key']

        );
        return $this->fpay_auth->getBearerToken();
    }

    public function processRefund(AbstractRefund $refund, $reason = ''): AbstractFpayIntent
    {
        $this->logger->info('RefundManagerImpl@partialRefund starts the process to partial refund');

        $bearer_token = $this->loadCredentials();

        $fpay_intent = $this->fpay_intent_manager->getFpayIntentFromId(
            $bearer_token,
            $refund->getFpayIntentionId()
        );

        if ($this->isIntentInSomePaymentState($fpay_intent) === false) {
            $exception = $this->container->make(FpayRefundIntentStateNotValidException::class, [
                'logger' => $this->logger,
                'error_data' => [
                    'reason' => 'The intention is not in a valid payment state',
                    'fpay_intent_status' => $fpay_intent->getState(),
                    'fpay_intent_id' => $fpay_intent->getId(),
                ]
            ]);

            $exception->sendMessage();
            throw $exception;
        }

        return $this->makePartialRefundInServer($refund, $reason);
    }

    public function makePartialRefundInServer(AbstractRefund $refund, $reason = ''): AbstractFpayIntent
    {
        try {
            $this->logger->info('RefundManagerImpl@partialRefund starts the process to partial refund in Server');
            $bearer_token = $this->loadCredentials();

            $options = [
                'headers' => array(
                    'Authorization' => 'Bearer' . ' ' . $bearer_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => $refund->jsonEncodeFromCreateInServer()
            ];

            $partial_url = str_replace(
                self::REPLACE_URL_PATTERN,
                $refund->getFpayIntentionId(),
                $this->partial_refund_url
            );

            $url = $this->base_url . $partial_url;

            $this->logger->info('RefundManagerImpl@partialRefund', [
                'url' => $url
            ]);

            $request = $this->http_client->request(
                'POST',
                $url,
                $options
            );

            $response = json_decode($request->getBody()->getContents());
            $fpay_intent = $this->fpay_factory->createFpayIntent($response);

        } catch (BadResponseException $exception) {

            $fpay_auth_exception = $this->container->make(FpayPartialRefundException::class, [
                'logger' => $this->logger,
                'error_data' => Message::toString($exception->getResponse())
            ]);
            $fpay_auth_exception->sendMessage();
            throw $fpay_auth_exception;

        } catch (\Exception $exception) {

            $fpay_auth_exception = $this->container->make(FpayPartialRefundException::class, [
                'logger' => $this->logger,
                'error_data' => $exception
            ]);
            $fpay_auth_exception->sendMessage();
            throw $fpay_auth_exception;
        }

        return $fpay_intent;
    }

    public function processRefundViaWebhook(
        AbstractFpayIntent $fpay_intent,
        array              $order_refunds_from_fpay,
                           $total_refunded,
                           $total_order_value
    ): array
    {
        $this->logger->info(
            'RefundManagerImpl@processsRefundViaWebhook starts the process to do a partial refund via webhook', [
                'fpay_intent_id' => $fpay_intent->getId()
            ]
        );

        $bearer_token = $this->loadCredentials();

        $fpay_intent_from_server = $this->fpay_intent_manager->getFpayIntentFromId(
            $bearer_token,
            $fpay_intent->getId()
        );


        if ($this->isIntentInSomePaymentState($fpay_intent_from_server) === false) {
            $exception = $this->container->make(FpayRefundIntentStateNotValidException::class, [
                'logger' => $this->logger,
                'error_data' => [
                    'reason' => 'The intention is not in a valid payment state',
                    'fpay_intent_status' => $fpay_intent_from_server->getState(),
                    'fpay_intent_id' => $fpay_intent_from_server->getId(),
                ]
            ]);

            $exception->sendMessage();
            throw $exception;
        }

        $pending_refunds_to_apply = $this->getPendingRefundsToApplyInWoocommerce(
            $fpay_intent_from_server->getGateway()->getRefunds(),
            $order_refunds_from_fpay
        );


        if (empty($pending_refunds_to_apply)) {
            $exception = $this->container->make(FpayRefundWebhookException::class, [
                'logger' => $this->logger,
                'error_data' => json_encode([
                    'reason' => 'Does not exist pending refunds to apply',
                    'total_refunded' => $total_refunded,
                    'order_refunds_from_fpay' => $order_refunds_from_fpay,
                    'refunds_from_fpay' => $fpay_intent_from_server->getGateway()->getRefunds(),
                ])
            ]);
            $exception->sendMessage();
            throw $exception;
        }

        $pending_value_from_pending_refunds = $this->getTotalToRefund($pending_refunds_to_apply);
        $pending_value_to_refund = $total_order_value - ($total_refunded + $pending_value_from_pending_refunds);

        if ($pending_value_to_refund < 0) {
            $exception = $this->container->make(FpayOverDraftRefundException::class, [
                'logger' => $this->logger,
                'error_data' => json_encode([
                    'reason' => 'The pending value to refund is not valid',
                    'pending_value_to_refund' => $pending_value_to_refund,
                    'total_order_value' => $total_order_value,
                    'total_refunded' => $total_refunded,
                    'pending_value_from_pending_refunds' => $pending_value_from_pending_refunds,
                ])
            ]);
            $exception->sendMessage();
            throw $exception;
        }

        return $pending_refunds_to_apply;

    }

    public function getPendingRefundsToApplyInWoocommerce(array $fpay_refunds, array $order_refunds): array
    {
        $this->logger->info('RefundManager@getPendingRefundsToApplyInWoocommerce', [
            'refunds_fpay_quantity' => count($fpay_refunds),
            'fpay_refunds' => $fpay_refunds,
        ]);

        $this->logger->info('RefundManager@getPendingRefundsToApplyInWoocommerce', [
            'order_refunds_quantity' => count($order_refunds),
            'order_refunds' => $order_refunds,
        ]);


        $pending_refunds = array_udiff($fpay_refunds, $order_refunds, array($this, 'filter_pending'));


        $this->logger->info('RefundManager@getPendingRefundsToApplyInWoocommerce', [
            'pending_refunds_quantity' => count($pending_refunds),
            'pending_refunds' => $pending_refunds,
        ]);

        return $pending_refunds;
    }

    public function filter_pending($refund_a, $refund_b): int
    {

        if ($refund_a->getAuthorizationId() === $refund_b->getAuthorizationId()) {
            return 0;
        }

        return ($refund_a->getAuthorizationId() > $refund_b->getAuthorizationId()) ? 1 : -1;
    }

    public function getTotalToRefund(array $refunds): float
    {
        $total_refunded = 0;

        foreach ($refunds as $refund) {
            $total_refunded += $refund->getRefundedAmount();
        }
        return $total_refunded;
    }
}