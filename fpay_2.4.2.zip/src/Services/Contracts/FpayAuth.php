<?php

namespace Fpay\Woocommerce\Services\Contracts;

use stdClass;

interface FpayAuth
{
    /**
     * @param string $public_key
     * @param string $private_key
     */
    public function authInServer(string $public_key, string $private_key): void;

    /**
     * @return string
     */
    public function getBearerToken(): string;

    /**
     * @param $access_token
     */
    public function setBearerToken($access_token): void;
}