<?php

namespace Fpay\Woocommerce\Services\Contracts;

interface SessionManager
{
    /**
     * @param $uuid
     * @param $order_id
     * @param $self_link
     */
    public function saveDataInSession($uuid, $order_id, $self_link): void;

    /**
     * @return array
     */
    public function getDataFromSession(string $uuid):array;

    /**
     * @param $order_id
     * @param $self_link
     * @return bool
     */
    public function validateIfTheSessionDataIsCorrect($order_id, $self_link): bool;

}