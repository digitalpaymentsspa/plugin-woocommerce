<?php

namespace Fpay\Woocommerce\Services;

use DI\Container;
use Fpay\Woocommerce\Exceptions\Contracts\FpayInconsistentDataException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayInconsistentPaymentSuccessException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayIntentDoesNotBelongsToPaymentGatewayException;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractOrder;
use Fpay\Woocommerce\Models\Contracts\AbstractRefund;
use Fpay\Woocommerce\Services\Contracts\FpayAuth;
use Fpay\Woocommerce\Services\Contracts\FpayIntentManager;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;
use Fpay\Woocommerce\Services\Contracts\Webhook;
use Monolog\Logger;

defined('ABSPATH') || exit;

class WebhookImpl implements Webhook
{
    protected Logger $logger;
    protected Container $container;
    protected FpayIntentManager $fpay_intent_manager;
    protected FpayAuth $fpay_auth;
    protected array $settings;
    protected FpayOrderContext $context;
    protected WoocommerceRefundsManager $woocommerce_refunds_manager;
    protected RefundManager $refund_manager;
    protected array $plugin_config;

    /**
     * @param $logger
     * @param $container
     * @param $fpay_intent_manager
     * @param $fpay_auth
     * @param $settings
     * @param $context
     */
    public function __construct(
        $logger,
        $container,
        $fpay_intent_manager,
        $fpay_auth, $settings,
        $context,
        $woocommerce_refunds_manager,
        $refund_manager,
        $plugin_config
    )
    {
        $this->logger = $logger;
        $this->container = $container;
        $this->fpay_intent_manager = $fpay_intent_manager;
        $this->fpay_auth = $fpay_auth;
        $this->settings = $settings;
        $this->context = $context;
        $this->woocommerce_refunds_manager = $woocommerce_refunds_manager;
        $this->refund_manager = $refund_manager;
        $this->plugin_config = $plugin_config;
    }

    public function loadCredentials(): string
    {
        $this->fpay_auth->authInServer(
            $this->settings['public_key'],
            $this->settings['private_key']

        );
        return $this->fpay_auth->getBearerToken();
    }

    public function processFpayIntent($order, $self_link): void
    {
        $this->logger->info('WebhookImpl@processFpayIntent');

        $bearer_token = $this->loadCredentials();
        $fpay_intent = $this->fpay_intent_manager->getFpayIntentFromSelfUrl($bearer_token, $self_link);

        $this->logger->info('WebhookImpl@processFpayIntent', [
            'fpay_intent_id' => $fpay_intent->getId(),
            'fpay_state' => $fpay_intent->getState()
        ]);

        $this->checkIfBelongsToPaymentGateway($fpay_intent->getId(), $order->get_payment_method(), $this->plugin_config['plugin_id']);

        $data = [
            'fpay_intent_id' => $fpay_intent->getId(),
            'fpay_state' => $fpay_intent->getState(),
            'payment_method' => $fpay_intent->getPaymentInformationScheme(),
        ];

        switch ($fpay_intent->getState()) {
            case AbstractFpayIntent::STATE_PARTIAL_REFUNDED:
            case AbstractFpayIntent::STATE_REFUNDED:
                $strategy = $this->container->make(FpayOrderContext::REFUND_WEBHOOK_STRATEGY, [
                    'logger' => $this->logger
                ]);
                $this->processRefunds($order, $fpay_intent, $strategy, $data);
                break;
            case AbstractFpayIntent::STATE_PAID:
                $strategy = $this->container->make(FpayOrderContext::PAID_STRATEGY, [
                    'logger' => $this->logger,
                    'container' => $this->container,
                    'incoming_state' => AbstractOrder::PROCESSING_STATUS,
                ]);
                $this->processFpayIntentSuccess($order, $fpay_intent, $strategy, $data);
                break;
            case AbstractFpayIntent::STATE_REJECTED:
            case AbstractFpayIntent::STATE_VOIDED:
            case AbstractFpayIntent::STATE_EXPIRED:
                $strategy = $this->container->make(FpayOrderContext::FAIL_STRATEGY, [
                    'logger' => $this->logger,
                    'container' => $this->container,
                    'incoming_state' => AbstractOrder::FAILED_STATUS,
                ]);
                $this->processOthersStatesOfFpayIntent($order, $fpay_intent, $strategy, $data);
                break;
            default:
                /**
                 * STATE_CANCELLED
                 */
                $strategy = $this->container->make(FpayOrderContext::CANCEL_STRATEGY, [
                    'logger' => $this->logger,
                    'container' => $this->container,
                    'incoming_state' => AbstractOrder::CANCELLED_STATUS,
                ]);
                $this->processOthersStatesOfFpayIntent($order, $fpay_intent, $strategy, $data);
                break;
        }
    }

    public function checkIfBelongsToPaymentGateway(
        $fpay_intent_id,
        $plugin_id_related_to_order,
        $current_plugin_id
    ): void
    {
        if ($plugin_id_related_to_order !== $current_plugin_id) {
            $exception = $this->container->make(FpayIntentDoesNotBelongsToPaymentGatewayException::class, [
                'logger' => $this->logger,
                'error_data' => json_encode([
                    'fpay_intent_id' => $fpay_intent_id,
                    'plugin_id_related_to_order' => $plugin_id_related_to_order,
                    'current_plugin_id' => $current_plugin_id,
                ]),
            ]);

            $exception->sendMessage();
            throw $exception;
        }
    }

    public function processRefunds($order, $fpay_intent, $strategy, $data): void
    {
        $this->logger->info('WebhookImpl@refund_webhook', [
            'data' => $data
        ]);

        $order_refunds = $order->get_refunds();
        $order_refunds_from_fpay = $this->woocommerce_refunds_manager->filterRefundsViaFpay($order_refunds, $fpay_intent->getId());
        $total_refunded = $order->get_total_refunded();


        $pending_refunds = $this->refund_manager->processRefundViaWebhook(
            $fpay_intent,
            $order_refunds_from_fpay,
            $total_refunded,
            $order->get_total()
        );

        $this->logger->info('Webhook@refund_webhook', [
            'pending_refunds_quantity' => count($pending_refunds),
            'pending_refunds' => $pending_refunds

        ]);

        foreach ($pending_refunds as $pending_refund) {
            $this->logger->info('Webhook@refund_webhook - foreach', [
                'pending_refund' => $pending_refund
            ]);
            $this->makeRefundViaStrategy($order, $pending_refund, $strategy, $data);
        }
    }

    public function makeRefundViaStrategy($order, AbstractRefund $refund, $strategy, $data): void
    {
        $reason = 'Devolución realizada desde el portal comercios.';

        $refund_data = array(
            'refunded_amount' => $refund->getRefundedAmount(),
            'reason' => $reason,
            'authorization_id' => $refund->getAuthorizationId(),
            'state' => $refund->getState(),
        );

        $final_data = array_merge($data, $refund_data);

        $this->context->setStrategy($strategy);
        $this->context->updateOrderStatus($order, $final_data);

    }


    public function processFpayIntentSuccess($order, $fpay_intent, $strategy, $data): void
    {

        $this->logger->info('WebhookImpl@processFpayIntentSuccess');

        $purchase_order_id = intval($fpay_intent->getTransaction()->getPurchaseOrder());

        $order_id = intval($order->get_id());

        if ($purchase_order_id !== $order_id) {
            $exception = $this->container->make(FpayInconsistentDataException::class, [
                'logger' => $this->logger,
                'error_data' => json_encode([
                    'order' => $order_id,
                    'purchase_order_id' => $purchase_order_id,
                    'self_link' => $fpay_intent->getSelfUrl(),
                ]),
            ]);

            $exception->sendMessage();
            throw $exception;
        }

        $this->context->setStrategy($strategy);
        $this->context->updateOrderStatus($order, $data);
    }

    public function processOthersStatesOfFpayIntent($order, $fpay_intent, $strategy, $data): void
    {
        $this->logger->info('Webhook@processOthersStatesOfFpayIntent');
        $this->context->setStrategy($strategy);
        $this->context->updateOrderStatus($order, $data);
    }

    public function getFpayOrderContext(): FpayOrderContext
    {
        return $this->context;
    }
}