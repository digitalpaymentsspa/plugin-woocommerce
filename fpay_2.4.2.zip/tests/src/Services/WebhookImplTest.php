<?php

use Fpay\Woocommerce\Exceptions\Contracts\FpayInconsistentDataException;
use Fpay\Woocommerce\Exceptions\Contracts\FpayIntentDoesNotBelongsToPaymentGatewayException;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Models\Contracts\AbstractOrder;
use Fpay\Woocommerce\Models\Contracts\AbstractTransaction;
use Fpay\Woocommerce\Services\Contracts\RefundManager;
use Fpay\Woocommerce\Services\Contracts\WoocommerceRefundsManager;
use Fpay\Woocommerce\Services\FpayIntentManagerImpl;
use Fpay\Woocommerce\Services\WebhookImpl;
use Fpay\Woocommerce\Strategies\Contracts\FpayOrderContext;
use Fpay\Woocommerce\Strategies\FpayOrderContextImpl;
use function Brain\Monkey\Functions\expect as expect_woocommerce;
use function Fpay\Woocommerce\Config\config;

it('checks when the Fpay intent has corrupt data', function(){
    /**
     * Arrange
     */
    expect_woocommerce('wc_add_notice')
    ->once()
    ->with(ERROR_FOR_HUMANS_MESSAGE . ERROR_KEY_9, 'error');

    expect_woocommerce('wc_get_checkout_url')->once();
    expect_woocommerce('wp_safe_redirect')->once();

    $transacion_spy = Mockery::spy(AbstractTransaction::class);
    $transacion_spy->shouldReceive('getPurchaseOrder')->andReturn('370');

    $fpay_intent_spy = Mockery::spy(AbstractFpayIntent::class);
    $fpay_intent_spy->shouldReceive('getTransaction')->andReturn($transacion_spy);

    $wc_order_spy = createWcOrderSpy('560', '437363637');

    $data = [
        'fpay_intent_id' => '2212121',
        'fpay_state' => AbstractFpayIntent::STATE_PAID,
    ];

    $strategy = $this->container->make(FpayOrderContext::PAID_STRATEGY, [
        'logger' => $this->logger,
        'container' => $this->container,
        'incoming_state' => AbstractOrder::PROCESSING_STATUS,
    ]);

    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManagerImpl::class)->makePartial();
    $fpay_auth_spy = createFpayAuthSpy();
    $settings = createSettingsMock();
    $fpay_order_context_spy = Mockery::spy(new FpayOrderContextImpl());

    $woocommerce_refunds_maanger = Mockery::spy(WoocommerceRefundsManager::class);
    $refund_manager = Mockery::spy(RefundManager::class);

    /** @var WebhookImpl $webhook_spy */
    $webhook_spy = Mockery::mock(WebhookImpl::class, [
        $this->logger,
        $this->container,
        $fpay_intent_manager_spy,
        $fpay_auth_spy,
        $settings,
        $fpay_order_context_spy,
        $woocommerce_refunds_maanger,
        $refund_manager,
        config()
    ])->makePartial();

    /**
     * Act
     */
    $exception_to_assert = null;
    try{
        $webhook_spy->processFpayIntentSuccess($wc_order_spy, $fpay_intent_spy, $strategy, $data);
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeInstanceOf(FpayInconsistentDataException::class);
});

it('checks when the order payment id does not belongs to the current payment gateway', function(){
    /**
     * Arrange
     */


    /** @var FpayIntentManagerImpl | \Mockery\Mock $fpay_intent_manager_spy */
    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManagerImpl::class)->makePartial();
    $fpay_auth_spy = createFpayAuthSpy();
    $settings = createSettingsMock();
    $fpay_order_context_spy = Mockery::spy(new FpayOrderContextImpl());

    $woocommerce_refunds_maanger = Mockery::spy(WoocommerceRefundsManager::class);
    $refund_manager = Mockery::spy(RefundManager::class);

    /** @var WebhookImpl $webhook_spy */
    $webhook_spy = Mockery::mock(WebhookImpl::class, [
        $this->logger,
        $this->container,
        $fpay_intent_manager_spy,
        $fpay_auth_spy,
        $settings,
        $fpay_order_context_spy,
        $woocommerce_refunds_maanger,
        $refund_manager,
        config()
    ])->makePartial();
    $fpay_intent_id_mock = '633e15950388b9402e0cc915';
    $plugin_id_related_to_order = 'fpay-gateway-2';
    $current_plugin_id = 'fpay-gateway';
    /**
     * Act
     */
    $exception_to_assert = null;
    try{
        $webhook_spy->checkIfBelongsToPaymentGateway($fpay_intent_id_mock, $plugin_id_related_to_order, $current_plugin_id );
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeInstanceOf(FpayIntentDoesNotBelongsToPaymentGatewayException::class);
});

it('checks when the order payment id belongs to the current payment gateway', function(){
    /**
     * Arrange
     */


    /** @var FpayIntentManagerImpl | \Mockery\Mock $fpay_intent_manager_spy */
    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManagerImpl::class)->makePartial();
    $fpay_auth_spy = createFpayAuthSpy();
    $settings = createSettingsMock();
    $fpay_order_context_spy = Mockery::spy(new FpayOrderContextImpl());

    $woocommerce_refunds_maanger = Mockery::spy(WoocommerceRefundsManager::class);
    $refund_manager = Mockery::spy(RefundManager::class);

    /** @var WebhookImpl $webhook_spy */
    $webhook_spy = Mockery::mock(WebhookImpl::class, [
        $this->logger,
        $this->container,
        $fpay_intent_manager_spy,
        $fpay_auth_spy,
        $settings,
        $fpay_order_context_spy,
        $woocommerce_refunds_maanger,
        $refund_manager,
        config()
    ])->makePartial();
    $fpay_intent_id_mock = '633e15950388b9402e0cc915';
    $plugin_id_related_to_order = 'fpay-gateway';
    $current_plugin_id = 'fpay-gateway';
    /**
     * Act
     */
    $exception_to_assert = null;
    try{
        $webhook_spy->checkIfBelongsToPaymentGateway($fpay_intent_id_mock, $plugin_id_related_to_order, $current_plugin_id );
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }
    /**
     * Assert
     */
    expect($exception_to_assert)->toBeNull();
});