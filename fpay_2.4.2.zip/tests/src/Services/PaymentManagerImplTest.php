<?php

use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\Models\Contracts\AbstractFpayIntent;
use Fpay\Woocommerce\Services\Contracts\FpayIntentManager;
use Fpay\Woocommerce\Services\PaymentManagerImpl;
use function Fpay\Woocommerce\Config\config;


beforeEach(function () {
    /** @var FpayWoocommerceFactory fpay_woocommerce_real_factory */
    $this->fpay_woocommerce_real_factory = createFpayWoocommerceFactoryInstance($this->container, $this->plugin_config, $this->logger);
    /** @var FpayFactory fpay_real_factory */
    $this->fpay_real_factory = createFpayFactoryInstance($this->container, $this->plugin_config, $this->logger);
});

it('checks the valid urls created for the fpay intent', function () {

    /**
     * Arrange
     */
    $fpay_auth_spy = createFpayAuthSpy();
    $logger_spy = createLoggerSpy();
    $client_mock = createClientMock([]);
    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManager::class);
    $settings_mock = createSettingsMock();

    $fpay_woocommerce_factory_spy = Mockery::spy(FpayWoocommerceFactory::class)->makePartial();

    $payment_manager_spy = Mockery::spy(new PaymentManagerImpl(
        $fpay_auth_spy,
        $settings_mock,
        $logger_spy,
        $client_mock,
        $fpay_woocommerce_factory_spy,
        $fpay_intent_manager_spy,
        config()
    ));

    /**
     * Act
     */
    $urls = $payment_manager_spy->createRedirectUrls(WOOCOMMERCE_DOMAIN, UUID);

    /**
     * Assert
     */
    expect($urls)->toBeArray();

    expect($urls)->toMatchArray(array(
        "return_url" => WOOCOMMERCE_DOMAIN . "?wc-api=" . config('success_api_name') . "&uuid=" . UUID,
        "cancel_url" => WOOCOMMERCE_DOMAIN . "?wc-api=" . config('not_success_api_name') . "&uuid=" . UUID,
    ));

    $payment_manager_spy->shouldHaveReceived('createRedirectUrls')
        ->once();

});

it('checks the loadCredentials method', function () {

    /**
     * Arrange
     */
    $fpay_auth_spy = createFpayAuthSpy();
    $logger_spy = createLoggerSpy();
    $client_mock = createClientMock([]);
    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManager::class);
    $settings_mock = createSettingsMock();
    $fpay_woocommerce_factory_spy = Mockery::spy(FpayWoocommerceFactory::class)->makePartial();

    $payment_manager_spy = Mockery::spy(new PaymentManagerImpl(
        $fpay_auth_spy,
        $settings_mock,
        $logger_spy,
        $client_mock,
        $fpay_woocommerce_factory_spy,
        $fpay_intent_manager_spy,
        config()
    ));

    /**
     * Act
     */
    $bearer_token = $payment_manager_spy->loadCredentials();

    /**
     * Assert
     */
    expect($bearer_token)->toBeString();

    $fpay_auth_spy->shouldHaveReceived('authInServer')
        ->once()
        ->with($settings_mock['public_key'], $settings_mock['private_key']);

    $fpay_auth_spy->shouldHaveReceived('getBearerToken')
        ->once();

});


it('checks the process payment method', function (
    $data_for_create_wc_order,
    $created_fpay_intent_response
) {

    /**
     * Arrange
     */

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $fpay_intent_spy = $this->fpay_woocommerce_real_factory->createFpayIntent($wc_order_spy);

    $fpay_auth_spy = createFpayAuthSpy();
    $logger_spy = createLoggerSpy();
    $client_mock = createClientMock([]);
    $settings_mock = createSettingsMock();

    $fpay_woocommerce_factory_spy = Mockery::spy(FpayWoocommerceFactory::class)->makePartial();
    $fpay_woocommerce_factory_spy->shouldReceive('createFpayIntent')
        ->andReturn($fpay_intent_spy);

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $created_fpay_intent_spy = $this->fpay_real_factory->createFpayIntent($fpay_intent_data_hidrated);

    $fpay_intent_manager_spy = Mockery::spy(FpayIntentManager::class)->makePartial();
    $fpay_intent_manager_spy->shouldReceive('createFpayIntentInServer')
        ->andReturn($created_fpay_intent_spy);

    $payment_manager_spy = Mockery::spy(PaymentManagerImpl::class, [
        $fpay_auth_spy,
        $settings_mock,
        $logger_spy,
        $client_mock,
        $fpay_woocommerce_factory_spy,
        $fpay_intent_manager_spy,
        config()
    ])->makePartial();


    /**
     * Act
     */
    $fpay_intent_created_from_server_spy = $payment_manager_spy->processPayment(
        $wc_order_spy,
        WOOCOMMERCE_DOMAIN,
        UUID
    );

    /**
     * Assert
     */
    expect($fpay_intent_created_from_server_spy)->toBeInstanceOf(AbstractFpayIntent::class);

    $payment_manager_spy->shouldHaveReceived('loadCredentials')
        ->once();

    $payment_manager_spy->shouldHaveReceived('createRedirectUrls')
        ->once();

    $fpay_intent_manager_spy->shouldHaveReceived('createFpayIntentInServer')
        ->once();

    expect($fpay_intent_created_from_server_spy->getFpayCheckoutUrl())->toBeString();

})
    ->with('data_for_create_wc_order')
    ->with('created_fpay_intent_response');
