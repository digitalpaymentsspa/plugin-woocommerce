<?php

use Fpay\Woocommerce\Exceptions\Contracts\FpayDataInSessionNotFoundException;
use Fpay\Woocommerce\Services\Contracts\SessionManager;
use Fpay\Woocommerce\Services\SessionManagerImpl;
use function Brain\Monkey\Functions\expect as expect_woocommerce;
use function Fpay\Woocommerce\Config\config;

beforeAll(function () {
    $_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
});

beforeEach(function () {
    /** @var FpayFactory fpay_factory */
    $this->fpay_factory = createFpayFactoryInstance($this->container, $this->plugin_config, $this->logger);
});

afterAll(function () {
    unset($_SERVER['HTTP_USER_AGENT']);
    unset($_GET[UUID_KEY]);
});

it('validate the method getDataFromSession was loaded correctly', function ($created_fpay_intent_response){

    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);
    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    $order_spy_id = $wc_order_spy->get_id();

    $self_url = $fpay_intent->getSelfUrl();
    $session_spy = createWcSessionSpy($self_url, $uuid, $order_spy_id);
    expect_woocommerce('WC')->twice()->andReturn((object)['session' => $session_spy,]);

    /** @var SessionManager  | \Mockery\Mock $session_manager */
    $session_manager = Mockery::spy(SessionManagerImpl::class, [
        $this->container,
        $this->logger
    ])->makePartial();

    $session_manager->shouldReceive('validateIfTheSessionDataIsCorrect')->andReturn(true);

    /**
     * Act
     */
    $exception_to_assert = null;
    try{
        $result = $session_manager->getDataFromSession($uuid);
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }


    /**
     * Assert
     */
    expect($result)->toBeArray();
    expect($exception_to_assert)->toBeNull();
    $session_spy->shouldHaveReceived('get')->twice();

})->with('created_fpay_intent_response');


it('validate the method getDataFromSession was NOT loaded correctly', function ($created_fpay_intent_response){

    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_add_notice')
        ->once()
        ->with(ERROR_FOR_HUMANS_MESSAGE . ERROR_KEY_3, 'error');

    expect_woocommerce('wp_safe_redirect')->once();
    expect_woocommerce('wc_get_checkout_url')->once();

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);
    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    $order_spy_id = $wc_order_spy->get_id();

    $self_url = $fpay_intent->getSelfUrl();
    $session = createWcSessionSpy($self_url, $uuid, $order_spy_id);
    expect_woocommerce('WC')->twice()->andReturn((object)['session' => $session,]);

    /** @var SessionManager  | \Mockery\Mock $session_manager */
    $session_manager = Mockery::spy(SessionManagerImpl::class, [
        $this->container,
        $this->logger
    ])->makePartial();

    $session_manager->shouldReceive('validateIfTheSessionDataIsCorrect')->andReturn(false);

    /**
     * Act
     */
    $exception_to_assert = null;
    $result = null;
    try{
        $result = $session_manager->getDataFromSession($uuid);
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }


    /**
     * Assert
     */
    expect($result)->toBeNull();
    expect($exception_to_assert)->toBeInstanceOf(FpayDataInSessionNotFoundException::class);

})->with('created_fpay_intent_response');

it('validate the method save data in session worked correctly', function ($created_fpay_intent_response){

    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);
    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());
    $order_spy_id = $wc_order_spy->get_id();

    $self_url = $fpay_intent->getSelfUrl();
    $session_spy = createWcSessionSpy($self_url, $uuid, $order_spy_id);
    expect_woocommerce('WC')->twice()->andReturn((object)['session' => $session_spy,]);

    /** @var SessionManager  | \Mockery\Mock $session_manager */
    $session_manager = Mockery::spy(SessionManagerImpl::class, [
        $this->container,
        $this->logger
    ])->makePartial();

    /**
     * Act
     */
    $exception_to_assert = null;
    try{
        $session_manager->saveDataInSession($uuid, $wc_order_spy->get_id(), $fpay_intent->getSelfUrl());
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }


    /**
     * Assert
     */
    expect($exception_to_assert)->toBeNull();
    $session_spy->shouldHaveReceived('set')->twice();

})->with('created_fpay_intent_response');

it('checks when data is correct on the validate if session data is correct method', function ($created_fpay_intent_response){

    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);
    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());

    /** @var SessionManager  | \Mockery\Mock $session_manager */
    $session_manager = Mockery::spy(SessionManagerImpl::class, [
        $this->container,
        $this->logger
    ])->makePartial();

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_get_order')->once()->andReturn($wc_order_spy);

    /**
     * Act
     */
    $exception_to_assert = null;
    $result = false;
    try{
        $result = $session_manager->validateIfTheSessionDataIsCorrect($wc_order_spy->get_id(), $fpay_intent->getSelfUrl());
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }


    /**
     * Assert
     */
    expect($result)->toBeTrue();
    expect($exception_to_assert)->toBeNull();

})->with('created_fpay_intent_response');

it('checks when order_id is null on the validate if session data is correct method', function ($created_fpay_intent_response){

    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);
    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());

    /** @var SessionManager  | \Mockery\Mock $session_manager */
    $session_manager = Mockery::spy(SessionManagerImpl::class, [
        $this->container,
        $this->logger
    ])->makePartial();

    /**
     * Act
     */
    $exception_to_assert = null;
    $result = false;
    try{
        $result = $session_manager->validateIfTheSessionDataIsCorrect(null, $fpay_intent->getSelfUrl());
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }


    /**
     * Assert
     */
    expect($result)->toBeFalse();
    expect($exception_to_assert)->toBeNull();

})->with('created_fpay_intent_response');

it('checks when self_link is null on the validate if session data is correct method', function ($created_fpay_intent_response){

    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);
    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());

    /** @var SessionManager  | \Mockery\Mock $session_manager */
    $session_manager = Mockery::spy(SessionManagerImpl::class, [
        $this->container,
        $this->logger
    ])->makePartial();


    /**
     * Act
     */
    $exception_to_assert = null;
    $result = false;
    try{
        $result = $session_manager->validateIfTheSessionDataIsCorrect($wc_order_spy->get_id(), null);
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }


    /**
     * Assert
     */
    expect($result)->toBeFalse();
    expect($exception_to_assert)->toBeNull();

})->with('created_fpay_intent_response');

it('checks when the order does not exists on the validate if session data is correct method', function ($created_fpay_intent_response){

    /**
     * Arrange
     */
    $uuid = UUID;
    $_GET[UUID_KEY] = $uuid;

    $fpay_intent_data_hidrated = json_decode(json_encode($created_fpay_intent_response['body']));
    $fpay_intent = $this->fpay_factory->createFpayIntent($fpay_intent_data_hidrated);
    $wc_order_spy = createWcOrderSpy($fpay_intent->getTransaction()->getPurchaseOrder(), $fpay_intent->getId());

    /** @var SessionManager  | \Mockery\Mock $session_manager */
    $session_manager = Mockery::spy(SessionManagerImpl::class, [
        $this->container,
        $this->logger
    ])->makePartial();

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_get_order')->withAnyArgs()->once()->andReturn(false);

    /**
     * Act
     */
    $exception_to_assert = null;
    $result = false;
    try{
        $result = $session_manager->validateIfTheSessionDataIsCorrect($wc_order_spy->get_id(), $fpay_intent->getSelfUrl());
    }catch (Exception $exception){
        $exception_to_assert = $exception;
    }

    /**
     * Assert
     */
    expect($result)->toBeFalse();
    expect($exception_to_assert)->toBeNull();
})->with('created_fpay_intent_response');