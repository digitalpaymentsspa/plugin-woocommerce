<?php

use Fpay\Woocommerce\Exceptions\FpayCreateIntentExceptionImpl;
use Fpay\Woocommerce\Exceptions\FpaySelfExceptionImpl;
use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\Models\FpayIntent;
use Mockery\MockInterface;
use Fpay\Woocommerce\Services\FpayIntentManagerImpl;
use function Brain\Monkey\Functions\expect as expect_woocommerce;

beforeEach(function () {
    /** @var FpayWoocommerceFactory fpay_woocommerce_real_factory */
    $this->fpay_woocommerce_real_factory = createFpayWoocommerceFactoryInstance($this->container, $this->plugin_config, $this->logger);
    /** @var FpayFactory fpay_real_factory */
    $this->fpay_real_factory = createFpayFactoryInstance($this->container, $this->plugin_config, $this->logger);
});

it('checks the method create the Fpay intent in server works', function (
    $data_for_create_wc_order,
    $created_fpay_intent_response
) {

    /**
     * Arrange
     */

    $client_mock = createClientMock(
        array($created_fpay_intent_response)
    );

    $settings = createSettingsMock();
    $logger_spy = createLoggerSpy();
    $settings_mock = createSettingsMock();

    $fpay_intent_data_hidrated = json_decode(
        json_encode($created_fpay_intent_response['body'])
    );

    $created_fpay_intent = $this->fpay_real_factory->createFpayIntent($fpay_intent_data_hidrated);

    /** @var FpayFactory | MockInterface $fpay_factory */
    $fpay_factory = Mockery::spy(FpayFactory::class)->makePartial();
    $fpay_factory->shouldReceive('createFpayIntent')
        ->andReturn($created_fpay_intent);

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $fpay_intent_from_woocommerce = $this->fpay_woocommerce_real_factory->createFpayIntent($wc_order_spy);

    $fpay_auth_spy = createFpayAuthSpy();

    $fpay_intent_manager = new FpayIntentManagerImpl(
        $client_mock,
        $settings_mock['prod_base_url'],
        $settings_mock['create_fpay_intent_url'],
        $logger_spy,
        $this->container,
        $fpay_factory,
        $settings['self_url']
    );


    /**
     * Act
     */

    $fpay_intent_to_assert = $fpay_intent_manager->createFpayIntentInServer($fpay_auth_spy->getBearerToken(), $fpay_intent_from_woocommerce);

    /**
     * Assert
     */
    expect($fpay_intent_to_assert)->toBeInstanceOf(FpayIntent::class);

})->with('data_for_create_wc_order')
    ->with('created_fpay_intent_response');

it('checks when the data send to create a Fpay intent is invalid', function (
    $data_for_create_wc_order,
    $invalid_create_fpay_intent_response
) {

    /**
     * Arrange
     */

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_add_notice')
        ->with(
            ERROR_FOR_HUMANS_MESSAGE . ERROR_KEY_2,
            'error'
        );

    $client_mock = createClientMock(
        array($invalid_create_fpay_intent_response)
    );

    $settings = createSettingsMock();
    $logger_spy = createLoggerSpy();
    $settings_mock = createSettingsMock();

    $created_fpay_intent = Mockery::spy(FpayIntent::class);

    /** @var FpayFactory | MockInterface $fpay_factory */
    $fpay_factory = Mockery::spy(FpayFactory::class)->makePartial();
    $fpay_factory->shouldReceive('createFpayIntent')
        ->andReturn($created_fpay_intent);

    $wc_order_id = $data_for_create_wc_order['transaction']['purchase_order'];
    $fpay_intent_id = $data_for_create_wc_order['id'];

    $wc_order_spy = createWcOrderSpy($wc_order_id, $fpay_intent_id, $data_for_create_wc_order);
    $fpay_intent_from_woocommerce = $this->fpay_woocommerce_real_factory->createFpayIntent($wc_order_spy);

    $fpay_auth_spy = createFpayAuthSpy();

    $fpay_intent_manager = new FpayIntentManagerImpl(
        $client_mock,
        $settings_mock['prod_base_url'],
        $settings_mock['create_fpay_intent_url'],
        $logger_spy,
        $this->container,
        $fpay_factory,
        $settings['self_url']
    );

    $message = 'Bad response client exception.';

    /**
     * Act
     */
    $exception_to_assert = new \Exception();
    $error = false;

    try {
        $fpay_intent_manager->createFpayIntentInServer(
            $fpay_auth_spy->getBearerToken(),
            $fpay_intent_from_woocommerce
        );
    } catch (\Exception $exception) {
        $exception_to_assert = $exception;
        $error = true;
    }

    /**
     * Assert
     */
    expect($error)->toBeTrue();
    expect($exception_to_assert)->toBeInstanceOf(FpayCreateIntentExceptionImpl::class);
    expect($exception_to_assert->getMessage())->toEqual($message);

})->with('data_for_create_wc_order')
    ->with('invalid_create_fpay_intent_response');

it('checks the method that gets the Fpay intent from server from self url', function (
    $data_for_create_wc_order,
    $created_fpay_intent_response
) {

    /**
     * Arrange
     */

    $client_mock = createClientMock(
        array($created_fpay_intent_response)
    );

    $settings = createSettingsMock();
    $logger_spy = createLoggerSpy();
    $settings_mock = createSettingsMock();

    $fpay_intent_data_hidrated = json_decode(
        json_encode($created_fpay_intent_response['body'])
    );

    $created_fpay_intent = $this->fpay_real_factory->createFpayIntent($fpay_intent_data_hidrated);

    /** @var FpayFactory | MockInterface $fpay_factory */
    $fpay_factory = Mockery::spy(FpayFactory::class)->makePartial();
    $fpay_factory->shouldReceive('createFpayIntent')
        ->andReturn($created_fpay_intent);

    $fpay_auth_spy = createFpayAuthSpy();

    $fpay_intent_manager = new FpayIntentManagerImpl(
        $client_mock,
        $settings_mock['prod_base_url'],
        $settings_mock['create_fpay_intent_url'],
        $logger_spy,
        $this->container,
        $fpay_factory,
        $settings['self_url']
    );


    /**
     * Act
     */

    $fpay_intent_to_assert = $fpay_intent_manager->getFpayIntentFromSelfUrl(
        $fpay_auth_spy->getBearerToken(),
        $created_fpay_intent->getSelfUrl(),
    );

    /**
     * Assert
     */
    expect($fpay_intent_to_assert)->toBeInstanceOf(FpayIntent::class);

})->with('data_for_create_wc_order')
    ->with('created_fpay_intent_response');

it('checks the method that gets the Fpay intent from server from id', function (
    $data_for_create_wc_order,
    $created_fpay_intent_response
) {

    /**
     * Arrange
     */

    $client_mock = createClientMock(
        array($created_fpay_intent_response)
    );

    $settings = createSettingsMock();
    $logger_spy = createLoggerSpy();
    $settings_mock = createSettingsMock();

    $fpay_intent_data_hidrated = json_decode(
        json_encode($created_fpay_intent_response['body'])
    );

    $created_fpay_intent = $this->fpay_real_factory->createFpayIntent($fpay_intent_data_hidrated);

    /** @var FpayFactory | MockInterface $fpay_factory */
    $fpay_factory = Mockery::spy(FpayFactory::class)->makePartial();
    $fpay_factory->shouldReceive('createFpayIntent')
        ->andReturn($created_fpay_intent);

    $fpay_auth_spy = createFpayAuthSpy();

    $fpay_intent_manager = new FpayIntentManagerImpl(
        $client_mock,
        $settings_mock['prod_base_url'],
        $settings_mock['create_fpay_intent_url'],
        $logger_spy,
        $this->container,
        $fpay_factory,
        $settings['self_url']
    );


    /**
     * Act
     */

    $fpay_intent_to_assert = $fpay_intent_manager->getFpayIntentFromId(
        $fpay_auth_spy->getBearerToken(),
        $created_fpay_intent->getId(),
    );

    /**
     * Assert
     */
    expect($fpay_intent_to_assert)->toBeInstanceOf(FpayIntent::class);

})->with('data_for_create_wc_order')
    ->with('created_fpay_intent_response');

it('checks the method try to get the Fpay Intent from self url but this fails and throw an exception ', function (
    $data_for_create_wc_order,
    $invalid_self_response,
    $created_fpay_intent_response
) {

    /**
     * Arrange
     */

    /**
     * Woocommerce functions called
     */
    expect_woocommerce('wc_add_notice')
        ->with(
            ERROR_FOR_HUMANS_MESSAGE . ERROR_KEY_14,
            'error'
        );
    $client_mock = createClientMock(
        array($invalid_self_response)
    );

    $settings = createSettingsMock();
    $logger_spy = createLoggerSpy();
    $settings_mock = createSettingsMock();
    $fpay_intent_data_hidrated = json_decode(
        json_encode($created_fpay_intent_response['body'])
    );

    $created_fpay_intent = $this->fpay_real_factory->createFpayIntent($fpay_intent_data_hidrated);

    /** @var FpayFactory | MockInterface $fpay_factory */
    $fpay_factory = Mockery::spy(FpayFactory::class)->makePartial();
    $fpay_factory->shouldReceive('createFpayIntent')
        ->andReturn($created_fpay_intent);

    $fpay_auth_spy = createFpayAuthSpy();

    $fpay_intent_manager = new FpayIntentManagerImpl(
        $client_mock,
        $settings_mock['prod_base_url'],
        $settings_mock['create_fpay_intent_url'],
        $logger_spy,
        $this->container,
        $fpay_factory,
        $settings['self_url']
    );

    $message = 'Bad response client exception.';

    /**
     * Act
     */
    $exception_to_assert = new \Exception();
    $error = false;

    try {
        $fpay_intent_manager->getFpayIntentFromSelfUrl(
            $fpay_auth_spy->getBearerToken(),
            $created_fpay_intent->getSelfUrl(),
        );
    } catch (\Exception $exception) {
        $exception_to_assert = $exception;
        $error = true;
    }

    /**
     * Assert
     */
    expect($error)->toBeTrue();
    expect($exception_to_assert)->toBeInstanceOf(FpaySelfExceptionImpl::class);
    expect($exception_to_assert->getMessage())->toEqual($message);

})->with('data_for_create_wc_order')
    ->with('invalid_self_response')
    ->with('created_fpay_intent_response');