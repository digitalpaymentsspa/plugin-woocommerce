<?php

use Fpay\Woocommerce\Factories\Contracts\FpayFactory;
use Fpay\Woocommerce\Factories\Contracts\FpayWoocommerceFactory;
use Fpay\Woocommerce\Services\Contracts\FpayAuth;
use function Brain\Monkey\Functions\when;
use Brain\Monkey;
use Fpay\Woocommerce\FpayGatewayImpl;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Client;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Psr7\Response;
use function Pest\Faker\faker;
use Mockery\MockInterface;
use Monolog\Logger;

const CURRENCY = 'CLP';
const WOOCOMMERCE_DOMAIN = 'http://example.com';
const UUID = '8d7e7a10-479e-419e-a89c-cc3cc7ba9356';
const CHECKOUT_URL = WOOCOMMERCE_DOMAIN . '/?page_id=12';

/*
|--------------------------------------------------------------------------
| Test Case
|--------------------------------------------------------------------------
|
| The closure you provide to your test functions is always bound to a specific PHPUnit test
| case class. By default, that class is "PHPUnit\Framework\TestCase". Of course, you may
| need to change it using the "uses()" function to bind a different classes or traits.
|
*/


uses()
    ->beforeAll(function () {
        Monkey\setUp();
    })
    ->afterAll(function () {
        Monkey\tearDown();
        Mockery::close();
    })
    // This mock the wp functions that the plugin uses.
    ->beforeEach(function () {
        $this->container = require __DIR__ . '/../app/bootstrap.php';
        $this->plugin_config = $this->container->get('config');
        $this->logger = $this->container->get('Logger');

        when('get_option')->justReturn([
            "enabled" => "yes",
            "api_details" => "",
            "public_key" => "usuario",
            "private_key" => "r5G^FfaE4FJ%$%!@321",
            "environment" => "produccion",
        ]);
        when('apply_filters')->justReturn(null);
        when('admin_url')->returnArg();
        when('plugins_url')->returnArg();
        when('plugin_dir_url')->alias(function ($file) {
            $string = dirname($file);
            return rtrim($string, '/\\') . '/';
        });
        when('get_current_blog_id')->justReturn(42);
        when('get_site_url')->justReturn(WOOCOMMERCE_DOMAIN);
        when('get_woocommerce_currency')->justReturn(CURRENCY);
        when('wc_get_base_location')->justReturn(['country' => 'CL']);

        when('wp_register_style')->justReturn(true);
        when('wp_enqueue_style')->justReturn();

    })->in('src');

/*
|--------------------------------------------------------------------------
| Expectations
|--------------------------------------------------------------------------
|
| When you're writing tests, you often need to check that values meet certain conditions. The
| "expect()" function gives you access to a set of "expectations" methods that you can use
| to assert different things. Of course, you may extend the Expectation API at any time.
|
*/

expect()->extend('toBeOne', function () {
    return $this->toBe(1);
});

/*
|--------------------------------------------------------------------------
| Functions
|--------------------------------------------------------------------------
|
| While Pest is very powerful out-of-the-box, you may have some testing code specific to your
| project that you don't want to repeat in every file. Here you can also expose helpers as
| global functions to help you to reduce the number of lines of code in your test files.
|
*/

/**
 * @return MockInterface | Logger
 */
function createLoggerSpy()
{
    $logger_spy = Mockery::spy(Logger::class);
    $logger_spy->shouldReceive('info')->andReturn('');
    $logger_spy->shouldReceive('debug')->andReturn('');
    $logger_spy->shouldReceive('warning')->andReturn('');
    $logger_spy->shouldReceive('error')->andReturn('');
    return $logger_spy;
}

/**
 * @param $data
 * @return WC_Order_Refund | MockInterface
 */
function createWcOrderRefund(array $data): WC_Order_Refund
{
    $wc_order_refund = Mockery::mock(WC_Order_Refund::class)->makePartial();
    $wc_order_refund->shouldReceive('get_meta_data')->andReturn($data['meta_data']);
    $wc_order_refund->shouldReceive('get_id')->andReturn($data['id']);
    $wc_order_refund->shouldReceive('save')->andReturnTrue();
    $wc_order_refund->shouldReceive('get_reason')->andReturn($data['reason']);
    $wc_order_refund->shouldReceive('set_reason')->andReturn();

    return $wc_order_refund;
}

/**
 * @return array
 */
function createSettingsMock(): array
{
    return [
        'public_key' => faker()->uuid(),
        'private_key' => faker()->uuid(),
        'auth_url' => '/sso/oauth2/v2/token',
        'prod_base_url' => 'https://payments-wallet.fif.tech',
        'qa_base_url' => 'https://payments-psp-qa.fpayapp.com',
        'int_base_url' => 'https://payments-psp-int.fpayapp.com',
        'self_url' => '/checkout/payments/',
        'create_fpay_intent_url' => '/checkout/payments'
    ];
}

/**
 * @param string $self_url
 * @return WC_Session | MockInterface
 */
function createWcSessionSpy(string $self_url, string $uuid, string $spy_order_id): WC_Session
{
    $wc_session = Mockery::spy(WC_Session::class);
    $wc_session->shouldReceive('set')->andReturn();
    $wc_session->shouldReceive('get')
        ->withAnyArgs()
        ->andReturnUsing(function ($key) use ($uuid, $spy_order_id, $self_url) {
            if ($uuid . FpayGatewayImpl::ORDER_ID_KEY === $key) {
                return $spy_order_id;
            } elseif ($uuid . FpayGatewayImpl::SELF_LINK_KEY === $key) {
                return $self_url;
            }
            return $key;
        });
    return $wc_session;
}

/**
 * @param FpayFactory $fpay_factory
 * @param $refund_pure_data_array
 * @return array
 */
function createRefundsFromFpayIntentData(FpayFactory $fpay_factory, $refund_pure_data_array, $fpay_intent_id): array
{
    $pending_refunds = array();
    foreach ($refund_pure_data_array as $refund_pure_data) {
        $refund_pure_data['fpay_intent_id'] = $fpay_intent_id;
        $refund_pure_data['authorization_id'] = (string)$refund_pure_data['authorization_code'];
        unset($refund_pure_data['authorization_code']);
        array_push($pending_refunds, $fpay_factory->createRefund($refund_pure_data));
    }

    return $pending_refunds;
}

function createRefundFromRefundData($fpay_factory, $fpay_intent_id, $amount = 0, $order_id)
{

    $refund_data = array(
        'fpay_intent_id' => $fpay_intent_id,
        'refunded_amount' => $amount === null ? 0 : $amount,
        'refund_merchant_unique_id' => $order_id,
        'authorization_id' => -1
    );
    return $fpay_factory->createRefund($refund_data);
}

/**
 * @param $container
 * @param $plugin_config
 * @param $logger
 * @return FpayWoocommerceFactory
 */
function createFpayWoocommerceFactoryInstance($container, $plugin_config, $logger): FpayWoocommerceFactory
{
    return $container->make(FpayWoocommerceFactory::class, [
        'container' => $container,
        'plugin_config' => $plugin_config,
        'logger' => $logger,
        'channel' => 'WEB',
    ]);
}

/**
 * @param $container
 * @param $plugin_config
 * @param $logger
 * @return FpayFactory
 */
function createFpayFactoryInstance($container, $plugin_config, $logger): FpayFactory
{
    return $container->make(FpayFactory::class, [
        'container' => $container,
        'plugin_config' => $plugin_config,
        'logger' => $logger,
        'channel' => 'WEB',
    ]);
}

/**
 * @return FpayAuth | MockInterface
 */
function createFpayAuthSpy(): FpayAuth
{
    $fpay_auth_mock = Mockery::spy(FpayAuth::class)
        ->makePartial();
    $fpay_auth_mock->shouldReceive('authInServer')
        ->withAnyArgs()
        ->andReturn();
    $fpay_auth_mock->shouldReceive('getBearerToken')
        ->andReturn('eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJwcmltYXJ5c2lkIjoiNjI3NTJlODIyYjYwNGUwMDNlNGZiNDJmIiwidW5pcXVlX25hbWUiOiJPbnRoZW0gQ29tZXJjaW8gMDEiLCJncm91cHNpZCI6IkFQUEwiLCJpc3MiOiJGYWxhYmVsbGEiLCJhdWQiOiJXZWIiLCJ0eXBlIjoiQmVhcmVyIiwic2NvcGUiOltdLCJpYXQiOjE2NjEzMTgyMjYsImV4cCI6MTY2MTMxODgyNn0.gvP8jX-sP921SK1mfw1V5KH4SKMer5cKqWVrUnZzeFLgy4dqQHPKFajLxzEXLFTTcHTJ7Q5zk8X2E6bDZBeoVQojPT6YXUDHSfccFeu5oTGf5u5arbg-VbQfLlmEyv0KG3W6aAwNZ_gPjEYZGXqfqChurYguYhYkeh4GAIEnU1SS2Eqk-kN2KMG1V_USW-dWrKS4XrtjXBNuu6zXmuyr32jVsYTQXSud02nzrY_JqeC_XQ6yYgvvaDEEaa2MqgrVtgG1nBr7sN-AZssmc58e3fGUiG0T9gXgvH3ANO0a85IYWbBLCz1czHnM3Darzmlbgo9_9hEUabzIwbM0ofmvbg');
    return $fpay_auth_mock;
}

function createClientMock(array $responses_data)
{
    $mock = new MockHandler(
        buildResponses($responses_data)
    );

    $handlerStack = HandlerStack::create($mock);
    return new Client(['handler' => $handlerStack]);
}

function buildResponses(array $responses_data): array{
    $guzzle_responses_mocks_list = array();

    if(empty($responses_data)){
        return  $guzzle_responses_mocks_list;
    }

    foreach ($responses_data as $response_datum){
        $guzzle_response = new Response(
            $response_datum['http_code'],
            $response_datum['headers'],
            json_encode($response_datum['body'])
        );
        array_push($guzzle_responses_mocks_list, $guzzle_response);
    }
    return  $guzzle_responses_mocks_list;
}

/**
 * @param $order_id
 * @param $fpay_intent_id
 * @param array $complete_data
 * @return WC_Order | MockInterface
 */
function createWcOrderSpy($order_id, $fpay_intent_id, $complete_data = []): WC_Order
{
    $wc_order_spy = Mockery::spy(WC_Order::class)->makePartial();
    $wc_order_spy->shouldReceive('get_id')->andReturn($order_id);
    $wc_order_spy->shouldReceive('get_transaction_id')->andReturn($fpay_intent_id);
    $wc_order_spy->shouldReceive('save')->andReturn(1);

    if (empty($complete_data)) {
        return $wc_order_spy;
    }
    $wc_order_spy->shouldReceive('get_subtotal')
        ->andReturn(round($complete_data['subtotal']));

    $wc_order_spy->shouldReceive('get_shipping_total')
        ->andReturn(round($complete_data['shipping']));

    $wc_order_spy->shouldReceive('get_total')
        ->andReturn($complete_data['total']);

    $wc_order_spy->shouldReceive('get_billing_city')
        ->andReturn($complete_data['billing_city']);

    $wc_order_spy->shouldReceive('get_billing_phone')
        ->andReturn($complete_data['phone']);

    $wc_order_spy->shouldReceive('get_billing_first_name')
        ->andReturn($complete_data['billing_first_name']);

    $wc_order_spy->shouldReceive('get_billing_last_name')
        ->andReturn($complete_data['billing_last_name']);

    $wc_order_spy->shouldReceive('get_billing_last_name')
        ->andReturn($complete_data['billing_last_name']);

    $wc_order_items = array();
    foreach ($complete_data['items'] as $item) {
        array_push($wc_order_items, createWcOrderItemSpy($item));
    }
    $wc_order_spy->shouldReceive('get_items')
        ->andReturn($wc_order_items);

    $wc_order_spy->shouldReceive('get_billing_email')
        ->andReturn($complete_data['buyer']['email']);

    $wc_order_spy->shouldReceive('get_logger_in')
        ->andReturn($complete_data['buyer']['logged_in']);

    $wc_order_spy->shouldReceive('get_billing_phone')
        ->andReturn($complete_data['buyer']['phone']);

    $wc_order_spy->shouldReceive('get_billing_first_name')
        ->andReturn($complete_data['buyer']['first_name']);
    $wc_order_spy->shouldReceive('get_billing_last_name')
        ->andReturn($complete_data['buyer']['last_name']);

    return $wc_order_spy;
}

/**
 * @param array $item
 * @return WC_Order_Item | MockInterface
 */
function createWcOrderItemSpy(array $item): WC_Order_Item
{
    $wc_order_item_spy = Mockery::spy(WC_Order_Item::class);
    $wc_order_item_spy->shouldReceive('get_product_id')
        ->andReturn($item['sku']);
    $wc_order_item_spy->shouldReceive('get_name')
        ->andReturn($item['name']);
    $wc_order_item_spy->shouldReceive('get_name')
        ->andReturn(
            $item['description'] === ''
                ? $wc_order_item_spy->get_name() : $item['description']
        );
    $wc_order_item_spy->shouldReceive('get_quantity')
        ->andReturn($item['quantity']);
    $wc_order_item_spy->shouldReceive('get_total')
        ->andReturn($item['total']);
    $wc_order_item_spy->shouldReceive('get_subtotal_tax')
        ->andReturn($item['tax']);
    $wc_order_item_spy->shouldReceive('get_type')
        ->andReturn(array_key_exists('category', $item) ? $item['category'] : '');

    return $wc_order_item_spy;
}
