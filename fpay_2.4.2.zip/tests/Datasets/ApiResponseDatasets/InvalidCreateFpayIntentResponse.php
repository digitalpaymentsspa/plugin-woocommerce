<?php

dataset('invalid_create_fpay_intent_response', function () {
    yield function () {
        return [
            'http_code' => 400,
            'body' => [
                "error_code" => "INVALID_MODEL",
                "error_description" => "the requested model has invalid properties",
                "meta_data" => [
                    "validations" => [
                        [
                            "message" => "Path `description` is required.",
                            "kind" => "required",
                            "path" => "description",
                        ],
                        [
                            "message" =>
                                "Validation failed: description: Path `description` is required.",
                        ],
                    ],
                ],
                "statusCode" => 400,
            ],
            'headers' => []
        ];
    };
});
