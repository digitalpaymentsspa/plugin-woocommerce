<?php

dataset('invalid_credentials_data', function () {
    yield function () {
        return [
            'http_code' => 400,
            'body' => [
                "error_code" => "INVALID_CREDENTIALS",
                "error_description" => "The credentials are invalid",
                "meta_data" => []
            ],
            'headers' => []
        ];
    };
});
