<?php

dataset('wc_order_refund_with_metadata_data', function () {
    yield function () {
        return [
            "id" => 367,
            "parent_id" => 366,
            "status" => "completed",
            "currency" => "COP",
            "version" => "6.4.1",
            "prices_include_tax" => false,
            "date_created" => [
                "date" => "2022-08-26 06:00:13.000000",
                "timezone_type" => 1,
                "timezone" => "+00:00",
            ],
            "date_modified" => [
                "date" => "2022-08-26 06:00:13.000000",
                "timezone_type" => 1,
                "timezone" => "+00:00",
            ],
            "discount_total" => "0",
            "discount_tax" => "0",
            "shipping_total" => "0",
            "shipping_tax" => "0",
            "cart_tax" => "0",
            "total" => "-1",
            "total_tax" => "0",
            "amount" => "1",
            "reason" => "",
            "refunded_by" => 1,
            "refunded_payment" => false,
            "meta_data" => [
                [
                    "id" => 6216,
                    "key" => "fpay_meta_data",
                    "value" => [
                        "payment_method" => "fpay_woocommerce",
                        "fpay_intent_id" => "63084004cadb56394d4282b8",
                        "refunded_amount" => 1,
                        "refund_merchant_unique_id" =>
                            "wc_wc_366_20220826060015000000_20220826060018000000",
                        "authorization_id" => "39271193",
                        "state" => "applied",
                    ],
                ],
            ],
            "line_items" => [],
            "tax_lines" => [],
            "shipping_lines" => [],
            "fee_lines" => [],
            "coupon_lines" => [],
        ];

    };
});