<?php

/**
 * Plugin Name: Fpay Gateway
 * Description: Plugin oficial de Fpay.
 * Author: Fpay
 * Author URI: https://fpay.cl/
 * Version: 2.4.2
 */

require __DIR__ . '/vendor/autoload.php';
require_once(ABSPATH . 'wp-admin/includes/plugin.php');

use function Fpay\Woocommerce\Config\config;

/**
 * this evaluates for only gives access to WordPress and not for external web browser
 */
defined('ABSPATH') || exit;

$plugin_version = config('plugin_version');
$plugin_id = config('plugin_id');
$plugin_prefix = config('plugin_prefix');
$plugin_number = config('plugin_number');
$plugin_file_name = config('plugin_file_name');
$current_plugin_path = $plugin_prefix . '/' . $plugin_file_name;
$gateway_path = config('gateway_path');
$gateway_class_name = config('gateway_class_name');
$woocommerce_options_name = 'woocommerce_' . $plugin_id . '_settings';

/**
 * This function is executed before active the plugin.
 */
$plugin_activation_function = $plugin_prefix . '_plugin_activation';
if (!function_exists($plugin_activation_function)) {
    $plugin_activation_function = function () {

        $source = plugin_dir_path(__FILE__) . '.env.example';
        $destination = plugin_dir_path(__FILE__) . '.env';
        copy($source, $destination);

        if (!defined('WC_VERSION')) {

            $logo = esc_url(plugin_dir_url(__FILE__) . '/img/logo.png');
            echo '
                <div class="notice notice-error is-dismissible">
                <p> <img src="' . $logo . '"> requiere Woocommerce instalado para ser activado.</p>
            </div>';
            exit();
        }
    };
}
register_activation_hook(__FILE__, $plugin_activation_function);


/**
 * Activation Hook for register the gateway in the list of gateways for woocommerce
 */
$fpay_add_gateway_payment_class_function = $plugin_prefix . '_add_gateway_payment_class';
if (!function_exists($fpay_add_gateway_payment_class_function)) {
    $fpay_add_gateway_payment_class_function = function ($gateways) use ($gateway_path) {
        if (is_plugin_active('woocommerce/woocommerce.php')) {
            $gateways[] = $gateway_path;
            return $gateways;
        }
    };
}
add_filter('woocommerce_payment_gateways', $fpay_add_gateway_payment_class_function);


/*
 * This build the message when the credentials are not configured
 */
$fpay_credentials_are_not_configured_message_function = $plugin_prefix .
    '_credentials_are_not_configured_message';
if (!function_exists($fpay_credentials_are_not_configured_message_function)) {
    $fpay_credentials_are_not_configured_message_function = function () use ($plugin_id, $plugin_number) {
        if (is_admin()) {
            $logo = esc_url(plugin_dir_url(__FILE__) . '/img/logo.png');
            echo '
           <div class="notice notice-error is-dismissible">
          <p> <img src="' . $logo . '">
           ' . $plugin_number . ' necesita que configure sus credenciales.
           <a href=' . "/wp-admin/admin.php?page=wc-settings&tab=checkout&section=" . $plugin_id . '>Clic aquí para configurar.</a>
           </p>
         </div>';
        }
    };
}

/**
 * Define if the credentials are not configured
 */
$fpay_define_show_message_if_credentiales_are_not_configured_function = $plugin_prefix .
    '_define_show_message_if_credentiales_are_not_configured';
if (!function_exists($fpay_define_show_message_if_credentiales_are_not_configured_function)) {
    $fpay_define_show_message_if_credentiales_are_not_configured_function = function () use (
        $fpay_credentials_are_not_configured_message_function,
        $woocommerce_options_name
    ) {
        $fpay_options = get_option($woocommerce_options_name, array());
        $private_key = array_key_exists('private_key', $fpay_options) ? $fpay_options['private_key'] : '';
        $public_key = array_key_exists('public_key', $fpay_options) ? $fpay_options['public_key'] : '';

        if ($private_key === '' || $public_key === '') {
            add_action('admin_notices', $fpay_credentials_are_not_configured_message_function);
        }
    };
}

/**
 * This function show the dependency message for woocommerce
 */
$fpay_woocommerce_dependency_message_function = $plugin_prefix . '_woocommerce_dependency_message';
if (!function_exists($fpay_woocommerce_dependency_message_function)) {

    $fpay_woocommerce_dependency_message_function = function () use ($plugin_number) {
        global $pagenow;

        if ($pagenow === 'plugins.php') {
            $logo = esc_url(plugin_dir_url(__FILE__) . '/img/logo.png');
            echo '
           <div class="notice notice-error is-dismissible">
          <p> <img src="' . $logo . '">
            ' . $plugin_number . ' - fue desactivado. Active: <b>Woommerce</b> para continuar recibiendo pagos.</p>
         </div>';
        }
    };
}

/**
 * This functions is executed every momento that a plugins is loaded.
 */
$fpay_plugins_loaded_function = $plugin_prefix . '_plugins_loaded';
if (!function_exists($fpay_plugins_loaded_function)) {
    $fpay_plugins_loaded_function = function () use (
        $fpay_define_show_message_if_credentiales_are_not_configured_function,
        $fpay_woocommerce_dependency_message_function,
        $current_plugin_path
    ) {

        if (!defined('WC_VERSION')) {
            deactivate_plugins($current_plugin_path);
            add_action('admin_notices', $fpay_woocommerce_dependency_message_function);
        }

        $section = array_key_exists('section', $_GET) ?: '';
        if (is_plugin_active($current_plugin_path) && $section === '') {
            $fpay_define_show_message_if_credentiales_are_not_configured_function();
        }
    };
}
add_action('plugins_loaded', $fpay_plugins_loaded_function);
